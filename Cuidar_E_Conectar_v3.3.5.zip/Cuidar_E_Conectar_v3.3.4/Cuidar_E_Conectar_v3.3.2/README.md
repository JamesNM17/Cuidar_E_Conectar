# Cuidar & Conectar — versão 3.3.2

Sistema web de gestão de atendimento clínico com áreas separadas por cargo.

## Cargos e abas

- **Administrador:** visão geral, controle do sistema, central de operações, funcionários, recepção, triagem, pacientes, Conselheiro de Saúde, Segurança, Suporte, painel e personalização.
- **Recepcionista:** recepção e pacientes.
- **Enfermeiro:** triagem.
- **Conselheiro de Saúde:** atendimento clínico e emissão dos documentos clínicos.
- **Segurança:** central de segurança.
- **Suporte de TI:** central de suporte e chamados.

Documentação de estudos, suporte técnico e créditos ficam disponíveis como atalhos comuns aos usuários autenticados.

## Executar no Windows

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
py -m pip install -r requirements.txt
py main.py
```

O arquivo `.env` é carregado automaticamente. Para instalação nova, use `.env.example` como base.

## Criar usuário

O cadastro deve ser feito pelo administrador dentro do sistema ou por script administrativo controlado. Não use credenciais padrão em produção.


## v3.3.5 — Refino visual
- Ajuste de hierarquia tipográfica e espaçamento.
- Paleta clínica azul + teal, com melhor contraste.
- Sidebar, cards, botões e campos com acabamento mais consistente.
- Responsividade preservada.
