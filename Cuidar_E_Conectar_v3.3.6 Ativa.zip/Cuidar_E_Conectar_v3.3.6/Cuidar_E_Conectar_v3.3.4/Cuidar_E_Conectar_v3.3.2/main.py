# =========================================================
# CUIDAR & CONECTAR • v3.3.2
# =========================================================

import os
import uuid
import qrcode
import base64
import secrets
import json
import logging
import re

from dotenv import load_dotenv
from sqlalchemy import inspect as sa_inspect
from flask import (
    Flask,
    render_template,
    redirect,
    url_for,
    abort,
    flash,
    request,
    jsonify,
    session,
)
from werkzeug.utils import secure_filename
from flask_socketio import SocketIO, emit
from flask_login import (
    LoginManager,
    login_user,
    logout_user,
    login_required,
    current_user,
)
from flask_admin import Admin, AdminIndexView
from flask_wtf.csrf import CSRFProtect, CSRFError
from datetime import datetime, timezone
from io import BytesIO
from pathlib import Path
from zoneinfo import ZoneInfo
from PIL import Image, UnidentifiedImageError

# =========================================================
# DATABASE/MODELS
# =========================================================

from dados1 import db1
from model import (
    Funcionarios,
    Recepcao,
    Triagem,
    Medico,
    Paciente,
    AdminRecepcao,
    AdminTriagem,
    AdminMedico,
    AdminFuncionarios,
    ChamadoSuporte,
    Notificacao,
    AcessoLog,
    ChamadoSeguranca,
)

# =========================================================
# FORMS
# =========================================================

from forms import (
    FuncionarioForm,
    RecepcaoForm,
    TriagemForm,
    MedicoForm,
    LoginForm,
    PacienteForm,
    LocalAtendimentoForm,
)

# =========================================================
# APP
# =========================================================

load_dotenv()

app = Flask(__name__)
logger = logging.getLogger(__name__)

app.config["SQLALCHEMY_DATABASE_URI"] = os.getenv(
    "DATABASE_URL", "sqlite:///project.db"
).replace("postgres://", "postgresql://", 1)
app.config["SECRET_KEY"] = os.getenv("SECRET_KEY") or secrets.token_hex(32)
app.config["UPLOAD_FOLDER"] = os.path.join(app.root_path, "static", "uploads")
app.config["MAX_CONTENT_LENGTH"] = 5 * 1024 * 1024
app.config["SESSION_COOKIE_HTTPONLY"] = True
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"
app.config["REMEMBER_COOKIE_HTTPONLY"] = True
app.config["REMEMBER_COOKIE_SAMESITE"] = "Lax"
app.config["SESSION_COOKIE_SECURE"] = os.getenv("SESSION_COOKIE_SECURE", "0") == "1"
app.config["REMEMBER_COOKIE_SECURE"] = os.getenv("REMEMBER_COOKIE_SECURE", "0") == "1"

os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)

APP_LOG_PATH = Path(app.root_path) / "instance" / "app.log"
APP_LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
if not any(isinstance(h, logging.FileHandler) and getattr(h, "baseFilename", "") == str(APP_LOG_PATH) for h in logger.handlers):
    _file_handler = logging.FileHandler(APP_LOG_PATH, encoding="utf-8")
    _file_handler.setFormatter(logging.Formatter("%(asctime)s | %(levelname)s | %(message)s"))
    logger.addHandler(_file_handler)
logger.setLevel(logging.INFO)

db1.init_app(app)

csrf = CSRFProtect(app)

socketio = SocketIO(app, async_mode="threading")

# =========================================================
# DATABASE CREATE
# =========================================================

with app.app_context():
    db1.create_all()

    try:
        inspector = sa_inspect(db1.engine)
        columns = {c["name"] for c in inspector.get_columns("funcionarios")}
        if "especialidade" not in columns:
            with db1.engine.begin() as conn:
                conn.exec_driver_sql(
                    "ALTER TABLE funcionarios ADD COLUMN especialidade VARCHAR(50)"
                )
    except Exception:

        pass

    # Migrações leves para instalações já existentes.
    try:
        def _ensure_columns(table, columns):
            inspector = sa_inspect(db1.engine)
            existing = {c["name"] for c in inspector.get_columns(table)}
            with db1.engine.begin() as conn:
                for name, ddl in columns.items():
                    if name not in existing:
                        conn.exec_driver_sql(f"ALTER TABLE {table} ADD COLUMN {name} {ddl}")
        _ensure_columns("funcionarios", {
            "local_atendimento": "VARCHAR(160)",
        })
        _ensure_columns("recepcao", {
            "reaberto_em": "TIMESTAMP",
            "reaberto_por": "VARCHAR(100)",
            "reaberto_motivo": "TEXT",
            "reaberto_destino": "VARCHAR(50)",
            "local_atendimento": "VARCHAR(160)",
        })
        _ensure_columns("medico", {
            "encaminhamento_destino": "VARCHAR(200)",
            "encaminhamento_motivo": "TEXT",
        })
        _ensure_columns("notificacoes", {
            "voz": "BOOLEAN DEFAULT 0",
        })

        # Os módulos aposentados não participam mais do sistema.
        # Remove tabelas legadas e contas exclusivas desses módulos da base entregue.
        legacy_tables = ["psicologia", "vacinacao", "vendas_planos", "paciente_planos", "planos"]
        inspector = sa_inspect(db1.engine)
        existing_tables = set(inspector.get_table_names())
        with db1.engine.begin() as conn:
            for table in legacy_tables:
                if table in existing_tables:
                    conn.exec_driver_sql(f"DROP TABLE {table}")
        try:
            db1.session.query(Funcionarios).filter(
                db1.func.lower(Funcionarios.funcao).in_(["psicologo", "psicóloga", "comercial", "vendas"])
            ).delete(synchronize_session=False)
            db1.session.commit()
        except Exception:
            db1.session.rollback()
    except Exception:
        pass

# =========================================================
# LOGIN MANAGER
# =========================================================

login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = "login"


@login_manager.user_loader
def load_user(user_id):

    try:
        return db1.session.get(Funcionarios, user_id)

    except Exception:
        return None


# =========================================================
# CONTROLE DE LOCAL DE ATENDIMENTO
# =========================================================

@app.before_request
def exigir_local_de_atendimento():
    """Impede acesso a áreas autenticadas sem um local confirmado na sessão.

    As APIs de estado usadas pelas telas de login/local não podem gravar a própria
    URL como ``next_after_local``; isso causava o redirecionamento para JSON depois
    de confirmar o local.
    """
    endpoint = request.endpoint or ""
    if not current_user.is_authenticated:
        return None
    if endpoint in {
        "login",
        "selecionar_local",
        "sair",
        "assinar",
        "static",
        "csrf_error",
        "api_estado_sistema",
        "api_notificacoes",
        "api_avisos_globais",
        "marcar_aviso_global_lido",
    }:
        return None
    if request.method == "OPTIONS":
        return None
    if not local_atendimento_atual():
        if endpoint != "selecionar_local":
            target = request.full_path if request.full_path.startswith("/") else "/"
            if not target.startswith("/local-atendimento"):
                session["next_after_local"] = target
        return redirect(url_for("selecionar_local"))
    return None


# =========================================================
# FLASK ADMIN
# =========================================================

class AdminIndex(AdminIndexView):
    def is_accessible(self):
        return current_user.is_authenticated and normalizar_funcao(current_user.funcao) in {
            "administrador", "recepcionista", "enfermeiro", "medico"
        }

    def inaccessible_callback(self, name, **kwargs):
        if not current_user.is_authenticated:
            return redirect(url_for("login"))
        abort(403)


admin = Admin(app, name="Painel Clínico", index_view=AdminIndex(name="Painel Clínico"))
admin.add_view(AdminRecepcao(Recepcao, db1.session, name="Recepção"))
admin.add_view(AdminTriagem(Triagem, db1.session, name="Triagem"))
admin.add_view(AdminMedico(Medico, db1.session, name="Médico"))
admin.add_view(AdminFuncionarios(Funcionarios, db1.session, name="Funcionários"))

# =========================================================
# HELPERS
# =========================================================

ROLE_ALIASES = {
    "administrador": "administrador",
    "recepcionista": "recepcionista",
    "enfermeiro": "enfermeiro",
    "médico": "medico",
    "medico": "medico",
    "conselheiro": "medico",
    "conselheiro de saúde": "medico",
    "conselheiro de saude": "medico",
    "suporte tecnico": "suporte_ti",
    "suporte técnico": "suporte_ti",
    "suporte_tecnico": "suporte_ti",
    "suporte_ti": "suporte_ti",
    "segurança": "seguranca",
    "seguranca": "seguranca",
}

ROLE_LABELS = {
    "administrador": "Administrador",
    "recepcionista": "Recepcionista",
    "enfermeiro": "Enfermeiro",
    "medico": "Conselheiro de Saúde",
    "suporte_ti": "Suporte de TI",
    "seguranca": "Segurança",
}


def normalizar_funcao(funcao):
    valor = (funcao or "").strip().lower()
    return ROLE_ALIASES.get(valor, valor)


def check_role(*roles):
    if not current_user.is_authenticated or not current_user.funcao:
        return False
    funcao_atual = normalizar_funcao(current_user.funcao)
    return funcao_atual in {normalizar_funcao(r) for r in roles}


def require_role(*roles):

    if not check_role(*roles):
        abort(403)


@app.context_processor
def contexto_navegacao():
    if not current_user.is_authenticated:
        return {"funcao_atual": "", "funcao_label": ""}
    funcao = normalizar_funcao(current_user.funcao)
    return {
        "funcao_atual": funcao,
        "funcao_label": ROLE_LABELS.get(funcao, current_user.funcao or "Usuário"),
    }


def local_atendimento_atual():
    """Retorna o local confirmado para a sessão atual."""
    valor = (session.get("local_atendimento") or "").strip()
    return valor[:160] if valor else None


def inicio_dia_brasilia_utc():
    """Início do dia local de São Paulo convertido para UTC."""
    agora_local = datetime.now(FUSO_BRASILIA)
    inicio_local = agora_local.replace(hour=0, minute=0, second=0, microsecond=0)
    return inicio_local.astimezone(timezone.utc)


# =========================================================
# HELPERS DE ARQUIVOS
# =========================================================

ALLOWED_IMAGE_EXTENSIONS = {"png", "jpg", "jpeg", "webp"}


def allowed_image(filename):
    return (
        bool(filename)
        and "." in filename
        and filename.rsplit(".", 1)[1].lower() in ALLOWED_IMAGE_EXTENSIONS
    )


def salvar_imagem_upload(arquivo):
    """Valida o conteúdo real da imagem e salva com nome seguro e único."""
    if not arquivo or not arquivo.filename:
        return None

    if not allowed_image(arquivo.filename):
        raise ValueError("Formato de imagem não permitido. Use PNG, JPG, JPEG ou WEBP.")

    try:
        arquivo.stream.seek(0)
        with Image.open(arquivo.stream) as imagem:
            imagem.verify()
        arquivo.stream.seek(0)
        with Image.open(arquivo.stream) as imagem:
            imagem.load()
    except (UnidentifiedImageError, OSError, Image.DecompressionBombError) as exc:
        logger.warning("Upload de imagem rejeitado: %s", exc)
        raise ValueError("O arquivo enviado não é uma imagem válida.") from exc

    nome_original = secure_filename(arquivo.filename) or "imagem"
    nome_final = f"{uuid.uuid4().hex}_{nome_original}"
    caminho = os.path.join(app.config["UPLOAD_FOLDER"], nome_final)
    arquivo.stream.seek(0)
    arquivo.save(caminho)
    return f"uploads/{nome_final}"


# =========================================================
# CONFIGURAÇÃO DO PAINEL DE SENHAS
# =========================================================

PAINEL_CONFIG_PATH = Path(app.root_path) / "painel_config.json"

PAINEL_CONFIG_PADRAO = {
    "titulo": "Painel de Atendimento",
    "subtitulo": "Clínica Cuidar & Conectar",
    "cor_principal": "#0f172a",
    "cor_destaque": "#14b8a6",
    "cor_fundo": "#08111f",
    "mostrar_nome": True,
    "voz": True,
    "intervalo_atualizacao": 5,
    "tempo_exibicao": 15,
    "modo_exibicao": "principal",
    "imagem_personalizada": "",
    "logo_clinica": "",
    "colaboradores": [],
}


def carregar_config_painel():
    try:
        if PAINEL_CONFIG_PATH.exists():
            dados = json.loads(PAINEL_CONFIG_PATH.read_text(encoding="utf-8"))
            return {**PAINEL_CONFIG_PADRAO, **dados}
    except (OSError, json.JSONDecodeError):
        pass
    return PAINEL_CONFIG_PADRAO.copy()


def salvar_config_painel(config):
    PAINEL_CONFIG_PATH.write_text(
        json.dumps(config, ensure_ascii=False, indent=2), encoding="utf-8"
    )


app.jinja_env.globals["carregar_config_painel"] = carregar_config_painel


ADMIN_STATE_PATH = Path(app.root_path) / "instance" / "admin_state.json"
ADMIN_STATE_PADRAO = {"modo_descanso": False, "mensagem_descanso": "A clínica está temporariamente em modo descanso."}

def carregar_estado_admin():
    try:
        if ADMIN_STATE_PATH.exists():
            dados = json.loads(ADMIN_STATE_PATH.read_text(encoding="utf-8"))
            return {**ADMIN_STATE_PADRAO, **dados}
    except (OSError, json.JSONDecodeError):
        pass
    return ADMIN_STATE_PADRAO.copy()


def salvar_estado_admin(estado):
    tmp = ADMIN_STATE_PATH.with_suffix(".tmp")
    tmp.write_text(json.dumps(estado, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(ADMIN_STATE_PATH)


def ultimos_logs_arquivo(limite=180):
    try:
        linhas = APP_LOG_PATH.read_text(encoding="utf-8", errors="replace").splitlines()
        return linhas[-limite:]
    except OSError:
        return []


def _inteiro_seguro(valor, padrao):
    try:
        return int(str(valor).strip())
    except (TypeError, ValueError):
        return padrao


def preco_brl(valor):
    try:
        return (
            f"R$ {float(valor):,.2f}".replace(",", "X")
            .replace(".", ",")
            .replace("X", ".")
        )
    except (TypeError, ValueError):
        return "R$ 0,00"


app.jinja_env.filters["brl"] = preco_brl

# =========================================================
# NOTIFICAÇÕES / OPERAÇÃO EM TEMPO REAL
# =========================================================


def criar_notificacao(
    titulo, mensagem, tipo="info", link=None, destinatario_id=None, funcao_destino=None, voz=False
):
    n = Notificacao(
        titulo=titulo[:160],
        mensagem=mensagem,
        tipo=tipo[:20],
        link=link,
        destinatario_id=destinatario_id,
        funcao_destino=funcao_destino,
        voz=bool(voz),
    )
    db1.session.add(n)
    return n


def notificar_funcao(funcao, titulo, mensagem, tipo="info", link=None):
    alvo = normalizar_funcao(funcao)
    usuarios = [u for u in Funcionarios.query.all() if normalizar_funcao(u.funcao) == alvo]
    for usuario in usuarios:
        criar_notificacao(titulo, mensagem, tipo, link, destinatario_id=usuario.id)


def notificar_usuario(usuario_id, titulo, mensagem, tipo="info", link=None):
    criar_notificacao(titulo, mensagem, tipo, link, destinatario_id=usuario_id)


def notificacoes_visiveis():
    if not current_user.is_authenticated:
        return []
    return (
        Notificacao.query.filter(
            Notificacao.tipo != "broadcast",
            db1.or_(
                Notificacao.destinatario_id == current_user.id,
                db1.and_(
                    Notificacao.destinatario_id.is_(None),
                    Notificacao.funcao_destino.isnot(None),
                    Notificacao.funcao_destino.ilike(current_user.funcao or ""),
                ),
                db1.and_(
                    Notificacao.destinatario_id.is_(None),
                    Notificacao.funcao_destino.is_(None),
                ),
            )
        )
        .order_by(Notificacao.criada_em.desc())
        .limit(20)
        .all()
    )


@app.context_processor
def contexto_notificacoes():
    if not current_user.is_authenticated:
        return {"notificacoes_topo": [], "notificacoes_nao_lidas": 0}
    itens = notificacoes_visiveis()
    return {
        "notificacoes_topo": itens[:8],
        "notificacoes_nao_lidas": sum(1 for n in itens if not n.lida),
    }


# =========================================================
# ASSINATURA
# =========================================================


@app.route("/assinar/<token>")
def assinar(token):

    return render_template("utils/assinatura.html", token=token)


# =========================================================
# CENTRAL DE NOTIFICAÇÕES
# =========================================================


@app.route("/api/avisos-globais")
@login_required
def api_avisos_globais():
    """Retorna apenas avisos da administração destinados ao funcionário atual.

    Avisos globais usam o mesmo armazenamento das notificações, mas ficam fora
    do sino e são exibidos somente pelo modal global.
    """
    itens = (
        Notificacao.query.filter_by(
            destinatario_id=current_user.id,
            tipo="broadcast",
            lida=False,
        )
        .order_by(Notificacao.criada_em.asc())
        .limit(20)
        .all()
    )
    return jsonify({
        "avisos": [
            {
                "id": n.id,
                "titulo": n.titulo,
                "mensagem": n.mensagem,
                "voz": bool(getattr(n, "voz", False)),
                "criada_em": n.criada_em.strftime("%d/%m/%Y %H:%M") if n.criada_em else "",
            }
            for n in itens
        ]
    })


@app.route("/avisos-globais/<int:aviso_id>/ler", methods=["POST"])
@login_required
def marcar_aviso_global_lido(aviso_id):
    aviso = Notificacao.query.get_or_404(aviso_id)
    if aviso.tipo != "broadcast" or aviso.destinatario_id != current_user.id:
        abort(403)
    aviso.lida = True
    db1.session.commit()
    return jsonify({"ok": True})


@app.route("/api/notificacoes")
@login_required
def api_notificacoes():
    itens = notificacoes_visiveis()
    return jsonify(
        {
            "nao_lidas": sum(1 for n in itens if not n.lida),
            "notificacoes": [
                {
                    "id": n.id,
                    "titulo": n.titulo,
                    "mensagem": n.mensagem,
                    "tipo": n.tipo,
                    "voz": bool(getattr(n, "voz", False)),
                    "link": n.link,
                    "lida": n.lida,
                    "criada_em": (
                        n.criada_em.strftime("%d/%m/%Y %H:%M") if n.criada_em else ""
                    ),
                }
                for n in itens
            ],
        }
    )


@app.route("/notificacoes/<int:notificacao_id>/ler", methods=["POST"])
@login_required
def marcar_notificacao_lida(notificacao_id):
    n = Notificacao.query.get_or_404(notificacao_id)
    visiveis = {x.id for x in notificacoes_visiveis()}
    if n.id not in visiveis:
        abort(403)
    n.lida = True
    db1.session.commit()
    return jsonify({"ok": True})


@app.route("/notificacoes/ler-todas", methods=["POST"])
@login_required
def marcar_todas_notificacoes_lidas():
    for n in notificacoes_visiveis():
        n.lida = True
    db1.session.commit()
    return jsonify({"ok": True})


# =========================================================
# CENTRAL DE OPERAÇÕES
# =========================================================


def obter_stats_central():
    """Métricas operacionais compactas usadas pelo Controle do sistema."""
    inicio = inicio_dia_brasilia_utc()
    return {
        "pacientes_hoje": Recepcao.query.filter(
            Recepcao.horario_chegada >= inicio
        ).count(),
        "atendimentos_hoje": Medico.query.filter(
            Medico.horario_de_finalizacao >= inicio,
            Medico.finalizado_medico.is_(True),
        ).count(),
        "aguardando": Recepcao.query.filter(
            Recepcao.finalizado.is_(False),
            Recepcao.destino.in_(["Triagem", "Medico"]),
        ).count(),
        "suporte_abertos": ChamadoSuporte.query.filter(
            ChamadoSuporte.status == "Aberto"
        ).count(),
        "suporte_andamento": ChamadoSuporte.query.filter(
            ChamadoSuporte.status == "Em atendimento"
        ).count(),
        "suporte_criticos": ChamadoSuporte.query.filter(
            ChamadoSuporte.prioridade == "Crítica",
            ChamadoSuporte.status.in_(["Aberto", "Em atendimento"]),
        ).count(),
    }


@app.route("/central_operacoes")
@login_required
def central_operacoes():
    # Compatibilidade com links antigos: a Central agora faz parte do Controle.
    require_role("administrador")
    return redirect(url_for("admin_controle"))


@app.route("/api/central_operacoes")
@login_required
def api_central_operacoes():
    require_role("administrador")
    return jsonify(
        {
            "sistema": "online",
            "banco": "online",
            "painel": "online",
            **obter_stats_central(),
        }
    )


# =========================================================
# LOGIN
# =========================================================


@app.route("/", methods=["GET", "POST"])
def login():

    form = LoginForm()

    if form.validate_on_submit():

        usuario = form.usuario.data.strip()

        user = Funcionarios.query.filter(db1.func.lower(Funcionarios.usuario) == usuario.lower()).first()

        if user and user.check_senha(form.senha.data):
            login_user(user)
            user.online = True
            user.ultimo_login = datetime.now(timezone.utc)
            try:
                db1.session.commit()
            except Exception:
                db1.session.rollback()
                logout_user()
                logger.exception("Falha ao registrar login do funcionário %s", user.id)
                flash("Não foi possível concluir o login. Tente novamente.", "danger")
                return render_template("login.html", form=form)

            # Cada novo login precisa confirmar o local atual. O último local
            # fica salvo apenas para preencher o formulário.
            session.pop("local_atendimento", None)
            session.pop("next_after_local", None)
            return redirect(url_for("selecionar_local"))

        flash("Usuário ou senha incorretos.", "danger")

    return render_template("login.html", form=form)


# =========================================================
# LOCAL DE ATENDIMENTO
# =========================================================

@app.route("/local-atendimento", methods=["GET", "POST"])
@login_required
def selecionar_local():
    form = LocalAtendimentoForm()
    if request.method == "GET":
        form.local.data = (
            session.get("local_atendimento")
            or current_user.local_atendimento
            or ""
        )

    if form.validate_on_submit():
        local = " ".join((form.local.data or "").split()).strip()
        if len(local) < 2:
            form.local.errors.append("Informe um local válido.")
            return render_template("local_atendimento.html", form=form)
        local = local[:160]
        session["local_atendimento"] = local
        current_user.local_atendimento = local
        try:
            db1.session.commit()
        except Exception:
            db1.session.rollback()
            logger.exception("Falha ao salvar local de atendimento do funcionário %s", current_user.id)
            flash("Não foi possível salvar o local de atendimento. Tente novamente.", "danger")
            return render_template("local_atendimento.html", form=form)
        flash(f"Local de atendimento definido: {local}.", "success")
        destino = session.pop("next_after_local", None)
        if destino and destino.startswith("/") and not destino.startswith("//") and not destino.startswith("/local-atendimento"):
            return redirect(destino)
        return dashboard_por_funcao()

    return render_template("local_atendimento.html", form=form)


@app.route("/local-atendimento/alterar", methods=["GET", "POST"])
@login_required
def alterar_local():
    session.pop("next_after_local", None)
    return redirect(url_for("selecionar_local"))


def dashboard_por_funcao():
    func = normalizar_funcao(current_user.funcao)
    destinos = {
        "administrador": "admin_dashboard",
        "recepcionista": "recepcao_list",
        "medico": "dashboard_medico",
        "enfermeiro": "triagem_dashboard",
        "suporte_ti": "suporte_dashboard",
        "seguranca": "dashboard_seguranca",
    }
    endpoint = destinos.get(func)
    if not endpoint:
        abort(403)
    return redirect(url_for(endpoint))


# =========================================================
# LOGOUT
# =========================================================


@app.route("/sair")
@login_required
def sair():

    current_user.online = False
    current_user.ultimo_logout = datetime.now(timezone.utc)
    db1.session.commit()
    logout_user()
    session.pop("local_atendimento", None)
    session.pop("next_after_local", None)

    return redirect(url_for("login"))


# =========================================================
# ADMIN
# =========================================================


@app.route("/dashboard_admin")
@login_required
def admin_dashboard():

    require_role("administrador")

    inicio = inicio_dia_brasilia_utc()
    agora = datetime.now(timezone.utc)
    dados = Funcionarios.query.order_by(Funcionarios.nome_completo.asc()).all()

    recepcoes_hoje = Recepcao.query.filter(Recepcao.horario_chegada >= inicio).all()
    triagens_hoje = Triagem.query.filter(Triagem.horario_de_triagem >= inicio).all()
    conselheiros_hoje = Medico.query.filter(Medico.horario_de_finalizacao >= inicio).all()

    locais = {}
    for funcionario in dados:
        if funcionario.online and funcionario.local_atendimento:
            locais.setdefault(funcionario.local_atendimento, []).append(funcionario)

    encaminhamentos = [
        r for r in recepcoes_hoje
        if (r.destino or "").strip().lower() in {"triagem", "medico", "encaminhamento"}
        or (r.status or "").lower().startswith("encaminh")
    ]

    suporte_abertos = ChamadoSuporte.query.filter(ChamadoSuporte.status.in_(["Aberto", "Em atendimento", "Aguardando usuário"])).order_by(ChamadoSuporte.criado_em.desc()).all()
    seguranca_ativos = ChamadoSeguranca.query.filter(ChamadoSeguranca.status.in_(["Pendente", "Em atendimento"])).order_by(ChamadoSeguranca.criado_em.desc()).all()

    estatisticas = {
        "funcionarios": len(dados),
        "funcionarios_online": sum(1 for f in dados if f.online),
        "pacientes": Paciente.query.count(),
        "recepcoes_hoje": len(recepcoes_hoje),
        "recepcoes_abertas": sum(1 for r in recepcoes_hoje if not r.finalizado),
        "triagens_hoje": len(triagens_hoje),
        "triagens_pendentes": sum(1 for t in triagens_hoje if not t.finalizado_triagem),
        "conselheiros_hoje": len(conselheiros_hoje),
        "conselheiros_finalizados": sum(1 for m in conselheiros_hoje if m.finalizado_medico),
        "encaminhamentos": len(encaminhamentos),
        "locais_ativos": len(locais),
        "suporte_abertos": sum(1 for c in suporte_abertos if c.status == "Aberto"),
        "suporte_andamento": sum(1 for c in suporte_abertos if c.status == "Em atendimento"),
        "suporte_aguardando": sum(1 for c in suporte_abertos if c.status == "Aguardando usuário"),
        "seguranca_ativos": len(seguranca_ativos),
            }

    return render_template(
        "admin/dashboard_admin.html",
        dados=dados,
        estatisticas=estatisticas,
        locais_ativos=locais,
        encaminhamentos=encaminhamentos[:30],
        suporte_abertos=suporte_abertos[:20],
        seguranca_ativos=seguranca_ativos[:10],
        agora=agora,
    )


# =========================================================
# CONTROLE DO ADMINISTRADOR
# =========================================================


@app.route("/admin/controle")
@login_required
def admin_controle():
    require_role("administrador")
    agora = datetime.now(timezone.utc)
    logs = (
        AcessoLog.query.order_by(AcessoLog.criado_em.desc())
        .limit(120)
        .all()
    )
    return render_template(
        "admin/controle_admin.html",
        estado=carregar_estado_admin(),
        logs=logs,
        arquivo_logs=ultimos_logs_arquivo(120),
        funcionarios=Funcionarios.query.order_by(Funcionarios.nome_completo.asc()).all(),
        agora=agora,
        stats=obter_stats_central(),
    )


@app.route("/admin/controle/aviso", methods=["POST"])
@login_required
def admin_enviar_aviso():
    require_role("administrador")
    titulo = (request.form.get("titulo") or "Aviso da administração").strip()[:160]
    mensagem = (request.form.get("mensagem") or "").strip()[:5000]
    voz = request.form.get("voz") == "on"
    if not mensagem:
        flash("Digite uma mensagem para enviar aos funcionários.", "warning")
        return redirect(url_for("admin_controle"))

    # Cria uma cópia por funcionário para que cada tela tenha seu próprio
    # estado de leitura. O broadcast não aparece no sino de notificações.
    funcionarios = Funcionarios.query.order_by(Funcionarios.nome_completo.asc()).all()
    for usuario in funcionarios:
        criar_notificacao(
            titulo or "Aviso da administração",
            mensagem,
            "broadcast",
            destinatario_id=usuario.id,
            voz=voz,
        )
    db1.session.commit()
    logger.info("AVISO ADMIN | %s | destinatarios=%s | voz=%s", titulo, len(funcionarios), voz)
    flash(f"Aviso enviado para {len(funcionarios)} funcionário(s).", "success")
    return redirect(url_for("admin_controle"))


@app.route("/admin/controle/descanso", methods=["POST"])
@login_required
def admin_modo_descanso():
    require_role("administrador")
    estado = carregar_estado_admin()
    estado["modo_descanso"] = request.form.get("modo_descanso") == "on"
    estado["mensagem_descanso"] = (request.form.get("mensagem_descanso") or ADMIN_STATE_PADRAO["mensagem_descanso"]).strip()[:300]
    salvar_estado_admin(estado)
    logger.info("MODO DESCANSO ADMIN | ativo=%s", estado["modo_descanso"])
    flash("Modo descanso atualizado.", "success")
    return redirect(url_for("admin_controle"))


@app.route("/api/admin/estado")
@login_required
def api_admin_estado():
    require_role("administrador")
    return jsonify(carregar_estado_admin())


@app.route("/api/estado_sistema")
@login_required
def api_estado_sistema():
    estado = carregar_estado_admin()
    return jsonify({"modo_descanso": bool(estado.get("modo_descanso")), "mensagem_descanso": estado.get("mensagem_descanso", "")})


@app.route("/api/admin/logs")
@login_required
def api_admin_logs():
    require_role("administrador")
    limite = max(20, min(_inteiro_seguro(request.args.get("limite"), 120), 300))
    acessos = (
        AcessoLog.query.order_by(AcessoLog.criado_em.desc())
        .limit(limite)
        .all()
    )
    return jsonify({
        "acessos": [
            {
                "quando": horario_local(item.criado_em).strftime("%d/%m/%Y %H:%M:%S") if item.criado_em else "",
                "usuario": item.funcionario_nome or "—",
                "funcao": item.funcao or "—",
                "metodo": item.metodo,
                "caminho": item.caminho,
                "status": item.status_code or 0,
                "ip": item.ip or "—",
            }
            for item in acessos
        ],
        "arquivo": ultimos_logs_arquivo(limite),
    })


# =========================================================
# FUNCIONARIOS
# =========================================================


@app.route("/dashboard_funcionarios")
@login_required
def funcionarios_list():

    require_role("administrador")

    dados = Funcionarios.query.all()

    return render_template("funcionarios/dashboard_funcionarios.html", dados=dados)


# =========================================================
# NOVO FUNCIONARIO
# =========================================================


@app.route("/funcionario/novo", methods=["GET", "POST"])
@login_required
def funcionario_novo():

    require_role("administrador")

    form = FuncionarioForm()

    token = str(uuid.uuid4())

    link_assinatura = url_for("assinar", token=token, _external=True)

    qr = qrcode.make(link_assinatura)

    buffer = BytesIO()
    qr.save(buffer, format="PNG")

    qr_code = base64.b64encode(buffer.getvalue()).decode()
    qr_code = f"data:image/png;base64,{qr_code}"

    if form.validate_on_submit():

        if not form.senha.data:
            flash("Defina uma senha para o novo funcionário.", "danger")
            return render_template(
                "funcionarios/form.html",
                form=form,
                action="Novo",
                qr_code=qr_code,
                token=token,
            )

        usuario_normalizado = (form.usuario.data or "").strip().lower()
        if Funcionarios.query.filter(db1.func.lower(Funcionarios.usuario) == usuario_normalizado).first():
            flash("Este usuário já está cadastrado.", "danger")
            return render_template(
                "funcionarios/form.html",
                form=form,
                action="Novo",
                qr_code=qr_code,
                token=token,
            )

        email_normalizado = (form.email.data or "").strip().lower() or None
        if (
            email_normalizado
            and Funcionarios.query.filter(db1.func.lower(Funcionarios.email) == email_normalizado).first()
        ):
            flash("Este e-mail já está cadastrado.", "danger")
            return render_template(
                "funcionarios/form.html",
                form=form,
                action="Novo",
                qr_code=qr_code,
                token=token,
            )

        funcao_nova = normalizar_funcao(form.funcao.data)
        especialidade = form.especialidade.data if funcao_nova == "medico" else None
        novo_func = Funcionarios(
            nome_completo=form.nome_completo.data.strip(),
            usuario=usuario_normalizado,
            funcao=funcao_nova,
            especialidade=especialidade,
            sexo=form.sexo.data,
            email=email_normalizado,
            telefone=(form.telefone.data or "").strip() or None,
            assinatura=form.assinatura.data,
            assinatura_token=token,
        )

        novo_func.set_senha(form.senha.data)

        try:
            db1.session.add(novo_func)
            db1.session.commit()
        except Exception:
            db1.session.rollback()
            logger.exception("Falha ao criar funcionário")
            flash("Não foi possível criar o funcionário. Verifique os dados e tente novamente.", "danger")
            return render_template(
                "funcionarios/form.html", form=form, action="Novo", qr_code=qr_code, token=token
            )

        flash(f"Funcionário {novo_func.nome_completo} criado com sucesso!", "success")

        return redirect(url_for("funcionarios_list"))

    return render_template(
        "funcionarios/form.html", form=form, action="Novo", qr_code=qr_code, token=token
    )


# =========================================================
# EDITAR FUNCIONARIO
# =========================================================


@app.route("/funcionario/editar/<string:id>", methods=["GET", "POST"])
@login_required
def funcionarios_editar(id):

    require_role("administrador")

    func = Funcionarios.query.get_or_404(id)

    form = FuncionarioForm(obj=func)

    if form.validate_on_submit():

        usuario_normalizado = (form.usuario.data or "").strip().lower()
        other_user = Funcionarios.query.filter(
            db1.func.lower(Funcionarios.usuario) == usuario_normalizado,
            Funcionarios.id != func.id,
        ).first()
        if other_user:
            flash("Este usuário já está cadastrado.", "danger")
            return render_template("funcionarios/form.html", form=form, action="Editar")

        email_normalizado = (form.email.data or "").strip().lower() or None
        if email_normalizado:
            other_email = Funcionarios.query.filter(
                db1.func.lower(Funcionarios.email) == email_normalizado,
                Funcionarios.id != func.id,
            ).first()
            if other_email:
                flash("Este e-mail já está cadastrado.", "danger")
                return render_template(
                    "funcionarios/form.html", form=form, action="Editar"
                )

        func.nome_completo = form.nome_completo.data
        func.usuario = usuario_normalizado
        func.funcao = normalizar_funcao(form.funcao.data)
        func.especialidade = form.especialidade.data if normalizar_funcao(form.funcao.data) == "medico" else None
        func.sexo = form.sexo.data
        func.email = email_normalizado
        func.telefone = (form.telefone.data or "").strip() or None
        func.assinatura = form.assinatura.data

        if form.senha.data:
            func.set_senha(form.senha.data)

        try:
            db1.session.commit()
        except Exception:
            db1.session.rollback()
            logger.exception("Falha ao atualizar funcionário %s", func.id)
            flash("Não foi possível atualizar o funcionário. Verifique os dados e tente novamente.", "danger")
            return render_template("funcionarios/form.html", form=form, action="Editar")

        flash("Funcionário atualizado com sucesso!", "success")

        return redirect(url_for("funcionarios_list"))

    return render_template("funcionarios/form.html", form=form, action="Editar")


# =========================================================
# DASHBOARD RECEPÇÃO
# =========================================================


@app.route("/dashboard_recepcao")
@login_required
def recepcao_list():

    require_role("recepcionista", "administrador")

    dados = Recepcao.query.order_by(Recepcao.horario_chegada.desc()).all()

    return render_template("recepcao/selecionar.html", dados=dados)


# =========================================================
# NOVO ATENDIMENTO RECEPÇÃO
# =========================================================


@app.route("/recepcao/selecionar", methods=["GET", "POST"])
@login_required
def recepcao_selecionar():

    require_role("recepcionista", "administrador")

    pacientes = Paciente.query.order_by(Paciente.nome_completo.asc()).all()

    if request.method == "POST":

        paciente_id = request.form.get("paciente_id")

        paciente = Paciente.query.get_or_404(paciente_id)

        protocolo = f"REC-{datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S')}-{secrets.token_hex(2).upper()}"

        destino_inicial = (request.form.get("destino_inicial") or "TRIAGEM").strip().upper()
        destinos_iniciais = {
            "TRIAGEM": ("Triagem", "Aguardando triagem"),
            "MEDICO": ("Medico", "Aguardando médico"),
        }
        if destino_inicial == "OUTRA":
            outro_destino = (request.form.get("outro_destino") or "").strip()[:100]
            destino_db = outro_destino or "Triagem"
            status_inicial = (
                f"Encaminhado para {destino_db}"
                if outro_destino
                else "Aguardando triagem"
            )
        else:
            destino_db, status_inicial = destinos_iniciais.get(
                destino_inicial, ("Triagem", "Aguardando triagem")
            )

        novo = Recepcao(
            paciente_id=paciente.id,
            local_atendimento=local_atendimento_atual(),
            destino=destino_db,
            horario_chegada=datetime.now(timezone.utc),
            responsavel_recepcao=current_user.nome_completo,
            observacoes_recepcao=(
                request.form.get("observacoes_recepcao") or ""
            ).strip(),
            motivo=request.form.get("motivo", "").strip(),
            urgencia_recepcao=(
                request.form.get("urgencia_recepcao") or "BAIXA"
            ).upper(),
            status=status_inicial,
            protocolo=protocolo,
            chamado=False,
            finalizado=False,
        )

        try:

            db1.session.add(novo)

            db1.session.commit()

            flash("Atendimento iniciado com sucesso!", "success")

            return redirect(url_for("recepcao_list"))

        except Exception as e:

            db1.session.rollback()

            logger.exception("Falha ao iniciar atendimento")
            flash("Não foi possível iniciar o atendimento. Verifique os dados e tente novamente.", "danger")

    return render_template("recepcao/form.html", pacientes=pacientes)


# =========================================================
# TRIAGEM
# =========================================================


@app.route("/fila/triagem")
@login_required
def fila_triagem():
    require_role("enfermeiro", "administrador")
    pacientes = (
        Recepcao.query.outerjoin(Triagem)
        .filter(Recepcao.finalizado.is_(False), Recepcao.destino == "Triagem")
        .filter((Triagem.id.is_(None)) | (Triagem.finalizado_triagem.is_(False)))
        .order_by(Recepcao.horario_chegada.asc())
        .all()
    )
    return jsonify({"total": len(pacientes), "ids": [p.id for p in pacientes]})


@app.route("/fila/medico")
@login_required
def fila_medico():
    require_role("medico", "médico", "administrador")
    pacientes = (
        Recepcao.query.outerjoin(Triagem, Recepcao.id == Triagem.recepcao_id)
        .outerjoin(Medico, Recepcao.id == Medico.recepcao_id)
        .filter(
            db1.or_(Triagem.id.is_(None), Triagem.finalizado_triagem.is_(True)),
            Recepcao.finalizado.is_(False),
            Recepcao.destino == "Medico",
        )
        .filter((Medico.id.is_(None)) | (Medico.finalizado_medico.is_(False)))
        .order_by(Triagem.horario_de_triagem.asc())
        .all()
    )
    return jsonify({"total": len(pacientes), "ids": [p.id for p in pacientes]})




@app.route("/triagem")
@login_required
def triagem_dashboard():

    require_role("enfermeiro", "administrador")

    pacientes = (
        Recepcao.query.outerjoin(Triagem)
        .filter(Recepcao.finalizado == False)
        .filter(Recepcao.destino == "Triagem")
        .filter((Triagem.id == None) | (Triagem.finalizado_triagem == False))
        .order_by(Recepcao.horario_chegada.asc())
        .all()
    )

    return render_template("triagem/dashboard_triagem.html", pacientes=pacientes)


# =========================================================
# NOVA TRIAGEM
# =========================================================


@app.route("/triagem/novo", methods=["GET", "POST"])
@login_required
def triagem_novo(recepcao_id=None):

    require_role("enfermeiro", "administrador")

    form = TriagemForm()

    pacientes_disponiveis = (
        Recepcao.query.outerjoin(Triagem)
        .filter(Recepcao.finalizado.is_(False), Recepcao.destino == "Triagem")
        .filter((Triagem.id.is_(None)) | (Triagem.finalizado_triagem.is_(False)))
        .order_by(Recepcao.horario_chegada.asc())
        .all()
    )

    form.recepcao_id.choices = [
        (p.id, f"{p.paciente.nome_completo} ({p.id})") for p in pacientes_disponiveis
    ]
    if recepcao_id is not None and request.method == "GET":
        form.recepcao_id.data = recepcao_id

    if form.validate_on_submit():

        triagem = Triagem(
            recepcao_id=form.recepcao_id.data,
            ocupacao=form.ocupacao.data,
            temperatura=form.temperatura.data,
            freq_cardiaca=form.freq_cardiaca.data,
            freq_respiratoria=form.freq_respiratoria.data,
            pressao_arterial=form.pressao_arterial.data,
            saturacao=form.saturacao.data,
            escala_de_dor=form.escala_de_dor.data,
            peso=form.peso.data,
            altura=form.altura.data,
            imc=form.imc.data,
            alergia=form.alergia.data,
            tipo_sanguineo=form.tipo_sanguineo.data,
            gestante=form.gestante.data,
            queixa_principal=form.queixa_principal.data,
            doencas_pre_existentes=form.doencas_pre_existentes.data,
            toma_medicacao=form.toma_medicacao.data,
            cirurgia_realizada=form.cirurgia_realizada.data,
            tabagista=form.tabagista.data,
            bebida_alcoolica=form.bebida_alcoolica.data,
            responsavel_triagem=current_user.nome_completo,
            observacoes_triagem=form.observacoes_triagem.data,
            horario_de_triagem=datetime.now(timezone.utc),
            finalizado_triagem=True,
        )

        try:

            db1.session.add(triagem)
            recepcao = db1.session.get(Recepcao, form.recepcao_id.data)
            if recepcao:
                recepcao.destino = "Medico"
                recepcao.status = "Aguardando médico"
                recepcao.chamado = False
                recepcao.finalizado = False

            db1.session.commit()

            flash(
                f"Triagem de {recepcao.paciente.nome_completo if recepcao else 'paciente'} finalizada. Paciente encaminhado ao médico.",
                "success",
            )

            return redirect(url_for("triagem_dashboard"))

        except Exception as e:

            db1.session.rollback()

            logger.exception("Falha ao salvar triagem")
            flash("Não foi possível salvar a triagem. Verifique os dados e tente novamente.", "danger")

    return render_template("triagem/form.html", form=form, action="Finalizar")


@app.route("/triagem/<int:id>/editar", methods=["GET", "POST"])
@login_required
def triagem_editar(id):
    require_role("enfermeiro", "administrador")
    triagem = Triagem.query.get_or_404(id)
    form = TriagemForm(obj=triagem)
    form.recepcao_id.choices = [
        (
            triagem.recepcao_id,
            f"{triagem.recepcao.paciente.nome_completo} ({triagem.recepcao_id})",
        )
    ]

    if form.validate_on_submit():
        form.populate_obj(triagem)
        triagem.responsavel_triagem = current_user.nome_completo
        triagem.horario_de_triagem = datetime.now(timezone.utc)
        db1.session.commit()
        flash("Triagem atualizada com sucesso.", "success")
        return redirect(url_for("triagem_dashboard"))

    return render_template("triagem/form.html", form=form, action="Editar")


@app.route("/triagem/<int:id>/excluir", methods=["POST"])
@login_required
def triagem_excluir(id):
    require_role("enfermeiro", "administrador")
    triagem = Triagem.query.get_or_404(id)
    recepcao = triagem.recepcao
    db1.session.delete(triagem)
    if recepcao and not recepcao.finalizado:
        recepcao.destino = "Triagem"
        recepcao.status = "Aguardando triagem"
        recepcao.chamado = False
    db1.session.commit()
    flash("Triagem excluída.", "warning")
    return redirect(url_for("triagem_dashboard"))


# =========================================================
# PACIENTES
# =========================================================


@app.route("/paciente/<string:id>/historico")
@login_required
def paciente_historico(id):
    require_role("recepcionista", "enfermeiro", "medico", "administrador")
    paciente = Paciente.query.get_or_404(id)
    atendimentos = (
        Recepcao.query.filter_by(paciente_id=paciente.id)
        .order_by(Recepcao.horario_chegada.desc())
        .all()
    )
    itens = []
    for r in atendimentos:
        tri = r.triagem
        med = r.medico
        itens.append(
            {
                "id": r.id,
                "protocolo": r.protocolo,
                "data": (
                    filtro_horario_brasilia(r.horario_chegada)
                    if r.horario_chegada
                    else "—"
                ),
                "status": r.status or "—",
                "destino": r.destino or "—",
                "urgencia": r.urgencia_recepcao or "—",
                "motivo": r.motivo or r.observacoes_recepcao or "—",
                "recepcao": {
                    "responsavel": r.responsavel_recepcao or "—",
                    "observacoes": r.observacoes_recepcao or "—",
                },
                "triagem": {
                    "finalizada": bool(tri and tri.finalizado_triagem),
                    "responsavel": tri.responsavel_triagem if tri else "—",
                    "data": (
                        filtro_horario_brasilia(tri.horario_de_triagem)
                        if tri and tri.horario_de_triagem
                        else "—"
                    ),
                    "queixa": tri.queixa_principal if tri else "—",
                    "temperatura": tri.temperatura if tri else "—",
                    "pressao": tri.pressao_arterial if tri else "—",
                    "fc": tri.freq_cardiaca if tri else "—",
                    "fr": tri.freq_respiratoria if tri else "—",
                    "peso": tri.peso if tri else "—",
                    "altura": tri.altura if tri else "—",
                    "saturacao": tri.saturacao if tri else "—",
                    "dor": tri.escala_de_dor if tri else None,
                    "alergia": tri.alergia if tri else "—",
                    "medicacao": tri.toma_medicacao if tri else "—",
                    "doencas": tri.doencas_pre_existentes if tri else "—",
                    "observacoes": tri.observacoes_triagem if tri else "—",
                },
                "medico": {
                    "finalizado": bool(med and med.finalizado_medico),
                    "responsavel": med.responsavel_medico if med else "—",
                    "data": (
                        filtro_horario_brasilia(med.horario_de_finalizacao)
                        if med and med.horario_de_finalizacao
                        else "—"
                    ),
                    "diagnostico": med.diagnostico if med else "—",
                    "prescricao": med.prescricao if med else "—",
                    "cid": med.cid if med else "—",
                    "feedback": med.feedback if med else "—",
                    "observacoes": med.observacoes_medico if med else "—",
                },
            }
        )
    return jsonify(
        {
            "paciente": {
                "id": paciente.id,
                "nome": paciente.nome_completo,
                "documento": paciente.documento or "Não informado",
                "data_nascimento": (
                    paciente.data_nascimento.strftime("%d/%m/%Y")
                    if paciente.data_nascimento
                    else "Não informado"
                ),
                "sexo": paciente.sexo or "Não informado",
                "contato": paciente.contato or "Não informado",
                "email": paciente.email or "Não informado",
                "usuario": paciente.usuario or "Não informado",
                "responsavel": paciente.responsavel or "Não informado",
                "observacoes": paciente.observacoes_cadastro or "Sem observações",
            },
            "atendimentos": itens,
        }
    )


@app.route("/dashboard_pacientes")
@login_required
def dashboard_pacientes():

    require_role("administrador", "recepcionista")

    dados = Paciente.query.order_by(Paciente.nome_completo.asc()).all()

    return render_template("pacientes/dashboard_pacientes.html", dados=dados)


# =========================================================
# NOVO PACIENTE
# =========================================================


@app.route("/paciente/novo", methods=["GET", "POST"])
@login_required
def paciente_novo():

    require_role("administrador", "recepcionista")

    form = PacienteForm()


    # =====================================================
    # ASSINATURA / QR CODE
    # =====================================================

    token = str(uuid.uuid4())

    link_assinatura = url_for("assinar", token=token, _external=True)

    qr = qrcode.make(link_assinatura)

    buffer = BytesIO()
    qr.save(buffer, format="PNG")

    qr_code = base64.b64encode(buffer.getvalue()).decode()

    qr_code = f"data:image/png;base64,{qr_code}"

    # =====================================================
    # SALVAR PACIENTE
    # =====================================================

    if form.validate_on_submit():

        # Normaliza os campos
        usuario = (form.usuario.data or "").strip().lower()
        email = (form.email.data or "").strip().lower()

        # =================================================
        # VERIFICA USUÁRIO
        # =================================================

        if usuario:

            usuario_existente = Paciente.query.filter(db1.func.lower(Paciente.usuario) == usuario.lower()).first()

            if usuario_existente:

                flash("Usuário já cadastrado.", "danger")

                return render_template(
                    "pacientes/form.html",
                    form=form,
                    action="Novo",
                    qr_code=qr_code,
                    token=token,
                )

        # =================================================
        # VERIFICA E-MAIL
        # =================================================

        if email:

            email_existente = Paciente.query.filter(db1.func.lower(Paciente.email) == email.lower()).first()

            if email_existente:

                flash("E-mail já cadastrado.", "danger")

                return render_template(
                    "pacientes/form.html",
                    form=form,
                    action="Novo",
                    qr_code=qr_code,
                    token=token,
                )

        # =================================================
        # FOTO
        # =================================================

        foto_path = None

        if form.foto.data and form.foto.data.filename:
            try:
                foto_path = salvar_imagem_upload(form.foto.data)
            except ValueError as exc:
                flash(str(exc), "danger")
                return render_template(
                    "pacientes/form.html",
                    form=form,
                    action="Novo",
                    qr_code=qr_code,
                    token=token,
                )

        # =================================================
        # CRIA PACIENTE
        # =================================================

        novo = Paciente(
            nome_completo=form.nome_completo.data,
            data_nascimento=form.data_nascimento.data,
            sexo=form.sexo.data,
            contato=form.contato.data,
            documento=form.documento.data,
            observacoes_cadastro=(form.observacoes_cadastro.data),
            responsavel=current_user.nome_completo,
            responsavel_cadastro=(current_user.nome_completo),
            email=email or None,
            usuario=usuario or None,
            assinatura=form.assinatura.data,
            assinatura_token=token,
            foto=foto_path,
        )

        # =================================================
        # SENHA
        # =================================================

        if form.senha.data:

            novo.set_senha(form.senha.data)

        # =================================================
        # SALVA NO BANCO
        # =================================================

        try:
            db1.session.add(novo)
            db1.session.commit()
        except Exception:
            db1.session.rollback()
            if foto_path:
                try:
                    caminho_foto = os.path.join(
                        app.config["UPLOAD_FOLDER"], os.path.basename(foto_path)
                    )
                    if os.path.isfile(caminho_foto):
                        os.remove(caminho_foto)
                except OSError:
                    logger.warning("Não foi possível limpar foto após rollback do paciente")
            logger.exception("Falha ao cadastrar paciente")
            flash("Não foi possível cadastrar o paciente. Verifique os dados e tente novamente.", "danger")
            return render_template(
                "pacientes/form.html",
                form=form,
                action="Novo",
                qr_code=qr_code,
                token=token,
            )

        # =================================================
        # SUCESSO
        # =================================================

        flash("Paciente criado com sucesso!", "success")

        return redirect(url_for("dashboard_pacientes"))

    # =====================================================
    # FORMULÁRIO
    # =====================================================

    return render_template(
        "pacientes/form.html", form=form, action="Novo", qr_code=qr_code, token=token
    )


# =========================================================
# EDITAR PACIENTE
# =========================================================


@app.route("/paciente/editar/<string:id>", methods=["GET", "POST"])
@login_required
def paciente_editar(id):

    require_role("administrador", "recepcionista")

    paciente = Paciente.query.get_or_404(id)

    form = PacienteForm(obj=paciente)


    if form.validate_on_submit():

        # =================================================
        # NORMALIZA CAMPOS OPCIONAIS
        # =================================================

        usuario = (form.usuario.data or "").strip().lower() or None
        email = (form.email.data or "").strip().lower() or None

        # =================================================
        # VERIFICA USUÁRIO DUPLICADO
        # =================================================

        if usuario:

            other_user = Paciente.query.filter(
                db1.func.lower(Paciente.usuario) == usuario.lower(),
                Paciente.id != paciente.id,
            ).first()

            if other_user:

                flash("Este usuário já está cadastrado.", "danger")

                return render_template(
                    "pacientes/form.html", form=form, action="Editar"
                )

        # =================================================
        # VERIFICA E-MAIL DUPLICADO
        # =================================================

        if email:

            other_email = Paciente.query.filter(
                db1.func.lower(Paciente.email) == email.lower(),
                Paciente.id != paciente.id,
            ).first()

            if other_email:

                flash("Este e-mail já está cadastrado.", "danger")

                return render_template(
                    "pacientes/form.html", form=form, action="Editar"
                )

        # =================================================
        # ATUALIZA DADOS
        # =================================================

        paciente.nome_completo = form.nome_completo.data
        paciente.data_nascimento = form.data_nascimento.data
        paciente.sexo = form.sexo.data
        paciente.contato = form.contato.data
        paciente.documento = form.documento.data
        paciente.observacoes_cadastro = form.observacoes_cadastro.data
        paciente.email = email
        paciente.usuario = usuario

        # =================================================
        # ATUALIZA SENHA SOMENTE SE INFORMADA
        # =================================================

        if form.senha.data:
            paciente.set_senha(form.senha.data)

        # =================================================
        # FOTO
        # =================================================

        arquivo = form.foto.data
        foto_antiga = paciente.foto
        nova_foto = None

        if arquivo and arquivo.filename:
            try:
                nova_foto = salvar_imagem_upload(arquivo)
                paciente.foto = nova_foto
            except ValueError as exc:
                flash(str(exc), "danger")
                return render_template("pacientes/form.html", form=form, action="Editar")

        # =================================================
        # SALVA NO BANCO
        # =================================================

        try:

            db1.session.commit()

        except Exception as exc:

            db1.session.rollback()

            logger.exception("Falha ao atualizar paciente %s", paciente.id)
            flash("Não foi possível atualizar o paciente. Verifique os dados e tente novamente.", "danger")

            return render_template("pacientes/form.html", form=form, action="Editar")

        flash("Paciente atualizado com sucesso!", "success")

        return redirect(url_for("dashboard_pacientes"))

    return render_template("pacientes/form.html", form=form, action="Editar")


# =========================================================
# EXCLUIR PACIENTE
# =========================================================


@app.route("/paciente/excluir/<string:id>", methods=["POST"])
@login_required
def paciente_excluir(id):

    require_role("administrador")

    paciente = Paciente.query.get_or_404(id)

    try:
        recepcoes = Recepcao.query.filter_by(paciente_id=paciente.id).all()

        for recepcao in recepcoes:


            triagem = Triagem.query.filter_by(recepcao_id=recepcao.id).first()
            if triagem:
                db1.session.delete(triagem)

            medico = Medico.query.filter_by(recepcao_id=recepcao.id).first()
            if medico:
                db1.session.delete(medico)


            db1.session.delete(recepcao)


        foto = paciente.foto
        db1.session.delete(paciente)
        db1.session.commit()

        if foto:
            try:
                caminho_foto = os.path.join(app.config["UPLOAD_FOLDER"], os.path.basename(foto))
                if os.path.isfile(caminho_foto):
                    os.remove(caminho_foto)
            except OSError:
                logger.warning("Não foi possível remover foto do paciente %s", paciente.id)

    except Exception as exc:
        db1.session.rollback()
        logger.exception("Falha ao excluir paciente %s", paciente.id)
        flash("Não foi possível excluir o paciente com segurança.", "danger")
        return redirect(url_for("dashboard_pacientes"))

    flash("Paciente e seu histórico de atendimento foram excluídos.", "warning")
    return redirect(url_for("dashboard_pacientes"))


# =========================================================
# EXCLUIR FUNCIONARIO
# =========================================================


@app.route("/funcionario/excluir/<string:id>", methods=["POST"])
@login_required
def funcionarios_excluir(id):

    require_role("administrador")

    func = Funcionarios.query.get_or_404(id)

    db1.session.delete(func)

    db1.session.commit()

    flash("Funcionário excluído com sucesso!", "warning")

    return redirect(url_for("funcionarios_list"))


# =========================================================
# ENCAMINHAMENTO DA RECEPÇÃO
# =========================================================


@app.route("/recepcao/encaminhar/<int:recepcao_id>", methods=["POST"])
@login_required
def recepcao_encaminhar(recepcao_id):
    require_role("recepcionista", "administrador")
    recepcao = Recepcao.query.get_or_404(recepcao_id)
    destino = (request.form.get("destino_encaminhamento") or "").strip().upper()
    motivo = (request.form.get("motivo_encaminhamento") or "").strip()[:2000]
    outro = (request.form.get("outro_destino") or "").strip()[:100]
    mapa = {
        "TRIAGEM": ("Triagem", "Aguardando triagem", "triagem_dashboard"),
        "MEDICO": ("Medico", "Aguardando médico", "dashboard_medico"),
    }
    if recepcao.finalizado:
        flash("Não é possível encaminhar um atendimento já finalizado.", "warning")
        return redirect(url_for("recepcao_list"))
    if destino == "OUTRA":
        if not outro:
            flash("Informe a área ou setor para o encaminhamento.", "warning")
            return redirect(url_for("recepcao_list"))
        destino_db, status, rota = outro, f"Encaminhado para {outro}", None
    elif destino in mapa:
        destino_db, status, rota = mapa[destino]
    else:
        flash("Encaminhamento inválido para este atendimento.", "warning")
        return redirect(url_for("recepcao_list"))
    recepcao.destino = destino_db
    recepcao.status = status
    recepcao.chamado = False
    recepcao.finalizado = False
    if motivo:
        texto = recepcao.observacoes_recepcao or ""
        recepcao.observacoes_recepcao = (texto + ("\n" if texto else "") + f"Encaminhamento da recepção: {motivo}")[:5000]
    if rota:
        notificar_funcao("enfermeiro" if destino == "TRIAGEM" else "medico", "Novo encaminhamento", f"{recepcao.paciente.nome_completo} foi encaminhado pela recepção.", "info", url_for(rota))
    db1.session.commit()
    flash(f"Paciente {recepcao.paciente.nome_completo} encaminhado com sucesso.", "success")
    return redirect(url_for("recepcao_list"))




# =========================================================
# DASHBOARD MEDICO
# =========================================================


@app.route("/dashboard_medico")
@login_required
def dashboard_medico():

    require_role("medico", "médico", "administrador")

    pacientes_aguardando = (
        Recepcao.query.outerjoin(Triagem, Recepcao.id == Triagem.recepcao_id)
        .outerjoin(Medico, Recepcao.id == Medico.recepcao_id)
        .filter(db1.or_(Triagem.id.is_(None), Triagem.finalizado_triagem.is_(True)))
        .filter(Recepcao.finalizado.is_(False))
        .filter(Recepcao.destino == "Medico")
        .filter((Medico.id.is_(None)) | (Medico.finalizado_medico.is_(False)))
        .order_by(Triagem.horario_de_triagem.asc(), Recepcao.horario_chegada.asc())
        .all()
    )

    ultimos_atendimentos = (
        Medico.query.filter(Medico.finalizado_medico == True)
        .order_by(Medico.horario_de_finalizacao.desc())
        .limit(5)
        .all()
    )

    atendimentos_hoje = Medico.query.filter(
        Medico.horario_de_finalizacao
        >= inicio_dia_brasilia_utc()
    ).count()

    return render_template(
        "medico/dashboard_medico.html",
        pacientes_aguardando=pacientes_aguardando,
        ultimos_atendimentos=ultimos_atendimentos,
        atendimentos_hoje=atendimentos_hoje,
    )


# =========================================================
# ATENDIMENTO MEDICO
# =========================================================


@app.route("/atender_paciente/<int:paciente_id>", methods=["GET", "POST"])
@login_required
def atender_paciente(paciente_id):
    require_role("medico", "médico", "administrador")

    paciente = Recepcao.query.get_or_404(paciente_id)

    # Encaminhamento direto da recepção também é válido.
    # Se houver triagem, ela precisa estar finalizada; se não houver, o médico pode atender.
    if paciente.triagem and not paciente.triagem.finalizado_triagem:
        flash("Este paciente ainda possui uma triagem em andamento.", "warning")
        return redirect(url_for("dashboard_medico"))

    if paciente.destino != "Medico":
        flash("Este paciente não está mais na fila médica.", "warning")
        return redirect(url_for("dashboard_medico"))
    if paciente.medico and paciente.medico.finalizado_medico:
        flash("Este atendimento médico já foi finalizado.", "warning")
        return redirect(url_for("dashboard_medico"))

    form = MedicoForm()
    form.preencher_form(paciente)

    if form.validate_on_submit():
        emitir_prescricao = bool(form.emitir_prescricao.data)
        emitir_encaminhamento = bool(form.emitir_encaminhamento.data)
        if emitir_prescricao and not (form.prescricao.data or "").strip():
            flash("Preencha a prescrição antes de finalizar o atendimento.", "warning")
            return render_template("medico/form.html", form=form, paciente=paciente, action="Finalizar", dados_paciente=paciente.paciente, historico_atendimentos=Recepcao.query.filter(Recepcao.paciente_id == paciente.paciente_id).order_by(Recepcao.horario_chegada.desc()).all())
        if emitir_encaminhamento and not (form.encaminhamento_destino.data or "").strip():
            flash("Informe para onde o paciente será encaminhado.", "warning")
            return render_template("medico/form.html", form=form, paciente=paciente, action="Finalizar", dados_paciente=paciente.paciente, historico_atendimentos=Recepcao.query.filter(Recepcao.paciente_id == paciente.paciente_id).order_by(Recepcao.horario_chegada.desc()).all())
        if emitir_encaminhamento and not (form.encaminhamento_motivo.data or "").strip():
            flash("Informe o motivo do encaminhamento.", "warning")
            return render_template("medico/form.html", form=form, paciente=paciente, action="Finalizar", dados_paciente=paciente.paciente, historico_atendimentos=Recepcao.query.filter(Recepcao.paciente_id == paciente.paciente_id).order_by(Recepcao.horario_chegada.desc()).all())

        if not paciente.medico:
            atendimento = Medico(recepcao_id=paciente.id)
            db1.session.add(atendimento)
        else:
            atendimento = paciente.medico
        atendimento.feedback = form.feedback.data or ""
        atendimento.diagnostico = form.diagnostico.data or ""
        atendimento.cid = form.cid.data or ""
        atendimento.prescricao = (form.prescricao.data or "").strip()[:5000] if emitir_prescricao else ""
        atendimento.encaminhamento_destino = (form.encaminhamento_destino.data or "").strip()[:200] if emitir_encaminhamento else ""
        atendimento.encaminhamento_motivo = (form.encaminhamento_motivo.data or "").strip()[:3000] if emitir_encaminhamento else ""
        atendimento.finalizado_medico = True
        atendimento.responsavel_medico = current_user.nome_completo
        atendimento.observacoes_medico = form.observacoes_medico.data or ""
        atendimento.horario_de_finalizacao = datetime.now(timezone.utc)
        paciente.destino = "Encaminhamento" if emitir_encaminhamento else "Finalizado"
        paciente.status = "Encaminhado" if emitir_encaminhamento else "Atendimento finalizado"
        paciente.chamado = False
        paciente.finalizado = not emitir_encaminhamento
        db1.session.commit()
        flash(f"Atendimento de {paciente.paciente.nome_completo} finalizado com sucesso.", "success")
        return redirect(url_for("dashboard_medico"))

    historico_atendimentos = (
        Recepcao.query.filter(Recepcao.paciente_id == paciente.paciente_id)
        .order_by(Recepcao.horario_chegada.desc())
        .all()
    )


    return render_template(
        "medico/form.html",
        form=form,
        paciente=paciente,
        action="Finalizar",
        dados_paciente=paciente.paciente,
        historico_atendimentos=historico_atendimentos,
    )


# =========================================================
# DOCUMENTOS MÉDICOS
# =========================================================


@app.route("/medico/documento/<int:recepcao_id>/<tipo>")
@login_required
def documento_medico(recepcao_id, tipo):
    require_role("medico", "médico", "administrador")
    tipos = {
        "receita": "Receita / prescrição",
        "encaminhamento": "Encaminhamento",
    }
    if tipo not in tipos:
        abort(404)

    atendimento = Recepcao.query.get_or_404(recepcao_id)
    paciente = atendimento.paciente
    dados_medico = atendimento.medico
    medico_nome = (dados_medico.responsavel_medico if dados_medico else "") or current_user.nome_completo
    valor_prescricao = dados_medico.prescricao if dados_medico else ""
    if tipo == "receita" and valor_prescricao:
        try:
            legado = json.loads(valor_prescricao)
            if isinstance(legado, dict) and legado.get("tipo") == "prescricao_v1":
                partes = []
                for chave, rotulo in (("medicamento", "Medicamento"), ("apresentacao", "Apresentação"), ("dose", "Dose"), ("via", "Via"), ("frequencia", "Frequência"), ("duracao", "Duração"), ("quantidade", "Quantidade"), ("orientacoes", "Orientações")):
                    valor = (legado.get(chave) or "").strip()
                    if valor:
                        partes.append(f"{rotulo}: {valor}")
                valor_prescricao = "\n".join(partes)
        except (TypeError, ValueError, json.JSONDecodeError):
            pass

    return render_template(
        "medico/documento.html",
        atendimento=atendimento,
        dados_paciente=paciente,
        tipo=tipo,
        titulo=tipos[tipo],
        medico_nome=medico_nome,
        prescricao=valor_prescricao or "",
        config=carregar_config_painel(),
    )


@app.route("/recepcao/autorizacao-imagem/<int:recepcao_id>")
@login_required
def recepcao_autorizacao_imagem(recepcao_id):
    require_role("recepcionista", "administrador")
    recepcao = Recepcao.query.get_or_404(recepcao_id)
    return render_template(
        "recepcao/autorizacao_imagem.html",
        recepcao=recepcao,
        config=carregar_config_painel(),
        emitida_em=horario_local(datetime.now(timezone.utc)),
    )


@app.route("/creditos")
@login_required
def creditos():
    return render_template("utils/creditos.html")



@app.route("/painel_senha")
@login_required
def painel_senha():
    require_role("administrador")

    pacientes = (
        Recepcao.query.filter(Recepcao.chamado == True)
        .order_by(Recepcao.horario_chamada.desc())
        .limit(10)
        .all()
    )
    return render_template(
        "utils/painel_senha.html",
        pacientes=pacientes,
        config=carregar_config_painel(),
    )


@app.route("/painel_senha/configurar", methods=["GET", "POST"])
@login_required
def configurar_painel_senha():
    require_role("administrador")
    config = carregar_config_painel()

    if request.method == "POST":
        def cor_hex_segura(valor, padrao):
            valor = (valor or "").strip()
            return valor if re.fullmatch(r"#[0-9a-fA-F]{6}", valor) else padrao

        modo = (request.form.get("modo_exibicao") or "principal").strip().lower()
        if modo not in {"decorativa", "principal", "imagem", "logo_colaboradores"}:
            modo = "principal"

        imagem_anterior = config.get("imagem_personalizada") or ""
        logo_anterior = config.get("logo_clinica") or ""
        imagem_nova = imagem_anterior
        logo_nova = logo_anterior

        arquivo_painel = request.files.get("imagem_personalizada")
        arquivo_logo = request.files.get("logo_clinica")
        try:
            if arquivo_painel and arquivo_painel.filename:
                imagem_nova = salvar_imagem_upload(arquivo_painel) or imagem_anterior
            if arquivo_logo and arquivo_logo.filename:
                logo_nova = salvar_imagem_upload(arquivo_logo) or logo_anterior
        except ValueError as exc:
            flash(str(exc), "warning")
            return render_template("utils/config_painel_senha.html", config=config)

        config.update(
            {
                "titulo": (request.form.get("titulo") or "Painel de Atendimento").strip()[:80],
                "subtitulo": (request.form.get("subtitulo") or "Clínica Cuidar & Conectar").strip()[:120],
                "cor_principal": cor_hex_segura(request.form.get("cor_principal"), "#0f172a"),
                "cor_destaque": cor_hex_segura(request.form.get("cor_destaque"), "#14b8a6"),
                "cor_fundo": cor_hex_segura(request.form.get("cor_fundo"), "#08111f"),
                "mostrar_nome": request.form.get("mostrar_nome") == "on",
                "voz": request.form.get("voz") == "on",
                "intervalo_atualizacao": max(2, min(_inteiro_seguro(request.form.get("intervalo_atualizacao"), 5), 60)),
                "tempo_exibicao": max(5, min(_inteiro_seguro(request.form.get("tempo_exibicao"), 15), 120)),
                "modo_exibicao": modo,
                "imagem_personalizada": imagem_nova,
                "logo_clinica": logo_nova,
                "colaboradores": [
                    {"nome": nome.strip()[:100], "cargo": cargo.strip()[:100]}
                    for nome, cargo in zip(request.form.getlist("colaborador_nome"), request.form.getlist("colaborador_cargo"))
                    if nome.strip()
                ],
            }
        )
        salvar_config_painel(config)
        flash("Personalização do painel salva com sucesso.", "success")
        return redirect(url_for("configurar_painel_senha"))

    return render_template("utils/config_painel_senha.html", config=config)


# =========================================================
# CHAMAR PACIENTE
# =========================================================


@app.route("/chamar_paciente/<int:recepcao_id>", methods=["POST"])
@login_required
def chamar_paciente(recepcao_id):
    """Chama o paciente para a sala/local definido na sessão do funcionário.

    O destino do fluxo clínico continua em Recepcao.destino; o local físico
    da chamada é salvo em Recepcao.fila. A sala não é mais digitada no
    momento da chamada: ela vem do local confirmado após o login.
    """
    require_role("recepcionista", "enfermeiro", "administrador", "medico")

    paciente = Recepcao.query.get_or_404(recepcao_id)
    destino_chamada = local_atendimento_atual()

    if not destino_chamada:
        session["next_after_local"] = request.path
        flash("Defina o local de atendimento antes de chamar um paciente.", "warning")
        return redirect(url_for("selecionar_local"))

    if paciente.finalizado:
        flash("Este atendimento já foi finalizado.", "warning")
        return redirect(request.referrer or url_for("recepcao_list"))

    paciente.chamado = True
    paciente.fila = destino_chamada
    paciente.horario_chamada = datetime.now(timezone.utc)
    paciente.status = f"Chamado — dirigir-se para {destino_chamada}"

    destino_fluxo = (paciente.destino or "").strip().lower()
    notificacoes = {
        "triagem": (
            "enfermeiro",
            "Paciente chamado para triagem",
            url_for("triagem_dashboard"),
        ),
        "medico": (
            "medico",
            "Paciente chamado para atendimento médico",
            url_for("dashboard_medico"),
        ),
    }

    if destino_fluxo in notificacoes:
        funcao, titulo, link = notificacoes[destino_fluxo]
        notificar_funcao(
            funcao,
            titulo,
            f"{paciente.paciente.nome_completo} foi chamado para {destino_chamada} · Local de atendimento: {destino_chamada}.",
            "info",
            link,
        )

    db1.session.commit()
    flash(
        f"Paciente {paciente.paciente.nome_completo} chamado para {destino_chamada}.",
        "success",
    )
    return redirect(request.referrer or url_for("recepcao_list"))


# =========================================================
# SEGURANÇA / BOTÃO DE PÂNICO
# =========================================================


@app.route("/seguranca/panico", methods=["POST"])
@login_required
def acionar_panico():
    local = (local_atendimento_atual() or "Não informado").strip()[:160]
    mensagem = (request.form.get("mensagem") or "Solicitação de ajuda de segurança.").strip()[:1000]
    chamado = ChamadoSeguranca(
        solicitante_id=current_user.id, local=local, mensagem=mensagem, status="Pendente"
    )
    db1.session.add(chamado)
    db1.session.flush()
    notificar_funcao(
        "seguranca",
        f"ALERTA DE SEGURANÇA #{chamado.id}",
        f"{current_user.nome_completo} solicitou ajuda. Local: {local}.",
        "danger",
        url_for("dashboard_seguranca"),
    )
    db1.session.commit()
    flash("Segurança foi acionada. Permaneça em local seguro e aguarde a equipe.", "danger")
    return redirect(request.referrer or url_for("dashboard_admin"))


@app.route("/seguranca")
@login_required
def dashboard_seguranca():
    require_role("seguranca", "segurança", "administrador")
    chamados = ChamadoSeguranca.query.order_by(ChamadoSeguranca.criado_em.desc()).limit(100).all()
    ordem_seguranca = {"Pendente": 0, "Em atendimento": 1, "Resolvido": 2, "Cancelado": 3}
    chamados.sort(key=lambda c: (ordem_seguranca.get(c.status, 9), -(c.criado_em.timestamp() if c.criado_em else 0)))
    ativos = [c for c in chamados if c.status in {"Pendente", "Em atendimento"}]
    return render_template("seguranca/dashboard_seguranca.html", chamados=chamados, ativos=ativos)


@app.route("/seguranca/chamado/<int:chamado_id>", methods=["POST"])
@login_required
def atualizar_seguranca(chamado_id):
    require_role("seguranca", "segurança", "administrador")
    chamado = ChamadoSeguranca.query.get_or_404(chamado_id)
    status = (request.form.get("status") or "Em atendimento").strip()
    if status not in {"Pendente", "Em atendimento", "Resolvido", "Cancelado"}:
        abort(400)
    chamado.status = status
    if status in {"Em atendimento", "Resolvido"} and not chamado.atendido_por:
        chamado.atendido_por = current_user.nome_completo
    if status in {"Resolvido", "Cancelado"}:
        chamado.atendido_em = datetime.now(timezone.utc)
    else:
        chamado.atendido_em = None
    db1.session.commit()
    flash(f"Alerta de segurança #{chamado.id} atualizado.", "success")
    return redirect(url_for("dashboard_seguranca"))


# =========================================================
# REABERTURA DE ATENDIMENTO PELO SUPORTE
# =========================================================


def _destino_reabertura(recepcao):
    if recepcao.medico and recepcao.medico.finalizado_medico:
        return "Medico", "Aguardando médico"
    if recepcao.triagem and recepcao.triagem.finalizado_triagem:
        return "Medico", "Aguardando médico"
    return "Triagem", "Aguardando triagem"


@app.route("/suporte/reabrir-atendimento/<int:recepcao_id>", methods=["POST"])
@login_required
def reabrir_atendimento(recepcao_id):
    require_role("suporte_ti", "suporte tecnico", "suporte técnico", "suporte_tecnico", "administrador")
    recepcao = Recepcao.query.get_or_404(recepcao_id)
    if not recepcao.finalizado:
        flash("Este atendimento já está aberto.", "warning")
        return redirect(url_for("suporte_dashboard"))
    destino = (request.form.get("destino") or "AUTO").strip().upper()
    mapa = {
        "TRIAGEM": ("Triagem", "Aguardando triagem"),
        "MEDICO": ("Medico", "Aguardando médico"),
    }
    if destino == "AUTO":
        destino_db, status = _destino_reabertura(recepcao)
    elif destino in mapa:
        destino_db, status = mapa[destino]
    else:
        flash("Destino de reabertura inválido.", "danger")
        return redirect(url_for("suporte_dashboard"))
    motivo = (request.form.get("motivo") or "Reabertura solicitada pelo suporte técnico.").strip()[:2000]
    recepcao.finalizado = False
    recepcao.destino = destino_db
    recepcao.status = status
    recepcao.chamado = False
    recepcao.reaberto_em = datetime.now(timezone.utc)
    recepcao.reaberto_por = current_user.nome_completo
    recepcao.reaberto_motivo = motivo
    recepcao.reaberto_destino = destino_db
    texto = recepcao.observacoes_recepcao or ""
    recepcao.observacoes_recepcao = (texto + ("\n" if texto else "") + f"Reabertura pelo suporte: {motivo}")[:5000]
    db1.session.commit()
    flash(f"Atendimento #{recepcao.id} reaberto em {destino_db.lower()}.", "success")
    return redirect(url_for("suporte_dashboard"))


# =========================================================
# SUPORTE TÉCNICO
# =========================================================


def _funcao_suporte(funcao):
    return normalizar_funcao(funcao) == "suporte_ti"


@app.route("/suporte")
@login_required
def suporte_dashboard():

    eh_suporte = _funcao_suporte(current_user.funcao) or check_role("administrador")

    if eh_suporte:
        base_query = ChamadoSuporte.query
    else:
        base_query = ChamadoSuporte.query.filter_by(solicitante_id=current_user.id)

    status_ordem = {
        "Aberto": 0,
        "Em atendimento": 1,
        "Aguardando usuário": 2,
        "Resolvido": 3,
        "Cancelado": 4,
    }

    chamados = base_query.order_by(ChamadoSuporte.criado_em.desc()).all()

    prioridade_ordem = {"Crítica": 0, "Alta": 1, "Normal": 2, "Baixa": 3}

    def chave_ticket(c):
        return (
            prioridade_ordem.get(c.prioridade, 9),
            c.criado_em or datetime.min.replace(tzinfo=timezone.utc),
        )

    filas = {status: [] for status in status_ordem}
    for chamado in chamados:
        filas.setdefault(chamado.status, []).append(chamado)

    for status in filas:
        filas[status].sort(key=chave_ticket)

    estatisticas = {status: len(filas.get(status, [])) for status in status_ordem}

    historico_reabertura = []
    if eh_suporte:
        historico_reabertura = (
            Recepcao.query.filter(Recepcao.finalizado.is_(True))
            .order_by(Recepcao.horario_chegada.desc())
            .limit(30)
            .all()
        )

    return render_template(
        "suporte/dashboard_suporte.html",
        chamados=chamados,
        filas=filas,
        estatisticas=estatisticas,
        eh_suporte=eh_suporte,
        status_ordem=list(status_ordem.keys()),
        historico_reabertura=historico_reabertura,
    )


@app.route("/suporte/novo", methods=["GET", "POST"])
@login_required
def suporte_novo():

    categorias = [
        "Sistema",
        "Login / acesso",
        "Computador / estação",
        "Impressora",
        "Rede / internet",
        "Painel / chamada",
        "Erro / bug",
        "Outro",
    ]

    prioridades = ["Baixa", "Normal", "Alta", "Crítica"]

    if request.method == "POST":
        titulo = (request.form.get("titulo") or "").strip()
        categoria = (request.form.get("categoria") or "Sistema").strip()
        descricao = (request.form.get("descricao") or "").strip()
        local = (local_atendimento_atual() or "Não informado").strip()
        prioridade = (request.form.get("prioridade") or "Normal").strip()

        if not titulo or not descricao:
            flash("Informe o título e descreva o problema.", "danger")
            return render_template(
                "suporte/novo_chamado.html",
                categorias=categorias,
                prioridades=prioridades,
            )

        if categoria not in categorias:
            categoria = "Outro"
        if prioridade not in prioridades:
            prioridade = "Normal"

        chamado = ChamadoSuporte(
            solicitante_id=current_user.id,
            titulo=titulo[:160],
            categoria=categoria,
            descricao=descricao,
            local=local[:120] or "Não informado",
            prioridade=prioridade,
            status="Aberto",
        )

        db1.session.add(chamado)
        db1.session.flush()
        tipo = (
            "danger"
            if prioridade == "Crítica"
            else ("warning" if prioridade == "Alta" else "info")
        )
        notificar_funcao(
            "suporte tecnico",
            f"Novo chamado #{chamado.id}",
            f"{current_user.nome_completo} abriu: {titulo} · {local} · prioridade {prioridade}.",
            tipo,
            url_for("suporte_dashboard"),
        )
        db1.session.commit()

        flash("Chamado enviado ao suporte técnico.", "success")
        return redirect(url_for("suporte_dashboard"))

    return render_template(
        "suporte/novo_chamado.html",
        categorias=categorias,
        prioridades=prioridades,
    )


@app.route("/suporte/chamado/<int:chamado_id>", methods=["POST"])
@login_required
def suporte_atualizar(chamado_id):

    chamado = ChamadoSuporte.query.get_or_404(chamado_id)
    eh_suporte = _funcao_suporte(current_user.funcao)

    if not eh_suporte and not check_role("administrador"):
        abort(403)

    status = (request.form.get("status") or chamado.status).strip()
    resposta = (request.form.get("resposta") or "").strip()

    status_validos = {
        "Aberto",
        "Em atendimento",
        "Aguardando usuário",
        "Resolvido",
        "Cancelado",
    }

    if status not in status_validos:
        flash("Status de chamado inválido.", "danger")
        return redirect(url_for("suporte_dashboard"))

    chamado.status = status
    chamado.resposta = resposta or chamado.resposta
    chamado.atualizado_em = datetime.now(timezone.utc)

    if status in {"Em atendimento", "Resolvido"} and not chamado.responsavel_id:
        chamado.responsavel_id = current_user.id

    if status == "Resolvido":
        chamado.resolvido_em = datetime.now(timezone.utc)
    else:
        chamado.resolvido_em = None

    if status == "Resolvido":
        notificar_usuario(
            chamado.solicitante_id,
            f"Chamado #{chamado.id} resolvido",
            resposta or "O suporte marcou seu chamado como resolvido.",
            "success",
            url_for("meus_chamados_suporte"),
        )
    elif status == "Aguardando usuário":
        notificar_usuario(
            chamado.solicitante_id,
            f"Chamado #{chamado.id} aguarda você",
            resposta or "O suporte precisa de uma informação adicional.",
            "warning",
            url_for("meus_chamados_suporte"),
        )

    db1.session.commit()

    flash(f"Chamado #{chamado.id} atualizado.", "success")
    return redirect(url_for("suporte_dashboard"))


@app.route("/suporte/meus-chamados")
@login_required
def meus_chamados_suporte():

    chamados = (
        ChamadoSuporte.query.filter_by(solicitante_id=current_user.id)
        .order_by(ChamadoSuporte.criado_em.desc())
        .all()
    )

    return render_template(
        "suporte/meus_chamados.html",
        chamados=chamados,
    )


# =========================================================
# SOCKET
# =========================================================


@socketio.on("assinatura_finalizada")
def assinatura_finalizada(data):
    """Recebe assinatura por token e grava apenas em um registro válido."""
    data = data if isinstance(data, dict) else {}
    token = str(data.get("token") or "").strip()
    imagem = str(data.get("imagem") or "").strip()

    if not re.fullmatch(r"[0-9a-fA-F-]{36}", token) or not imagem.startswith("data:image/png;base64,"):
        emit("assinatura_erro", {"message": "Dados de assinatura inválidos."})
        return

    payload = imagem.split(",", 1)[1]
    if len(payload) > 1_500_000:
        emit("assinatura_erro", {"message": "A assinatura excede o tamanho permitido."})
        return

    try:
        raw = base64.b64decode(payload, validate=True)
        if len(raw) > 1_000_000:
            raise ValueError("assinatura muito grande")
        with Image.open(BytesIO(raw)) as imagem_validada:
            imagem_validada.verify()
    except Exception:
        logger.warning("Assinatura inválida recebida para token %s", token)
        emit("assinatura_erro", {"message": "Não foi possível validar a assinatura."})
        return

    paciente = Paciente.query.filter_by(assinatura_token=token).first()
    funcionario = Funcionarios.query.filter_by(assinatura_token=token).first()
    alvo = paciente or funcionario
    if not alvo:
        emit("assinatura_erro", {"message": "Token de assinatura inválido ou expirado."})
        return

    alvo.assinatura = imagem
    alvo.assinatura_token = None
    try:
        db1.session.commit()
    except Exception:
        db1.session.rollback()
        logger.exception("Falha ao salvar assinatura")
        emit("assinatura_erro", {"message": "Não foi possível salvar a assinatura."})
        return

    emit("assinatura_recebida", {"ok": True})


# =========================================================
# GUIA
# =========================================================


@app.route("/documentacao")
@login_required
def documentacao():
    return render_template("utils/documentacao.html")


@app.route("/guia")
@login_required
def guia():
    return redirect(url_for("documentacao"))


# =========================================================
# ERROS
# =========================================================


@app.after_request
def registrar_acesso(response):
    try:
        if current_user.is_authenticated and request.endpoint not in {
            "static", "api_notificacoes", "api_estado_sistema", "api_admin_logs", "api_admin_estado", "api_central_operacoes"
        }:
            item = AcessoLog(
                funcionario_id=current_user.id,
                funcionario_nome=current_user.nome_completo,
                funcao=current_user.funcao,
                metodo=request.method,
                caminho=request.path[:255],
                status_code=response.status_code,
                ip=(request.headers.get("X-Forwarded-For", request.remote_addr or "" ).split(",")[0].strip())[:64],
            )
            db1.session.add(item)
            db1.session.commit()
            logger.info("ACESSO | %s | %s | %s | %s", current_user.nome_completo, request.method, request.path, response.status_code)
    except Exception as exc:
        db1.session.rollback()
        logger.warning("Falha ao registrar acesso: %s", exc)
    return response


@app.errorhandler(403)
def forbidden(error):
    return (
        render_template(
            "utils/error.html",
            code=403,
            title="Acesso negado",
            message="Você não tem permissão para acessar esta área.",
        ),
        403,
    )


@app.errorhandler(404)
def not_found(error):
    return (
        render_template(
            "utils/error.html",
            code=404,
            title="Página não encontrada",
            message="O endereço solicitado não existe ou foi removido.",
        ),
        404,
    )


@app.errorhandler(500)
def internal_error(error):
    db1.session.rollback()
    logger.exception("Erro interno não tratado: %s", error)
    return (
        render_template(
            "utils/error.html",
            code=500,
            title="Erro interno",
            message="O sistema encontrou um problema inesperado. Tente novamente.",
        ),
        500,
    )


@app.errorhandler(413)
def file_too_large(error):
    flash("A imagem excede o limite de 5 MB.", "danger")
    return redirect(request.referrer or url_for("dashboard_pacientes"))


@app.errorhandler(CSRFError)
def csrf_error(error):
    flash(
        "Sua sessão expirou ou o formulário estava desatualizado. "
        "Por favor, tente novamente.",
        "warning",
    )
    if current_user.is_authenticated:
        return redirect(request.referrer or url_for("login")), 400
    return redirect(url_for("login")), 400

# =========================================================
# HORÁRIOS LOCAIS
# =========================================================
# O banco continua armazenando os timestamps em UTC. A interface
# converte para o horário de Brasília para evitar registros/horários
# exibidos com diferença de fuso.
FUSO_BRASILIA = ZoneInfo("America/Sao_Paulo")


def horario_local(valor):
    if not valor:
        return None
    if valor.tzinfo is None:
        # Registros antigos/SQLite podem chegar sem informação de fuso.
        # Eles foram gravados pelo sistema como UTC.
        valor = valor.replace(tzinfo=timezone.utc)
    return valor.astimezone(FUSO_BRASILIA)


@app.template_filter("horario_brasilia")
def filtro_horario_brasilia(valor):
    local = horario_local(valor)
    return local.strftime("%d/%m/%Y %H:%M") if local else "—"


@app.template_filter("hora_brasilia")
def filtro_hora_brasilia(valor):
    local = horario_local(valor)
    return local.strftime("%H:%M") if local else "--:--"




# =========================================================
# RUN
# =========================================================

if __name__ == "__main__":

    socketio.run(
        app,
        host="0.0.0.0",
        port=int(os.getenv("PORT", "5000")),
        debug=os.getenv("FLASK_DEBUG", "0") == "1",
    )
