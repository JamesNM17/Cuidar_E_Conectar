/* Cuidar & Conectar — interface */
(() => {
  const root = document.body;
  const storageKey = "cc-theme";

  function applyTheme(theme) {
    const light = theme === "light";
    root.classList.toggle("light", light);
    root.dataset.theme = light ? "light" : "dark";
    document.querySelectorAll("[data-theme-label]").forEach(el => {
      el.textContent = light ? "Tema escuro" : "Tema claro";
    });
    document.querySelectorAll("[data-theme-icon]").forEach(el => {
      el.className = light ? "fa-solid fa-moon" : "fa-solid fa-sun";
    });
  }

  window.toggleTheme = () => {
    const next = root.classList.contains("light") ? "dark" : "light";
    localStorage.setItem(storageKey, next);
    applyTheme(next);
  };

  window.toggleSidebar = () => root.classList.toggle("sidebar-open");

  window.closeSidebar = () => root.classList.remove("sidebar-open");

  window.toggleSenha = () => {
    const input = document.getElementById("senha");
    const icon = document.getElementById("toggleSenha");
    if (!input) return;
    const visible = input.type === "text";
    input.type = visible ? "password" : "text";
    if (icon) {
      icon.classList.toggle("fa-eye", visible);
      icon.classList.toggle("fa-eye-slash", !visible);
    }
  };

  document.addEventListener("DOMContentLoaded", () => {
    const saved = localStorage.getItem(storageKey);
    const preferred = window.matchMedia("(prefers-color-scheme: light)").matches ? "light" : "dark";
    applyTheme(saved || preferred);

    document.querySelectorAll(".flash").forEach((flash) => {
      window.setTimeout(() => {
        flash.style.opacity = "0";
        flash.style.transform = "translateY(-5px)";
        window.setTimeout(() => flash.remove(), 220);
      }, 5200);
    });

    const overlay = document.querySelector(".sidebar-overlay");
    if (overlay) overlay.addEventListener("click", window.closeSidebar);

    document.querySelectorAll(".menu a").forEach(link => {
      link.addEventListener("click", () => {
        if (window.innerWidth <= 800) window.closeSidebar();
      });
    });

    document.addEventListener("keydown", event => {
      if (event.key === "Escape") window.closeSidebar();
    });
  });
})();
