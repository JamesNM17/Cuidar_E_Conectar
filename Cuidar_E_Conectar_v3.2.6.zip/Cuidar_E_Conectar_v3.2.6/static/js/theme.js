/* Cuidar & Conectar — gerenciamento global de tema */
(() => {
  "use strict";

  const STORAGE_KEY = "cc-theme";
  const THEMES = {
    LIGHT: "light",
    DARK: "dark",
  };

  const getStoredTheme = () => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      return stored === THEMES.LIGHT || stored === THEMES.DARK ? stored : null;
    } catch {
      return null;
    }
  };

  const getPreferredTheme = () =>
    window.matchMedia?.("(prefers-color-scheme: light)").matches
      ? THEMES.LIGHT
      : THEMES.DARK;

  const getCurrentTheme = () =>
    document.documentElement.dataset.theme ||
    (document.body?.classList.contains("light") ? THEMES.LIGHT : THEMES.DARK);

  const updateThemeControls = (theme) => {
    const light = theme === THEMES.LIGHT;

    document.querySelectorAll("[data-theme-label]").forEach((element) => {
      element.textContent = light ? "Tema escuro" : "Tema claro";
    });

    document.querySelectorAll("[data-theme-icon]").forEach((element) => {
      element.className = light
        ? "fa-solid fa-moon"
        : "fa-solid fa-sun";
    });

    document.querySelectorAll("[data-theme-toggle]").forEach((element) => {
      element.setAttribute("aria-pressed", String(light));
      element.setAttribute(
        "aria-label",
        light ? "Ativar modo escuro" : "Ativar modo claro",
      );
    });
  };

  const updateThemeColor = (theme) => {
    const meta = document.querySelector('meta[name="theme-color"]');
    if (!meta) return;
    meta.setAttribute("content", theme === THEMES.LIGHT ? "#f3f6fb" : "#0b1020");
  };

  const applyTheme = (theme) => {
    const normalized =
      theme === THEMES.LIGHT ? THEMES.LIGHT : THEMES.DARK;

    const root = document.documentElement;
    root.dataset.theme = normalized;
    root.classList.toggle("light", normalized === THEMES.LIGHT);
    root.classList.toggle("dark", normalized === THEMES.DARK);

    if (document.body) {
      document.body.dataset.theme = normalized;
      document.body.classList.toggle("light", normalized === THEMES.LIGHT);
      document.body.classList.toggle("dark", normalized === THEMES.DARK);
    }

    updateThemeControls(normalized);
    updateThemeColor(normalized);

    return normalized;
  };

  window.setTheme = (theme) => {
    const normalized = applyTheme(theme);
    try {
      localStorage.setItem(STORAGE_KEY, normalized);
    } catch {
      /* A preferência continua válida durante a sessão. */
    }
  };

  window.toggleTheme = () => {
    const current = getCurrentTheme();
    window.setTheme(
      current === THEMES.LIGHT ? THEMES.DARK : THEMES.LIGHT,
    );
  };

  window.toggleSidebar = () =>
    document.body?.classList.toggle("sidebar-open");

  window.closeSidebar = () =>
    document.body?.classList.remove("sidebar-open");

  window.toggleSenha = () => {
    const input = document.getElementById("senha");
    const icon = document.getElementById("toggleSenha");

    if (!input) return;

    const visible = input.type === "text";
    input.type = visible ? "password" : "text";

    if (icon) {
      icon.classList.toggle("fa-eye", visible);
      icon.classList.toggle("fa-eye-slash", !visible);
    }
  };

  const initializeTheme = () => {
    const theme =
      getStoredTheme() ||
      document.documentElement.dataset.theme ||
      getPreferredTheme();

    applyTheme(theme);

    document.querySelectorAll(".flash").forEach((flash) => {
      window.setTimeout(() => {
        flash.style.opacity = "0";
        flash.style.transform = "translateY(-5px)";
        window.setTimeout(() => flash.remove(), 220);
      }, 5200);
    });

    const overlay = document.querySelector(".sidebar-overlay");
    if (overlay) {
      overlay.addEventListener("click", window.closeSidebar);
    }

    document.querySelectorAll(".menu a").forEach((link) => {
      link.addEventListener("click", () => {
        if (window.innerWidth <= 800) window.closeSidebar();
      });
    });

    document.addEventListener("keydown", (event) => {
      if (event.key === "Escape") window.closeSidebar();
    });
  };

  /* O tema já foi aplicado no <head>; aqui apenas sincronizamos a UI. */
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initializeTheme, { once: true });
  } else {
    initializeTheme();
  }
})();
