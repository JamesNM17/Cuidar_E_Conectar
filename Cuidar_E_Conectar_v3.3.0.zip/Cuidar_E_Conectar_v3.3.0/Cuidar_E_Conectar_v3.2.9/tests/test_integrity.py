"""Auditoria estática mínima do Cuidar & Conectar.

Executar com: python tests/test_integrity.py
Não exige dependências do Flask.
"""
from pathlib import Path
import ast
import re
import sqlite3
import sys

ROOT = Path(__file__).resolve().parents[1]


def fail(message):
    print(f"[FALHA] {message}")
    raise SystemExit(1)


def main():
    py_files = list(ROOT.rglob("*.py"))
    for path in py_files:
        try:
            ast.parse(path.read_text(encoding="utf-8"))
        except SyntaxError as exc:
            fail(f"Python inválido em {path}: {exc}")

    main_text = (ROOT / "main.py").read_text(encoding="utf-8")
    tree = ast.parse(main_text)

    endpoints = set()
    routes = {}
    for node in tree.body:
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        for decorator in node.decorator_list:
            if (
                isinstance(decorator, ast.Call)
                and isinstance(decorator.func, ast.Attribute)
                and decorator.func.attr == "route"
            ):
                endpoints.add(node.name)
                routes[node.name] = ast.literal_eval(decorator.args[0])

    refs = set()
    for path in (ROOT / "templates").rglob("*.html"):
        text = path.read_text(encoding="utf-8")
        refs.update(re.findall(r"url_for\(\s*['\"]([^'\"]+)['\"]", text))
        if re.search(r'<form\b[^>]*method=["\']POST', text, re.I):
            if "csrf_token()" not in text and "hidden_tag()" not in text:
                fail(f"Formulário POST sem CSRF aparente: {path.relative_to(ROOT)}")

    missing = sorted(ref for ref in refs if ref not in endpoints and ref != "static")
    if missing:
        fail("Endpoints referenciados por templates não existem: " + ", ".join(missing))

    if "/recepcao/encaminhar/<int:recepcao_id>" not in routes.values():
        fail("Rota de encaminhamento da recepção não usa recepcao_id.")

    if "Não foi possível cadastrar o paciente: {exc}" in main_text:
        fail("Exceção interna ainda é exibida no cadastro de paciente.")

    db = ROOT / "instance" / "project.db"
    if db.exists():
        con = sqlite3.connect(db)
        for table, column in (("funcionarios", "local_atendimento"), ("recepcao", "local_atendimento")):
            columns = {row[1] for row in con.execute(f"PRAGMA table_info({table})")}
            # O app faz a migração automaticamente; a ausência no arquivo enviado
            # não é falha, desde que a rotina de migração exista.
            if column not in columns and f'"{column}"' not in main_text:
                fail(f"Migração ausente para {table}.{column}")
        con.close()

    print(f"[OK] Sintaxe Python: {len(py_files)} arquivos")
    print(f"[OK] Rotas Flask descobertas: {len(routes)}")
    print("[OK] Referências url_for e formulários POST auditados")
    print("[OK] Migrações de local de atendimento presentes")
    return 0


if __name__ == "__main__":
    sys.exit(main())
