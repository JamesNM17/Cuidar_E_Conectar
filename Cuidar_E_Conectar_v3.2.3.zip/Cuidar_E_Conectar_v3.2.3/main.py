# =========================================================
# FINALIZADO
# =========================================================

import os
import uuid
import qrcode
import base64
import secrets
import json
from sqlalchemy import inspect as sa_inspect
from flask import (
    Flask,
    render_template,
    redirect,
    url_for,
    abort,
    flash,
    request,
    jsonify,
)
from werkzeug.utils import secure_filename
from flask_socketio import SocketIO, emit
from flask_login import (
    LoginManager,
    login_user,
    logout_user,
    login_required,
    current_user,
)
from flask_admin import Admin
from flask_wtf.csrf import CSRFProtect, CSRFError
from datetime import datetime, timezone
from io import BytesIO
from pathlib import Path

# =========================================================
# DATABASE/MODELS
# =========================================================

from dados1 import db1
from model import (
    Funcionarios,
    Recepcao,
    Triagem,
    Medico,
    Psicologia,
    Paciente,
    AdminRecepcao,
    AdminTriagem,
    AdminMedico,
    AdminFuncionarios,
    Plano,
    PacientePlano,
    VendaPlano,
    Vacinacao,
    ChamadoSuporte,
    Notificacao,
)

# =========================================================
# FORMS
# =========================================================

from forms import (
    FuncionarioForm,
    RecepcaoForm,
    TriagemForm,
    MedicoForm,
    PsicologiaForm,
    LoginForm,
    PacienteForm,
    PlanoForm,
    VacinacaoForm,
)

# =========================================================
# APP
# =========================================================

app = Flask(__name__)

app.config["SQLALCHEMY_DATABASE_URI"] = os.getenv(
    "DATABASE_URL", "sqlite:///project.db"
).replace("postgres://", "postgresql://", 1)
app.config["SECRET_KEY"] = os.getenv("SECRET_KEY") or secrets.token_hex(32)
app.config["UPLOAD_FOLDER"] = os.path.join(app.root_path, "static", "uploads")
app.config["MAX_CONTENT_LENGTH"] = 5 * 1024 * 1024
app.config["SESSION_COOKIE_HTTPONLY"] = True
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"
app.config["REMEMBER_COOKIE_HTTPONLY"] = True
app.config["REMEMBER_COOKIE_SAMESITE"] = "Lax"

os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)

db1.init_app(app)

csrf = CSRFProtect(app)

socketio = SocketIO(app, async_mode="threading")

# =========================================================
# DATABASE CREATE
# =========================================================

with app.app_context():
    db1.create_all()

    try:
        inspector = sa_inspect(db1.engine)
        columns = {c["name"] for c in inspector.get_columns("funcionarios")}
        if "especialidade" not in columns:
            with db1.engine.begin() as conn:
                conn.exec_driver_sql(
                    "ALTER TABLE funcionarios ADD COLUMN especialidade VARCHAR(50)"
                )
    except Exception:

        pass

# =========================================================
# LOGIN MANAGER
# =========================================================

login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = "login"


@login_manager.user_loader
def load_user(user_id):

    try:
        return db1.session.get(Funcionarios, user_id)

    except Exception:
        return None


# =========================================================
# FLASK ADMIN
# =========================================================

admin = Admin(app, name="Painel Clínico")
admin.add_view(AdminRecepcao(Recepcao, db1.session, name="Recepção"))
admin.add_view(AdminTriagem(Triagem, db1.session, name="Triagem"))
admin.add_view(AdminMedico(Medico, db1.session, name="Médico"))
admin.add_view(AdminFuncionarios(Funcionarios, db1.session, name="Funcionários"))

# =========================================================
# HELPERS
# =========================================================

ROLE_ALIASES = {
    "médico": "medico",
    "medico": "medico",
    "suporte tecnico": "suporte_ti",
    "suporte técnico": "suporte_ti",
    "suporte_tecnico": "suporte_ti",
    "suporte_ti": "suporte_ti",
    "vendas": "comercial",
    "vendedor": "comercial",
    "vendas/comercial": "comercial",
    "comercial": "comercial",
}


def normalizar_funcao(funcao):
    valor = (funcao or "").strip().lower()
    return ROLE_ALIASES.get(valor, valor)


def check_role(*roles):
    if not current_user.is_authenticated or not current_user.funcao:
        return False
    funcao_atual = normalizar_funcao(current_user.funcao)
    return funcao_atual in {normalizar_funcao(r) for r in roles}


def require_role(*roles):

    if not check_role(*roles):
        abort(403)


# =========================================================
# HELPERS DE ARQUIVOS
# =========================================================

ALLOWED_IMAGE_EXTENSIONS = {"png", "jpg", "jpeg", "webp"}


def allowed_image(filename):
    return (
        bool(filename)
        and "." in filename
        and filename.rsplit(".", 1)[1].lower() in ALLOWED_IMAGE_EXTENSIONS
    )


# =========================================================
# CONFIGURAÇÃO DO PAINEL DE SENHAS
# =========================================================

PAINEL_CONFIG_PATH = Path(app.root_path) / "painel_config.json"

PAINEL_CONFIG_PADRAO = {
    "titulo": "Painel de Atendimento",
    "subtitulo": "Clínica Cuidar & Conectar",
    "cor_principal": "#0f172a",
    "cor_destaque": "#14b8a6",
    "cor_fundo": "#08111f",
    "mostrar_nome": True,
    "voz": True,
    "intervalo_atualizacao": 5,
    "tempo_exibicao": 15,
}


def carregar_config_painel():
    try:
        if PAINEL_CONFIG_PATH.exists():
            dados = json.loads(PAINEL_CONFIG_PATH.read_text(encoding="utf-8"))
            return {**PAINEL_CONFIG_PADRAO, **dados}
    except (OSError, json.JSONDecodeError):
        pass
    return PAINEL_CONFIG_PADRAO.copy()


def salvar_config_painel(config):
    PAINEL_CONFIG_PATH.write_text(
        json.dumps(config, ensure_ascii=False, indent=2), encoding="utf-8"
    )


def preco_brl(valor):
    try:
        return (
            f"R$ {float(valor):,.2f}".replace(",", "X")
            .replace(".", ",")
            .replace("X", ".")
        )
    except (TypeError, ValueError):
        return "R$ 0,00"


app.jinja_env.filters["brl"] = preco_brl

# =========================================================
# NOTIFICAÇÕES / OPERAÇÃO EM TEMPO REAL
# =========================================================


def criar_notificacao(
    titulo, mensagem, tipo="info", link=None, destinatario_id=None, funcao_destino=None
):
    n = Notificacao(
        titulo=titulo[:160],
        mensagem=mensagem,
        tipo=tipo[:20],
        link=link,
        destinatario_id=destinatario_id,
        funcao_destino=funcao_destino,
    )
    db1.session.add(n)
    return n


def notificar_funcao(funcao, titulo, mensagem, tipo="info", link=None):
    usuarios = Funcionarios.query.filter(Funcionarios.funcao.ilike(funcao)).all()
    for usuario in usuarios:
        criar_notificacao(titulo, mensagem, tipo, link, destinatario_id=usuario.id)


def notificar_usuario(usuario_id, titulo, mensagem, tipo="info", link=None):
    criar_notificacao(titulo, mensagem, tipo, link, destinatario_id=usuario_id)


def notificacoes_visiveis():
    if not current_user.is_authenticated:
        return []
    return (
        Notificacao.query.filter(
            db1.or_(
                Notificacao.destinatario_id == current_user.id,
                db1.and_(
                    Notificacao.destinatario_id.is_(None),
                    Notificacao.funcao_destino.isnot(None),
                    Notificacao.funcao_destino.ilike(current_user.funcao or ""),
                ),
            )
        )
        .order_by(Notificacao.criada_em.desc())
        .limit(20)
        .all()
    )


@app.context_processor
def contexto_notificacoes():
    if not current_user.is_authenticated:
        return {"notificacoes_topo": [], "notificacoes_nao_lidas": 0}
    itens = notificacoes_visiveis()
    return {
        "notificacoes_topo": itens[:8],
        "notificacoes_nao_lidas": sum(1 for n in itens if not n.lida),
    }


# =========================================================
# ASSINATURA
# =========================================================


@app.route("/assinar/<token>")
def assinar(token):

    return render_template("utils/assinatura.html", token=token)


# =========================================================
# CENTRAL DE NOTIFICAÇÕES
# =========================================================


@app.route("/api/notificacoes")
@login_required
def api_notificacoes():
    itens = notificacoes_visiveis()
    return jsonify(
        {
            "nao_lidas": sum(1 for n in itens if not n.lida),
            "notificacoes": [
                {
                    "id": n.id,
                    "titulo": n.titulo,
                    "mensagem": n.mensagem,
                    "tipo": n.tipo,
                    "link": n.link,
                    "lida": n.lida,
                    "criada_em": (
                        n.criada_em.strftime("%d/%m/%Y %H:%M") if n.criada_em else ""
                    ),
                }
                for n in itens
            ],
        }
    )


@app.route("/notificacoes/<int:notificacao_id>/ler", methods=["POST"])
@login_required
def marcar_notificacao_lida(notificacao_id):
    n = Notificacao.query.get_or_404(notificacao_id)
    visiveis = {x.id for x in notificacoes_visiveis()}
    if n.id not in visiveis:
        abort(403)
    n.lida = True
    db1.session.commit()
    return jsonify({"ok": True})


@app.route("/notificacoes/ler-todas", methods=["POST"])
@login_required
def marcar_todas_notificacoes_lidas():
    for n in notificacoes_visiveis():
        n.lida = True
    db1.session.commit()
    return jsonify({"ok": True})


# =========================================================
# CENTRAL DE OPERAÇÕES
# =========================================================


@app.route("/central_operacoes")
@login_required
def central_operacoes():
    require_role("administrador")
    agora = datetime.now(timezone.utc)
    inicio = agora.replace(hour=0, minute=0, second=0, microsecond=0)
    suporte_abertos = ChamadoSuporte.query.filter(
        ChamadoSuporte.status == "Aberto"
    ).count()
    suporte_andamento = ChamadoSuporte.query.filter(
        ChamadoSuporte.status == "Em atendimento"
    ).count()
    suporte_criticos = ChamadoSuporte.query.filter(
        ChamadoSuporte.prioridade == "Crítica",
        ChamadoSuporte.status.in_(["Aberto", "Em atendimento"]),
    ).count()
    stats = {
        "pacientes_hoje": Recepcao.query.filter(
            Recepcao.horario_chegada >= inicio
        ).count(),
        "atendimentos_hoje": Medico.query.filter(
            Medico.horario_de_finalizacao >= inicio, Medico.finalizado_medico.is_(True)
        ).count(),
        "aguardando": Recepcao.query.filter(
            Recepcao.finalizado.is_(False),
            Recepcao.destino.in_(["Triagem", "Medico", "Vacinacao"]),
        ).count(),
        "suporte_abertos": suporte_abertos,
        "suporte_andamento": suporte_andamento,
        "suporte_criticos": suporte_criticos,
        "vacinacoes_hoje": Vacinacao.query.filter(
            Vacinacao.data_aplicacao >= inicio
        ).count(),
    }
    return render_template("admin/central_operacoes.html", stats=stats)


@app.route("/api/central_operacoes")
@login_required
def api_central_operacoes():
    require_role("administrador")
    agora = datetime.now(timezone.utc)
    inicio = agora.replace(hour=0, minute=0, second=0, microsecond=0)
    return jsonify(
        {
            "sistema": "online",
            "banco": "online",
            "painel": "online",
            "pacientes_hoje": Recepcao.query.filter(
                Recepcao.horario_chegada >= inicio
            ).count(),
            "atendimentos_hoje": Medico.query.filter(
                Medico.horario_de_finalizacao >= inicio,
                Medico.finalizado_medico.is_(True),
            ).count(),
            "aguardando": Recepcao.query.filter(
                Recepcao.finalizado.is_(False),
                Recepcao.destino.in_(["Triagem", "Medico", "Vacinacao"]),
            ).count(),
            "suporte_abertos": ChamadoSuporte.query.filter_by(status="Aberto").count(),
            "suporte_criticos": ChamadoSuporte.query.filter(
                ChamadoSuporte.prioridade == "Crítica",
                ChamadoSuporte.status.in_(["Aberto", "Em atendimento"]),
            ).count(),
        }
    )


# =========================================================
# LOGIN
# =========================================================


@app.route("/", methods=["GET", "POST"])
def login():

    form = LoginForm()

    if form.validate_on_submit():

        usuario = form.usuario.data.strip()

        user = Funcionarios.query.filter_by(usuario=usuario).first()

        if user and user.check_senha(form.senha.data):

            login_user(user)
            user.online = True
            user.ultimo_login = datetime.now(timezone.utc)
            db1.session.commit()

            func = (user.funcao or "").strip().lower()

            if func == "administrador":
                return redirect(url_for("admin_dashboard"))

            elif func == "recepcionista":
                return redirect(url_for("recepcao_list"))

            elif normalizar_funcao(func) == "medico":
                return redirect(url_for("dashboard_medico"))

            elif normalizar_funcao(func) == "enfermeiro":
                return redirect(url_for("triagem_dashboard"))

            elif normalizar_funcao(func) == "psicologo":
                return redirect(url_for("dashboard_psicologo"))

            elif normalizar_funcao(func) == "suporte_ti":
                return redirect(url_for("suporte_dashboard"))

            elif normalizar_funcao(func) == "comercial":
                return redirect(url_for("dashboard_vendas"))

            flash("Função inválida.", "warning")

            return redirect(url_for("login"))

        flash("Usuário ou senha incorretos.", "danger")

    return render_template("login.html", form=form)


# =========================================================
# LOGOUT
# =========================================================


@app.route("/sair")
@login_required
def sair():

    current_user.online = False
    current_user.ultimo_logout = datetime.now(timezone.utc)
    db1.session.commit()
    logout_user()

    return redirect(url_for("login"))


# =========================================================
# ADMIN
# =========================================================


@app.route("/dashboard_admin")
@login_required
def admin_dashboard():

    require_role("administrador")

    dados = Funcionarios.query.order_by(Funcionarios.nome_completo.asc()).all()
    estatisticas = {
        "funcionarios": len(dados),
        "pacientes": Paciente.query.count(),
        "recepcoes_abertas": Recepcao.query.filter_by(finalizado=False).count(),
        "triagens_pendentes": Triagem.query.filter_by(finalizado_triagem=False).count(),
        "atendimentos_hoje": Medico.query.filter(
            Medico.horario_de_finalizacao
            >= datetime.now(timezone.utc).replace(
                hour=0, minute=0, second=0, microsecond=0
            )
        ).count(),
        "vacinacoes": Vacinacao.query.count(),
        "psicologia_pendentes": Recepcao.query.filter(
            Recepcao.finalizado.is_(False), Recepcao.destino == "Psicologo"
        ).count(),
    }

    return render_template(
        "admin/dashboard_admin.html",
        dados=dados,
        estatisticas=estatisticas,
    )


# =========================================================
# FUNCIONARIOS
# =========================================================


@app.route("/dashboard_funcionarios")
@login_required
def funcionarios_list():

    require_role("administrador")

    dados = Funcionarios.query.all()

    return render_template("funcionarios/dashboard_funcionarios.html", dados=dados)


# =========================================================
# NOVO FUNCIONARIO
# =========================================================


@app.route("/funcionario/novo", methods=["GET", "POST"])
@login_required
def funcionario_novo():

    require_role("administrador")

    form = FuncionarioForm()

    token = str(uuid.uuid4())

    link_assinatura = url_for("assinar", token=token, _external=True)

    qr = qrcode.make(link_assinatura)

    buffer = BytesIO()
    qr.save(buffer, format="PNG")

    qr_code = base64.b64encode(buffer.getvalue()).decode()
    qr_code = f"data:image/png;base64,{qr_code}"

    if form.validate_on_submit():

        if not form.senha.data:
            flash("Defina uma senha para o novo funcionário.", "danger")
            return render_template(
                "funcionarios/form.html",
                form=form,
                action="Novo",
                qr_code=qr_code,
                token=token,
            )

        if Funcionarios.query.filter_by(usuario=form.usuario.data).first():
            flash("Este usuário já está cadastrado.", "danger")
            return render_template(
                "funcionarios/form.html",
                form=form,
                action="Novo",
                qr_code=qr_code,
                token=token,
            )

        if (
            form.email.data
            and Funcionarios.query.filter_by(email=form.email.data).first()
        ):
            flash("Este e-mail já está cadastrado.", "danger")
            return render_template(
                "funcionarios/form.html",
                form=form,
                action="Novo",
                qr_code=qr_code,
                token=token,
            )

        novo_func = Funcionarios(
            nome_completo=form.nome_completo.data,
            usuario=form.usuario.data,
            funcao=form.funcao.data,
            especialidade=form.especialidade.data,
            sexo=form.sexo.data,
            email=form.email.data,
            telefone=form.telefone.data,
            assinatura=form.assinatura.data,
            assinatura_token=token,
        )

        novo_func.set_senha(form.senha.data)

        db1.session.add(novo_func)
        db1.session.commit()

        flash(f"Funcionário {novo_func.nome_completo} criado com sucesso!", "success")

        return redirect(url_for("funcionarios_list"))

    return render_template(
        "funcionarios/form.html", form=form, action="Novo", qr_code=qr_code, token=token
    )


# =========================================================
# EDITAR FUNCIONARIO
# =========================================================


@app.route("/funcionario/editar/<string:id>", methods=["GET", "POST"])
@login_required
def funcionarios_editar(id):

    require_role("administrador")

    func = Funcionarios.query.get_or_404(id)

    form = FuncionarioForm(obj=func)

    if form.validate_on_submit():

        other_user = Funcionarios.query.filter(
            Funcionarios.usuario == form.usuario.data, Funcionarios.id != func.id
        ).first()
        if other_user:
            flash("Este usuário já está cadastrado.", "danger")
            return render_template("funcionarios/form.html", form=form, action="Editar")

        if form.email.data:
            other_email = Funcionarios.query.filter(
                Funcionarios.email == form.email.data, Funcionarios.id != func.id
            ).first()
            if other_email:
                flash("Este e-mail já está cadastrado.", "danger")
                return render_template(
                    "funcionarios/form.html", form=form, action="Editar"
                )

        func.nome_completo = form.nome_completo.data
        func.usuario = form.usuario.data
        func.funcao = form.funcao.data
        func.especialidade = form.especialidade.data
        func.sexo = form.sexo.data
        func.email = form.email.data
        func.telefone = form.telefone.data
        func.assinatura = form.assinatura.data

        if form.senha.data:
            func.set_senha(form.senha.data)

        db1.session.commit()

        flash("Funcionário atualizado com sucesso!", "success")

        return redirect(url_for("funcionarios_list"))

    return render_template("funcionarios/form.html", form=form, action="Editar")


# =========================================================
# DASHBOARD RECEPÇÃO
# =========================================================


@app.route("/dashboard_recepcao")
@login_required
def recepcao_list():

    require_role("recepcionista", "administrador")

    dados = Recepcao.query.order_by(Recepcao.horario_chegada.desc()).all()

    return render_template("recepcao/selecionar.html", dados=dados)


# =========================================================
# NOVO ATENDIMENTO RECEPÇÃO
# =========================================================


@app.route("/recepcao/selecionar", methods=["GET", "POST"])
@login_required
def recepcao_selecionar():

    require_role("recepcionista", "administrador")

    pacientes = Paciente.query.order_by(Paciente.nome_completo.asc()).all()

    if request.method == "POST":

        paciente_id = request.form.get("paciente_id")

        paciente = Paciente.query.get_or_404(paciente_id)

        protocolo = f"REC-" f"{datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S')}"

        novo = Recepcao(
            paciente_id=paciente.id,
            destino="Triagem",
            horario_chegada=datetime.now(timezone.utc),
            responsavel_recepcao=current_user.nome_completo,
            observacoes_recepcao=(
                request.form.get("observacoes_recepcao") or ""
            ).strip(),
            motivo=request.form.get("motivo", "").strip(),
            urgencia_recepcao=(
                request.form.get("urgencia_recepcao") or "BAIXA"
            ).upper(),
            status="Aguardando triagem",
            protocolo=protocolo,
            chamado=False,
            finalizado=False,
        )

        try:

            db1.session.add(novo)

            db1.session.commit()

            flash("Atendimento iniciado com sucesso!", "success")

            return redirect(url_for("recepcao_list"))

        except Exception as e:

            db1.session.rollback()

            flash(f"Erro ao iniciar atendimento: {e}", "danger")

    return render_template("recepcao/form.html", pacientes=pacientes)


# =========================================================
# TRIAGEM
# =========================================================


@app.route("/fila/triagem")
@login_required
def fila_triagem():
    require_role("enfermeiro", "administrador")
    pacientes = (
        Recepcao.query.outerjoin(Triagem)
        .filter(Recepcao.finalizado.is_(False), Recepcao.destino == "Triagem")
        .filter((Triagem.id.is_(None)) | (Triagem.finalizado_triagem.is_(False)))
        .order_by(Recepcao.horario_chegada.asc())
        .all()
    )
    return jsonify({"total": len(pacientes), "ids": [p.id for p in pacientes]})


@app.route("/fila/medico")
@login_required
def fila_medico():
    require_role("medico", "médico", "administrador")
    pacientes = (
        Recepcao.query.join(Triagem, Recepcao.id == Triagem.recepcao_id)
        .outerjoin(Medico, Recepcao.id == Medico.recepcao_id)
        .filter(
            Triagem.finalizado_triagem.is_(True),
            Recepcao.finalizado.is_(False),
            Recepcao.destino == "Medico",
        )
        .filter((Medico.id.is_(None)) | (Medico.finalizado_medico.is_(False)))
        .order_by(Triagem.horario_de_triagem.asc())
        .all()
    )
    return jsonify({"total": len(pacientes), "ids": [p.id for p in pacientes]})


@app.route("/fila/vacinacao")
@login_required
def fila_vacinacao():
    require_role("administrador", "enfermeiro", "medico", "médico")
    fila = (
        Recepcao.query.filter(
            Recepcao.destino == "Vacinacao", Recepcao.finalizado.is_(False)
        )
        .order_by(Recepcao.horario_chegada.asc())
        .all()
    )
    return jsonify({"total": len(fila), "ids": [p.id for p in fila]})


@app.route("/triagem")
@login_required
def triagem_dashboard():

    require_role("enfermeiro", "administrador")

    pacientes = (
        Recepcao.query.outerjoin(Triagem)
        .filter(Recepcao.finalizado == False)
        .filter(Recepcao.destino == "Triagem")
        .filter((Triagem.id == None) | (Triagem.finalizado_triagem == False))
        .order_by(Recepcao.horario_chegada.asc())
        .all()
    )

    return render_template("triagem/dashboard_triagem.html", pacientes=pacientes)


# =========================================================
# NOVA TRIAGEM
# =========================================================


@app.route("/triagem/novo", methods=["GET", "POST"])
@login_required
def triagem_novo(recepcao_id=None):

    require_role("enfermeiro", "administrador")

    form = TriagemForm()

    pacientes_disponiveis = (
        Recepcao.query.outerjoin(Triagem)
        .filter(Recepcao.finalizado.is_(False), Recepcao.destino == "Triagem")
        .filter((Triagem.id.is_(None)) | (Triagem.finalizado_triagem.is_(False)))
        .order_by(Recepcao.horario_chegada.asc())
        .all()
    )

    form.recepcao_id.choices = [
        (p.id, f"{p.paciente.nome_completo} ({p.id})") for p in pacientes_disponiveis
    ]
    if recepcao_id is not None and request.method == "GET":
        form.recepcao_id.data = recepcao_id

    if form.validate_on_submit():

        triagem = Triagem(
            recepcao_id=form.recepcao_id.data,
            ocupacao=form.ocupacao.data,
            temperatura=form.temperatura.data,
            freq_cardiaca=form.freq_cardiaca.data,
            freq_respiratoria=form.freq_respiratoria.data,
            pressao_arterial=form.pressao_arterial.data,
            saturacao=form.saturacao.data,
            escala_de_dor=form.escala_de_dor.data,
            peso=form.peso.data,
            altura=form.altura.data,
            imc=form.imc.data,
            alergia=form.alergia.data,
            tipo_sanguineo=form.tipo_sanguineo.data,
            gestante=form.gestante.data,
            queixa_principal=form.queixa_principal.data,
            doencas_pre_existentes=form.doencas_pre_existentes.data,
            toma_medicacao=form.toma_medicacao.data,
            cirurgia_realizada=form.cirurgia_realizada.data,
            tabagista=form.tabagista.data,
            bebida_alcoolica=form.bebida_alcoolica.data,
            responsavel_triagem=current_user.nome_completo,
            observacoes_triagem=form.observacoes_triagem.data,
            horario_de_triagem=datetime.now(timezone.utc),
            finalizado_triagem=True,
        )

        try:

            db1.session.add(triagem)
            recepcao = db1.session.get(Recepcao, form.recepcao_id.data)
            if recepcao:
                recepcao.destino = "Medico"
                recepcao.status = "Aguardando médico"
                recepcao.chamado = False
                recepcao.finalizado = False

            db1.session.commit()

            flash(
                f"Triagem de {recepcao.paciente.nome_completo if recepcao else 'paciente'} finalizada. Paciente encaminhado ao médico.",
                "success",
            )

            return redirect(url_for("triagem_dashboard"))

        except Exception as e:

            db1.session.rollback()

            flash(f"Erro ao salvar triagem: {e}", "danger")

    return render_template("triagem/form.html", form=form, action="Finalizar")


@app.route("/triagem/<int:id>/editar", methods=["GET", "POST"])
@login_required
def triagem_editar(id):
    require_role("enfermeiro", "administrador")
    triagem = Triagem.query.get_or_404(id)
    form = TriagemForm(obj=triagem)
    form.recepcao_id.choices = [
        (
            triagem.recepcao_id,
            f"{triagem.recepcao.paciente.nome_completo} ({triagem.recepcao_id})",
        )
    ]

    if form.validate_on_submit():
        form.populate_obj(triagem)
        triagem.responsavel_triagem = current_user.nome_completo
        triagem.horario_de_triagem = datetime.now(timezone.utc)
        db1.session.commit()
        flash("Triagem atualizada com sucesso.", "success")
        return redirect(url_for("triagem_dashboard"))

    return render_template("triagem/form.html", form=form, action="Editar")


@app.route("/triagem/<int:id>/excluir", methods=["POST"])
@login_required
def triagem_excluir(id):
    require_role("enfermeiro", "administrador")
    triagem = Triagem.query.get_or_404(id)
    recepcao = triagem.recepcao
    db1.session.delete(triagem)
    if recepcao and not recepcao.finalizado:
        recepcao.destino = "Triagem"
        recepcao.status = "Aguardando triagem"
        recepcao.chamado = False
    db1.session.commit()
    flash("Triagem excluída.", "warning")
    return redirect(url_for("triagem_dashboard"))


# =========================================================
# PACIENTES
# =========================================================


@app.route("/paciente/<string:id>/historico")
@login_required
def paciente_historico(id):
    require_role(
        "recepcionista", "enfermeiro", "medico", "médico", "psicologo", "administrador"
    )
    paciente = Paciente.query.get_or_404(id)
    atendimentos = (
        Recepcao.query.filter_by(paciente_id=paciente.id)
        .order_by(Recepcao.horario_chegada.desc())
        .all()
    )
    itens = []
    for r in atendimentos:
        tri = r.triagem
        med = r.medico
        vacs = r.vacinacoes or []
        itens.append(
            {
                "id": r.id,
                "protocolo": r.protocolo,
                "data": (
                    r.horario_chegada.strftime("%d/%m/%Y %H:%M")
                    if r.horario_chegada
                    else "—"
                ),
                "status": r.status or "—",
                "destino": r.destino or "—",
                "urgencia": r.urgencia_recepcao or "—",
                "motivo": r.motivo or r.observacoes_recepcao or "—",
                "recepcao": {
                    "responsavel": r.responsavel_recepcao or "—",
                    "observacoes": r.observacoes_recepcao or "—",
                },
                "triagem": {
                    "finalizada": bool(tri and tri.finalizado_triagem),
                    "responsavel": tri.responsavel_triagem if tri else "—",
                    "data": (
                        tri.horario_de_triagem.strftime("%d/%m/%Y %H:%M")
                        if tri and tri.horario_de_triagem
                        else "—"
                    ),
                    "queixa": tri.queixa_principal if tri else "—",
                    "temperatura": tri.temperatura if tri else "—",
                    "pressao": tri.pressao_arterial if tri else "—",
                    "fc": tri.freq_cardiaca if tri else "—",
                    "fr": tri.freq_respiratoria if tri else "—",
                    "peso": tri.peso if tri else "—",
                    "altura": tri.altura if tri else "—",
                    "saturacao": tri.saturacao if tri else "—",
                    "dor": tri.escala_de_dor if tri else None,
                    "alergia": tri.alergia if tri else "—",
                    "medicacao": tri.toma_medicacao if tri else "—",
                    "doencas": tri.doencas_pre_existentes if tri else "—",
                    "observacoes": tri.observacoes_triagem if tri else "—",
                },
                "medico": {
                    "finalizado": bool(med and med.finalizado_medico),
                    "responsavel": med.responsavel_medico if med else "—",
                    "data": (
                        med.horario_de_finalizacao.strftime("%d/%m/%Y %H:%M")
                        if med and med.horario_de_finalizacao
                        else "—"
                    ),
                    "diagnostico": med.diagnostico if med else "—",
                    "prescricao": med.prescricao if med else "—",
                    "cid": med.cid if med else "—",
                    "feedback": med.feedback if med else "—",
                    "observacoes": med.observacoes_medico if med else "—",
                },
                "psicologia": {
                    "finalizada": bool(
                        r.psicologia and r.psicologia.finalizado_psicologia
                    ),
                    "responsavel": (
                        r.psicologia.responsavel_psicologo if r.psicologia else "—"
                    ),
                    "data": (
                        r.psicologia.horario_atendimento.strftime("%d/%m/%Y %H:%M")
                        if r.psicologia and r.psicologia.horario_atendimento
                        else "—"
                    ),
                    "avaliacao": r.psicologia.avaliacao if r.psicologia else "—",
                    "observacoes": r.psicologia.observacoes if r.psicologia else "—",
                    "diagnostico": r.psicologia.diagnostico if r.psicologia else "—",
                    "conduta": r.psicologia.conduta if r.psicologia else "—",
                },
                "vacinacoes": [
                    {
                        "vacina": v.vacina,
                        "dose": v.dose or "—",
                        "lote": v.lote or "—",
                        "fabricante": v.fabricante or "—",
                        "data": (
                            v.data_aplicacao.strftime("%d/%m/%Y %H:%M")
                            if v.data_aplicacao
                            else "—"
                        ),
                        "responsavel": v.responsavel_vacinacao or "—",
                        "observacoes": v.observacoes or "—",
                    }
                    for v in vacs
                ],
            }
        )
    return jsonify(
        {
            "paciente": {
                "id": paciente.id,
                "nome": paciente.nome_completo,
                "documento": paciente.documento or "Não informado",
                "data_nascimento": (
                    paciente.data_nascimento.strftime("%d/%m/%Y")
                    if paciente.data_nascimento
                    else "Não informado"
                ),
                "sexo": paciente.sexo or "Não informado",
                "contato": paciente.contato or "Não informado",
                "email": paciente.email or "Não informado",
                "usuario": paciente.usuario or "Não informado",
                "plano": paciente.plano or "SUS",
                "responsavel": paciente.responsavel or "Não informado",
                "observacoes": paciente.observacoes_cadastro or "Sem observações",
            },
            "atendimentos": itens,
        }
    )


@app.route("/dashboard_pacientes")
@login_required
def dashboard_pacientes():

    require_role("administrador", "recepcionista")

    dados = Paciente.query.order_by(Paciente.nome_completo.asc()).all()

    return render_template("pacientes/dashboard_pacientes.html", dados=dados)


# =========================================================
# NOVO PACIENTE
# =========================================================


@app.route("/paciente/novo", methods=["GET", "POST"])
@login_required
def paciente_novo():

    require_role("administrador", "recepcionista")

    form = PacienteForm()

    planos = Plano.query.filter_by(ativo=True).order_by(Plano.nome_plano.asc()).all()

    form.plano.choices = [("SUS", "SUS")] + [
        (p.nome_plano, p.nome_plano) for p in planos
    ]

    # =====================================================
    # ASSINATURA / QR CODE
    # =====================================================

    token = str(uuid.uuid4())

    link_assinatura = url_for("assinar", token=token, _external=True)

    qr = qrcode.make(link_assinatura)

    buffer = BytesIO()
    qr.save(buffer, format="PNG")

    qr_code = base64.b64encode(buffer.getvalue()).decode()

    qr_code = f"data:image/png;base64,{qr_code}"

    # =====================================================
    # SALVAR PACIENTE
    # =====================================================

    if form.validate_on_submit():

        # Normaliza os campos
        usuario = (form.usuario.data or "").strip()
        email = (form.email.data or "").strip()

        # =================================================
        # VERIFICA USUÁRIO
        # =================================================

        if usuario:

            usuario_existente = Paciente.query.filter_by(usuario=usuario).first()

            if usuario_existente:

                flash("Usuário já cadastrado.", "danger")

                return render_template(
                    "pacientes/form.html",
                    form=form,
                    action="Novo",
                    qr_code=qr_code,
                    token=token,
                )

        # =================================================
        # VERIFICA E-MAIL
        # =================================================

        if email:

            email_existente = Paciente.query.filter_by(email=email).first()

            if email_existente:

                flash("E-mail já cadastrado.", "danger")

                return render_template(
                    "pacientes/form.html",
                    form=form,
                    action="Novo",
                    qr_code=qr_code,
                    token=token,
                )

        # =================================================
        # FOTO
        # =================================================

        foto_path = None

        if form.foto.data:

            arquivo = form.foto.data

            if arquivo.filename:

                if not allowed_image(arquivo.filename):

                    flash(
                        "Formato de imagem não permitido. "
                        "Use PNG, JPG, JPEG ou WEBP.",
                        "danger",
                    )

                    return render_template(
                        "pacientes/form.html",
                        form=form,
                        action="Novo",
                        qr_code=qr_code,
                        token=token,
                    )

                nome = secure_filename(arquivo.filename)

                nome_final = f"{uuid.uuid4().hex}_{nome}"

                caminho = os.path.join(app.config["UPLOAD_FOLDER"], nome_final)

                arquivo.save(caminho)

                foto_path = f"uploads/{nome_final}"

        # =================================================
        # CRIA PACIENTE
        # =================================================

        novo = Paciente(
            nome_completo=form.nome_completo.data,
            data_nascimento=form.data_nascimento.data,
            sexo=form.sexo.data,
            contato=form.contato.data,
            documento=form.documento.data,
            plano=form.plano.data,
            observacoes_cadastro=(form.observacoes_cadastro.data),
            responsavel=current_user.nome_completo,
            responsavel_cadastro=(current_user.nome_completo),
            email=email or None,
            usuario=usuario or None,
            assinatura=form.assinatura.data,
            assinatura_token=token,
            foto=foto_path,
        )

        # =================================================
        # SENHA
        # =================================================

        if form.senha.data:

            novo.set_senha(form.senha.data)

        # =================================================
        # SALVA NO BANCO
        # =================================================

        try:

            db1.session.add(novo)

            db1.session.commit()

        except Exception as exc:

            db1.session.rollback()

            flash(f"Não foi possível cadastrar o paciente: {exc}", "danger")

            return render_template(
                "pacientes/form.html",
                form=form,
                action="Novo",
                qr_code=qr_code,
                token=token,
            )

        # =================================================
        # SUCESSO
        # =================================================

        flash("Paciente criado com sucesso!", "success")

        return redirect(url_for("dashboard_pacientes"))

    # =====================================================
    # FORMULÁRIO
    # =====================================================

    return render_template(
        "pacientes/form.html", form=form, action="Novo", qr_code=qr_code, token=token
    )


# =========================================================
# EDITAR PACIENTE
# =========================================================


@app.route("/paciente/editar/<string:id>", methods=["GET", "POST"])
@login_required
def paciente_editar(id):

    require_role("administrador", "recepcionista")

    paciente = Paciente.query.get_or_404(id)

    form = PacienteForm(obj=paciente)

    planos = Plano.query.filter_by(ativo=True).order_by(Plano.nome_plano.asc()).all()

    form.plano.choices = [("SUS", "SUS")] + [
        (p.nome_plano, p.nome_plano) for p in planos
    ]

    if form.validate_on_submit():

        # =================================================
        # NORMALIZA CAMPOS OPCIONAIS
        # =================================================

        usuario = (form.usuario.data or "").strip() or None
        email = (form.email.data or "").strip() or None

        # =================================================
        # VERIFICA USUÁRIO DUPLICADO
        # =================================================

        if usuario:

            other_user = Paciente.query.filter(
                Paciente.usuario == usuario, Paciente.id != paciente.id
            ).first()

            if other_user:

                flash("Este usuário já está cadastrado.", "danger")

                return render_template(
                    "pacientes/form.html", form=form, action="Editar"
                )

        # =================================================
        # VERIFICA E-MAIL DUPLICADO
        # =================================================

        if email:

            other_email = Paciente.query.filter(
                Paciente.email == email, Paciente.id != paciente.id
            ).first()

            if other_email:

                flash("Este e-mail já está cadastrado.", "danger")

                return render_template(
                    "pacientes/form.html", form=form, action="Editar"
                )

        # =================================================
        # ATUALIZA DADOS
        # =================================================

        paciente.nome_completo = form.nome_completo.data
        paciente.data_nascimento = form.data_nascimento.data
        paciente.sexo = form.sexo.data
        paciente.contato = form.contato.data
        paciente.documento = form.documento.data
        paciente.plano = form.plano.data
        paciente.observacoes_cadastro = form.observacoes_cadastro.data
        paciente.email = email
        paciente.usuario = usuario

        # =================================================
        # ATUALIZA SENHA SOMENTE SE INFORMADA
        # =================================================

        if form.senha.data:
            paciente.set_senha(form.senha.data)

        # =================================================
        # FOTO
        # =================================================

        arquivo = form.foto.data

        if arquivo and arquivo.filename:

            if not allowed_image(arquivo.filename):

                flash(
                    "Formato de imagem não permitido. " "Use PNG, JPG, JPEG ou WEBP.",
                    "danger",
                )

                return render_template(
                    "pacientes/form.html", form=form, action="Editar"
                )

            # =================================================
            # APAGA FOTO ANTIGA
            # =================================================

            foto_antiga = paciente.foto

            if foto_antiga:

                caminho_antigo = os.path.join(
                    app.config["UPLOAD_FOLDER"], os.path.basename(foto_antiga)
                )

                try:
                    if os.path.isfile(caminho_antigo):
                        os.remove(caminho_antigo)
                except OSError:
                    pass

            # =================================================
            # GERA NOVO NOME
            # =================================================

            nome_original = secure_filename(arquivo.filename)

            nome_final = f"{uuid.uuid4().hex}_{nome_original}"

            caminho = os.path.join(app.config["UPLOAD_FOLDER"], nome_final)

            # =================================================
            # SALVA IMAGEM
            # =================================================

            arquivo.save(caminho)

            paciente.foto = f"uploads/{nome_final}"

        # =================================================
        # SALVA NO BANCO
        # =================================================

        try:

            db1.session.commit()

        except Exception as exc:

            db1.session.rollback()

            flash(f"Não foi possível atualizar o paciente: {exc}", "danger")

            return render_template("pacientes/form.html", form=form, action="Editar")

        flash("Paciente atualizado com sucesso!", "success")

        return redirect(url_for("dashboard_pacientes"))

    return render_template("pacientes/form.html", form=form, action="Editar")


# =========================================================
# EXCLUIR PACIENTE
# =========================================================


@app.route("/paciente/excluir/<string:id>", methods=["POST"])
@login_required
def paciente_excluir(id):

    require_role("administrador")

    paciente = Paciente.query.get_or_404(id)

    try:
        recepcoes = Recepcao.query.filter_by(paciente_id=paciente.id).all()

        for recepcao in recepcoes:

            for vacinacao in Vacinacao.query.filter_by(recepcao_id=recepcao.id).all():
                db1.session.delete(vacinacao)

            triagem = Triagem.query.filter_by(recepcao_id=recepcao.id).first()
            if triagem:
                db1.session.delete(triagem)

            medico = Medico.query.filter_by(recepcao_id=recepcao.id).first()
            if medico:
                db1.session.delete(medico)

            db1.session.delete(recepcao)

        for vinculo in PacientePlano.query.filter_by(paciente_id=paciente.id).all():
            db1.session.delete(vinculo)

        for venda in VendaPlano.query.filter_by(paciente_id=paciente.id).all():
            db1.session.delete(venda)

        db1.session.delete(paciente)
        db1.session.commit()

    except Exception as exc:
        db1.session.rollback()
        flash(f"Não foi possível excluir o paciente com segurança: {exc}", "danger")
        return redirect(url_for("dashboard_pacientes"))

    flash("Paciente e seu histórico de atendimento foram excluídos.", "warning")
    return redirect(url_for("dashboard_pacientes"))


# =========================================================
# EXCLUIR FUNCIONARIO
# =========================================================


@app.route("/funcionario/excluir/<string:id>", methods=["POST"])
@login_required
def funcionarios_excluir(id):

    require_role("administrador")

    func = Funcionarios.query.get_or_404(id)

    db1.session.delete(func)

    db1.session.commit()

    flash("Funcionário excluído com sucesso!", "warning")

    return redirect(url_for("funcionarios_list"))


# =========================================================
# DASHBOARD PSICOLOGIA
# =========================================================


@app.route("/dashboard_psicologo")
@login_required
def dashboard_psicologo():
    require_role("psicologo", "administrador")

    encaminhamentos = (
        Recepcao.query.filter(
            Recepcao.finalizado.is_(False), Recepcao.destino == "Psicologo"
        )
        .order_by(Recepcao.horario_chegada.asc())
        .all()
    )
    return render_template(
        "psicologo/dashboard_psicologo.html", encaminhamentos=encaminhamentos
    )


@app.route("/psicologo/atender/<int:recepcao_id>", methods=["GET", "POST"])
@login_required
def atender_psicologia(recepcao_id):
    require_role("psicologo", "administrador")
    recepcao = Recepcao.query.get_or_404(recepcao_id)
    if recepcao.finalizado or recepcao.destino != "Psicologo":
        flash("Este atendimento não está disponível para a psicologia.", "warning")
        return redirect(url_for("dashboard_psicologo"))

    atendimento = recepcao.psicologia
    if not atendimento:
        atendimento = Psicologia(recepcao_id=recepcao.id)
        db1.session.add(atendimento)

    form = PsicologiaForm(obj=atendimento)
    form.recepcao_id.data = recepcao.id
    historico_atendimentos = (
        Recepcao.query.filter(Recepcao.paciente_id == recepcao.paciente_id)
        .order_by(Recepcao.horario_chegada.desc())
        .all()
    )
    if form.validate_on_submit():
        atendimento.avaliacao = form.avaliacao.data or ""
        atendimento.observacoes = form.observacoes.data or ""
        atendimento.diagnostico = form.diagnostico.data or ""
        atendimento.conduta = form.conduta.data or ""
        atendimento.responsavel_psicologo = current_user.nome_completo
        atendimento.horario_atendimento = datetime.now(timezone.utc)
        atendimento.finalizado_psicologia = True
        recepcao.destino = "Finalizado"
        recepcao.status = "Atendimento psicológico finalizado"
        recepcao.chamado = False
        recepcao.finalizado = True
        db1.session.commit()
        flash(
            f"Atendimento psicológico de {recepcao.paciente.nome_completo} finalizado com sucesso.",
            "success",
        )
        return redirect(url_for("dashboard_psicologo"))

    return render_template(
        "psicologo/form.html",
        form=form,
        recepcao=recepcao,
        atendimento=atendimento,
        dados_paciente=recepcao.paciente,
        historico_atendimentos=historico_atendimentos,
    )


@app.route("/recepcao/encaminhar/<int:paciente_id>", methods=["POST"])
@login_required
def recepcao_encaminhar(paciente_id):
    require_role("recepcionista", "administrador")
    paciente = Recepcao.query.get_or_404(paciente_id)
    destino = (request.form.get("destino_encaminhamento") or "").strip().upper()
    motivo = (request.form.get("motivo_encaminhamento") or "").strip()[:2000]
    mapa = {
        "VACINACAO": (
            "Vacinacao",
            "Aguardando vacinação",
            "enfermeiro",
            "lista_vacinacao",
        ),
        "PSICOLOGIA": (
            "Psicologo",
            "Encaminhado para psicologia",
            "psicologo",
            "dashboard_psicologo",
        ),
    }
    if destino not in mapa or paciente.finalizado:
        flash("Encaminhamento inválido para este atendimento.", "warning")
        return redirect(url_for("recepcao_list"))
    destino_db, status, funcao, rota = mapa[destino]
    paciente.destino = destino_db
    paciente.status = status
    paciente.chamado = False
    paciente.finalizado = False
    if motivo:
        texto = paciente.observacoes_recepcao or ""
        paciente.observacoes_recepcao = (
            texto + ("\n" if texto else "") + f"Encaminhamento da recepção: {motivo}"
        )[:5000]
    notificar_funcao(
        funcao,
        "Novo encaminhamento",
        f"{paciente.paciente.nome_completo} foi encaminhado para {destino_db.lower()} pela recepção.",
        "info",
        url_for(rota),
    )
    db1.session.commit()
    flash(
        f"Paciente {paciente.paciente.nome_completo} encaminhado com sucesso.",
        "success",
    )
    return redirect(url_for("recepcao_list"))


# =========================================================
# DASHBOARD MEDICO
# =========================================================


@app.route("/dashboard_medico")
@login_required
def dashboard_medico():

    require_role("medico", "médico", "administrador")

    pacientes_aguardando = (
        Recepcao.query.join(Triagem, Recepcao.id == Triagem.recepcao_id)
        .outerjoin(Medico, Recepcao.id == Medico.recepcao_id)
        .filter(Triagem.finalizado_triagem.is_(True))
        .filter(Recepcao.finalizado.is_(False))
        .filter(Recepcao.destino == "Medico")
        .filter((Medico.id.is_(None)) | (Medico.finalizado_medico.is_(False)))
        .order_by(Triagem.horario_de_triagem.asc())
        .all()
    )

    ultimos_atendimentos = (
        Medico.query.filter(Medico.finalizado_medico == True)
        .order_by(Medico.horario_de_finalizacao.desc())
        .limit(5)
        .all()
    )

    atendimentos_hoje = Medico.query.filter(
        Medico.horario_de_finalizacao
        >= datetime.now(timezone.utc).replace(hour=0, minute=0, second=0)
    ).count()

    return render_template(
        "medico/dashboard_medico.html",
        pacientes_aguardando=pacientes_aguardando,
        ultimos_atendimentos=ultimos_atendimentos,
        atendimentos_hoje=atendimentos_hoje,
    )


# =========================================================
# VENDAS / COMERCIAL
# =========================================================


@app.route("/dashboard_vendas")
@login_required
def dashboard_vendas():

    require_role("vendas", "vendedor", "comercial", "vendas/comercial", "administrador")

    is_admin = check_role("administrador")
    vendedor_id = None if is_admin else current_user.id

    query_vendas = VendaPlano.query
    if vendedor_id:
        query_vendas = query_vendas.filter_by(vendedor_id=vendedor_id)

    vendas = query_vendas.order_by(VendaPlano.data_venda.desc()).all()

    inicio_mes = datetime.now(timezone.utc).replace(
        day=1, hour=0, minute=0, second=0, microsecond=0
    )

    query_mes = VendaPlano.query.filter(VendaPlano.data_venda >= inicio_mes)
    if vendedor_id:
        query_mes = query_mes.filter(VendaPlano.vendedor_id == vendedor_id)
    vendas_mes = query_mes.all()

    valor_mes = sum(v.valor_final or 0 for v in vendas_mes)
    total_vendas = len(vendas)
    vendas_ativas = sum(1 for v in vendas if (v.status or "").lower() == "ativa")

    ranking = (
        db1.session.query(
            Funcionarios.nome_completo,
            db1.func.count(VendaPlano.id).label("quantidade"),
            db1.func.sum(VendaPlano.valor_final).label("valor"),
        )
        .join(VendaPlano, VendaPlano.vendedor_id == Funcionarios.id)
        .group_by(Funcionarios.id)
        .order_by(db1.func.sum(VendaPlano.valor_final).desc())
        .limit(10)
        .all()
    )

    return render_template(
        "vendas/dashboard_vendas.html",
        vendas=vendas,
        valor_mes=valor_mes,
        total_vendas=total_vendas,
        vendas_ativas=vendas_ativas,
        vendas_mes=len(vendas_mes),
        ranking=ranking,
    )


@app.route("/vendas/nova", methods=["GET", "POST"])
@login_required
def nova_venda_plano():

    require_role("vendas", "vendedor", "comercial", "vendas/comercial", "administrador")

    pacientes = Paciente.query.order_by(Paciente.nome_completo.asc()).all()
    planos = Plano.query.filter_by(ativo=True).order_by(Plano.nome_plano.asc()).all()

    if request.method == "POST":
        paciente_id = request.form.get("paciente_id", "").strip()
        plano_id = request.form.get("plano_id", type=int)
        periodicidade = request.form.get("periodicidade", "Mensal").strip()
        forma_pagamento = request.form.get("forma_pagamento", "Não informado").strip()
        status = request.form.get("status", "Ativa").strip()
        observacoes = request.form.get("observacoes", "").strip()

        paciente = Paciente.query.get_or_404(paciente_id)
        plano = Plano.query.get_or_404(plano_id)

        def moeda(valor):
            valor = (valor or "0").strip().replace("R$", "").replace(" ", "")
            if "," in valor:
                valor = valor.replace(".", "").replace(",", ".")
            return float(valor or 0)

        try:
            desconto = moeda(request.form.get("desconto"))
        except ValueError:
            flash("Informe um desconto válido.", "danger")
            return render_template(
                "vendas/nova_venda.html", pacientes=pacientes, planos=planos
            )

        valor_original = float(plano.preco or 0)
        desconto = max(0, min(desconto, valor_original))
        valor_final = valor_original - desconto

        venda = VendaPlano(
            paciente_id=paciente.id,
            plano_id=plano.id,
            vendedor_id=current_user.id,
            valor_original=valor_original,
            desconto=desconto,
            valor_final=valor_final,
            periodicidade=periodicidade,
            forma_pagamento=forma_pagamento,
            status=status,
            observacoes=observacoes,
        )

        paciente.plano = plano.nome_plano

        atual = PacientePlano.query.filter_by(
            paciente_id=paciente.id, ativo=True
        ).first()

        if atual:
            atual.ativo = False

        novo_vinculo = PacientePlano(
            paciente_id=paciente.id,
            plano_id=plano.id,
            data_inicio=datetime.now(timezone.utc).date(),
            pagamento_em_dia=True,
            ativo=True,
        )

        db1.session.add(venda)
        db1.session.add(novo_vinculo)
        db1.session.commit()

        flash(f"Venda registrada para {paciente.nome_completo}.", "success")
        return redirect(url_for("dashboard_vendas"))

    return render_template("vendas/nova_venda.html", pacientes=pacientes, planos=planos)


@app.route("/vendas/<int:id>/status", methods=["POST"])
@login_required
def alterar_status_venda(id):

    require_role("vendas", "vendedor", "comercial", "vendas/comercial", "administrador")

    venda = VendaPlano.query.get_or_404(id)

    if venda.vendedor_id != current_user.id and not check_role("administrador"):
        abort(403)

    status = request.form.get("status", "Ativa")
    venda.status = status
    db1.session.commit()

    flash("Status da venda atualizado.", "success")
    return redirect(url_for("dashboard_vendas"))


@app.route("/planos/<int:id>/editar", methods=["GET", "POST"])
@login_required
def editar_plano(id):

    require_role("administrador")
    plano = Plano.query.get_or_404(id)

    form = PlanoForm(obj=plano)

    if form.validate_on_submit():

        try:
            preco = form.preco.to_float()
        except ValueError as exc:
            flash(str(exc), "danger")
            return render_template("planos/editar_plano.html", form=form, plano=plano)

        plano.nome_plano = form.nome_plano.data
        plano.preco = preco
        plano.descricao = form.descricao.data
        plano.ativo = form.ativo.data

        db1.session.commit()

        flash("Plano atualizado com sucesso!", "success")

        return redirect(url_for("lista_planos"))

    return render_template("planos/editar_plano.html", form=form, plano=plano)


@app.route("/planos/excluir/<int:id>", methods=["POST"])
@login_required
def excluir_plano(id):

    require_role("administrador")
    plano = Plano.query.get_or_404(id)

    db1.session.delete(plano)
    db1.session.commit()

    flash("Plano excluído com sucesso!", "success")

    return redirect(url_for("lista_planos"))


# ==========================
# VACINAÇÃO
# ==========================


@app.route("/vacinacao")
@login_required
def lista_vacinacao():
    require_role("administrador", "enfermeiro", "medico", "médico")

    vacinacoes = Vacinacao.query.order_by(Vacinacao.id.desc()).all()
    fila_vacinacao = (
        Recepcao.query.filter(
            Recepcao.destino == "Vacinacao", Recepcao.finalizado == False
        )
        .order_by(Recepcao.horario_chegada.asc())
        .all()
    )

    return render_template(
        "vacinacao/lista_vacinacao.html",
        vacinacoes=vacinacoes,
        fila_vacinacao=fila_vacinacao,
    )


@app.route("/vacinacao/nova", methods=["GET", "POST"])
@login_required
def nova_vacinacao():
    require_role("administrador", "enfermeiro")
    form = VacinacaoForm()
    recepcao_preselecionada = request.args.get("recepcao_id", type=int)

    fila = (
        Recepcao.query.filter(
            Recepcao.destino == "Vacinacao", Recepcao.finalizado == False
        )
        .order_by(Recepcao.horario_chegada.asc())
        .all()
    )

    form.recepcao_id.choices = [
        (r.id, f"{r.paciente.nome_completo} • atendimento #{r.id}") for r in fila
    ]
    if recepcao_preselecionada and any(r.id == recepcao_preselecionada for r in fila):
        form.recepcao_id.data = recepcao_preselecionada

    if form.validate_on_submit():
        recepcao = Recepcao.query.get_or_404(form.recepcao_id.data)
        if recepcao.destino != "Vacinacao" or recepcao.finalizado:
            flash("Este atendimento não está aguardando vacinação.", "warning")
            return redirect(url_for("lista_vacinacao"))

        vacinacao = Vacinacao(
            recepcao_id=recepcao.id,
            vacina=form.vacina.data,
            dose=form.dose.data,
            lote=form.lote.data,
            fabricante=form.fabricante.data,
            observacoes=form.observacoes.data,
            responsavel_vacinacao=current_user.nome_completo,
            assinatura=form.assinatura.data,
            data_aplicacao=datetime.now(timezone.utc),
        )
        recepcao.finalizado = True
        recepcao.status = "Atendimento finalizado"
        recepcao.destino = "Finalizado"
        recepcao.chamado = False

        db1.session.add(vacinacao)
        db1.session.commit()

        flash(
            f"Vacinação de {recepcao.paciente.nome_completo} registrada e atendimento encerrado.",
            "success",
        )
        return redirect(url_for("lista_vacinacao"))

    return render_template(
        "vacinacao/nova_vacinacao.html", form=form, fila_vacinacao=fila
    )


@app.route("/vacinacao/<int:id>/editar", methods=["GET", "POST"])
@login_required
def editar_vacinacao(id):

    require_role("administrador", "enfermeiro")
    vacinacao = Vacinacao.query.get_or_404(id)

    form = VacinacaoForm(obj=vacinacao)
    form.recepcao_id.choices = [
        (
            vacinacao.recepcao_id,
            f"{vacinacao.recepcao.paciente.nome_completo} • atendimento #{vacinacao.recepcao_id}",
        )
    ]

    if form.validate_on_submit():

        form.populate_obj(vacinacao)

        db1.session.commit()

        flash("Vacinação atualizada com sucesso!", "success")

        return redirect(url_for("lista_vacinacao"))

    return render_template(
        "vacinacao/editar_vacinacao.html", form=form, vacinacao=vacinacao
    )


@app.route("/vacinacao/<int:id>/excluir", methods=["POST"])
@login_required
def excluir_vacinacao(id):

    require_role("administrador", "enfermeiro")
    vacinacao = Vacinacao.query.get_or_404(id)

    db1.session.delete(vacinacao)
    db1.session.commit()

    flash("Vacinação removida com sucesso!", "success")

    return redirect(url_for("lista_vacinacao"))


# =========================================================
# ATENDIMENTO MEDICO
# =========================================================


@app.route("/atender_paciente/<int:paciente_id>", methods=["GET", "POST"])
@login_required
def atender_paciente(paciente_id):
    require_role("medico", "médico", "administrador")

    paciente = Recepcao.query.get_or_404(paciente_id)

    if not paciente.triagem or not paciente.triagem.finalizado_triagem:
        flash("Este paciente ainda não possui uma triagem finalizada.", "warning")
        return redirect(url_for("dashboard_medico"))

    if paciente.destino != "Medico":
        flash("Este paciente não está mais na fila médica.", "warning")
        return redirect(url_for("dashboard_medico"))
    if paciente.medico and paciente.medico.finalizado_medico:
        flash("Este atendimento médico já foi finalizado.", "warning")
        return redirect(url_for("dashboard_medico"))

    form = MedicoForm()
    form.preencher_form(paciente)

    if form.validate_on_submit():
        if not paciente.medico:
            atendimento = Medico(recepcao_id=paciente.id)
            db1.session.add(atendimento)
        else:
            atendimento = paciente.medico

        atendimento.feedback = form.feedback.data or ""
        atendimento.diagnostico = form.diagnostico.data or ""
        atendimento.prescricao = form.prescricao.data or ""
        atendimento.cid = form.cid.data or ""
        atendimento.finalizado_medico = True
        atendimento.responsavel_medico = current_user.nome_completo
        atendimento.observacoes_medico = form.observacoes_medico.data or ""
        atendimento.horario_de_finalizacao = datetime.now(timezone.utc)

        if form.destino_final.data == "VACINACAO":
            paciente.destino = "Vacinacao"
            paciente.status = "Aguardando vacinação"
            paciente.chamado = False
            paciente.finalizado = False
        elif form.destino_final.data == "PSICOLOGIA":
            paciente.destino = "Psicologo"
            paciente.status = "Encaminhado para psicologia"
            paciente.chamado = False
            paciente.finalizado = False

            encaminhamento = (
                getattr(form, "encaminhamento_psicologia", None).data or ""
            ).strip()
            if encaminhamento:
                prefixo = "Encaminhamento para psicologia: "
                texto_atual = atendimento.observacoes_medico or ""
                atendimento.observacoes_medico = (
                    texto_atual
                    + ("\n" if texto_atual else "")
                    + prefixo
                    + encaminhamento
                )[:5000]

            notificar_funcao(
                "psicologo",
                "Novo encaminhamento para psicologia",
                f"{paciente.paciente.nome_completo} foi encaminhado pelo clínico para avaliação psicológica no atendimento #{paciente.id}.",
                "info",
                url_for("dashboard_psicologo"),
            )
        else:
            paciente.destino = "Finalizado"
            paciente.status = "Atendimento finalizado"
            paciente.chamado = False
            paciente.finalizado = True

        if form.destino_final.data == "VACINACAO":
            notificar_funcao(
                "enfermeiro",
                "Paciente encaminhado para vacinação",
                f"{paciente.paciente.nome_completo} foi encaminhado pelo médico para vacinação no atendimento #{paciente.id}.",
                "info",
                url_for("lista_vacinacao"),
            )

        db1.session.commit()

        if form.destino_final.data == "VACINACAO":
            flash(
                f"Atendimento médico de {paciente.paciente.nome_completo} finalizado. Paciente encaminhado para vacinação.",
                "success",
            )
        elif form.destino_final.data == "PSICOLOGIA":
            flash(
                f"Atendimento médico de {paciente.paciente.nome_completo} finalizado. Paciente encaminhado para psicologia.",
                "success",
            )
        else:
            flash(
                f"Atendimento de {paciente.paciente.nome_completo} finalizado com sucesso.",
                "success",
            )

        return redirect(url_for("dashboard_medico"))

    historico_atendimentos = (
        Recepcao.query.filter(Recepcao.paciente_id == paciente.paciente_id)
        .order_by(Recepcao.horario_chegada.desc())
        .all()
    )

    planos_paciente = (
        PacientePlano.query.filter(PacientePlano.paciente_id == paciente.paciente_id)
        .order_by(PacientePlano.data_inicio.desc())
        .all()
    )

    return render_template(
        "medico/form.html",
        form=form,
        paciente=paciente,
        action="Finalizar",
        dados_paciente=paciente.paciente,
        historico_atendimentos=historico_atendimentos,
        planos_paciente=planos_paciente,
    )


# =========================================================
# IMPRESSÃO DO PRONTUÁRIO / ATESTADO DE DEMONSTRAÇÃO
# =========================================================


@app.route("/medico/prontuario/<int:recepcao_id>")
@login_required
def imprimir_prontuario(recepcao_id):
    require_role("medico", "médico", "administrador")

    atendimento = Recepcao.query.get_or_404(recepcao_id)
    paciente = atendimento.paciente

    historico_atendimentos = (
        Recepcao.query.filter(Recepcao.paciente_id == paciente.id)
        .order_by(Recepcao.horario_chegada.desc())
        .all()
    )

    planos_paciente = (
        PacientePlano.query.filter(PacientePlano.paciente_id == paciente.id)
        .order_by(PacientePlano.data_inicio.desc())
        .all()
    )

    return render_template(
        "medico/imprimir_prontuario.html",
        atendimento=atendimento,
        dados_paciente=paciente,
        historico_atendimentos=historico_atendimentos,
        planos_paciente=planos_paciente,
    )


@app.route("/medico/documento/<int:recepcao_id>/<tipo>")
@login_required
def documento_medico(recepcao_id, tipo):
    require_role("medico", "médico", "administrador")
    tipos = {
        "prontuario": "Prontuário",
        "atestado": "Atestado demonstrativo",
        "receita": "Receita demonstrativa",
        "encaminhamento": "Encaminhamento",
        "resumo": "Resumo do atendimento",
        "vacinacao": "Comprovante de vacinação",
    }
    if tipo not in tipos:
        abort(404)
    atendimento = Recepcao.query.get_or_404(recepcao_id)
    paciente = atendimento.paciente
    historico = (
        Recepcao.query.filter_by(paciente_id=paciente.id)
        .order_by(Recepcao.horario_chegada.desc())
        .all()
    )
    vacinacoes = [v for h in historico for v in (h.vacinacoes or [])]
    return render_template(
        "medico/documento.html",
        atendimento=atendimento,
        dados_paciente=paciente,
        historico_atendimentos=historico,
        vacinacoes=vacinacoes,
        tipo=tipo,
        titulo=tipos[tipo],
        medico_nome=current_user.nome_completo,
    )


@app.route("/creditos")
@login_required
def creditos():
    return render_template("utils/creditos.html")


@app.route("/planos/novo", methods=["GET", "POST"])
@login_required
def novo_plano():

    require_role("administrador")
    form = PlanoForm()

    if form.validate_on_submit():

        try:
            preco = form.preco.to_float()
        except ValueError as exc:
            flash(str(exc), "danger")
            return render_template("planos/novo_plano.html", form=form)

        plano = Plano(
            nome_plano=form.nome_plano.data,
            preco=preco,
            descricao=form.descricao.data,
            ativo=form.ativo.data,
        )

        db1.session.add(plano)
        db1.session.commit()

        flash("Plano cadastrado com sucesso!", "success")

        return redirect(url_for("lista_planos"))

    return render_template("planos/novo_plano.html", form=form)


@app.route("/planos")
@login_required
def lista_planos():

    require_role("administrador", "vendas", "vendedor", "comercial", "vendas/comercial")
    planos = Plano.query.order_by(Plano.nome_plano.asc()).all()

    vendas = VendaPlano.query.all()
    total_vendas = len(vendas)
    receita = sum(v.valor_final or 0 for v in vendas)
    clientes_com_plano = PacientePlano.query.filter_by(ativo=True).count()

    return render_template(
        "planos/lista_planos.html",
        planos=planos,
        total_vendas=total_vendas,
        receita=receita,
        clientes_com_plano=clientes_com_plano,
    )


# =========================================================
# PAINEL SENHA
# =========================================================


@app.route("/painel_senha")
@login_required
def painel_senha():
    require_role("administrador")

    pacientes = (
        Recepcao.query.filter(Recepcao.chamado == True)
        .order_by(Recepcao.horario_chamada.desc())
        .limit(10)
        .all()
    )
    return render_template(
        "utils/painel_senha.html",
        pacientes=pacientes,
        config=carregar_config_painel(),
    )


@app.route("/painel_senha/configurar", methods=["GET", "POST"])
@login_required
def configurar_painel_senha():
    require_role("administrador")
    config = carregar_config_painel()

    if request.method == "POST":
        config.update(
            {
                "titulo": (
                    request.form.get("titulo") or "Painel de Atendimento"
                ).strip()[:80],
                "subtitulo": (
                    request.form.get("subtitulo") or "Clínica Cuidar & Conectar"
                ).strip()[:120],
                "cor_principal": request.form.get("cor_principal") or "#0f172a",
                "cor_destaque": request.form.get("cor_destaque") or "#14b8a6",
                "cor_fundo": request.form.get("cor_fundo") or "#08111f",
                "mostrar_nome": request.form.get("mostrar_nome") == "on",
                "voz": request.form.get("voz") == "on",
                "intervalo_atualizacao": max(
                    2, min(int(request.form.get("intervalo_atualizacao") or 5), 60)
                ),
                "tempo_exibicao": max(
                    5, min(int(request.form.get("tempo_exibicao") or 15), 120)
                ),
            }
        )
        salvar_config_painel(config)
        flash("Personalização do painel salva com sucesso.", "success")
        return redirect(url_for("configurar_painel_senha"))

    return render_template("utils/config_painel_senha.html", config=config)


# =========================================================
# CHAMAR PACIENTE
# =========================================================


@app.route("/chamar_paciente/<int:recepcao_id>", methods=["POST"])
@login_required
def chamar_paciente(recepcao_id):
    """Chama o paciente para um destino físico informado pelo usuário.

    O destino do fluxo clínico continua em Recepcao.destino; o local físico
    da chamada é salvo em Recepcao.fila. Isso evita quebrar as filas de
    triagem, médico, vacinação e psicologia.
    """
    require_role(
        "recepcionista", "enfermeiro", "administrador", "medico", "médico", "psicologo"
    )

    paciente = Recepcao.query.get_or_404(recepcao_id)
    destino_chamada = (request.form.get("destino_chamada") or "").strip()

    if not destino_chamada:
        flash(
            "Informe o destino do paciente, por exemplo: Sala 1 ou Triagem.", "warning"
        )
        return redirect(request.referrer or url_for("recepcao_list"))

    if len(destino_chamada) > 100:
        flash("O destino deve ter no máximo 100 caracteres.", "warning")
        return redirect(request.referrer or url_for("recepcao_list"))

    if paciente.finalizado:
        flash("Este atendimento já foi finalizado.", "warning")
        return redirect(request.referrer or url_for("recepcao_list"))

    paciente.chamado = True
    paciente.fila = destino_chamada
    paciente.horario_chamada = datetime.now(timezone.utc)
    paciente.status = f"Chamado — dirigir-se para {destino_chamada}"

    destino_fluxo = (paciente.destino or "").strip().lower()
    notificacoes = {
        "triagem": (
            "enfermeiro",
            "Paciente chamado para triagem",
            url_for("triagem_dashboard"),
        ),
        "medico": (
            "medico",
            "Paciente chamado para atendimento médico",
            url_for("dashboard_medico"),
        ),
        "vacinacao": (
            "enfermeiro",
            "Paciente chamado para vacinação",
            url_for("lista_vacinacao"),
        ),
        "psicologo": (
            "psicologo",
            "Paciente chamado para psicologia",
            url_for("dashboard_psicologo"),
        ),
    }

    if destino_fluxo in notificacoes:
        funcao, titulo, link = notificacoes[destino_fluxo]
        notificar_funcao(
            funcao,
            titulo,
            f"{paciente.paciente.nome_completo} foi chamado para {destino_chamada}.",
            "info",
            link,
        )

    db1.session.commit()
    flash(
        f"Paciente {paciente.paciente.nome_completo} chamado para {destino_chamada}.",
        "success",
    )
    return redirect(request.referrer or url_for("recepcao_list"))


# =========================================================
# SUPORTE TÉCNICO
# =========================================================


def _funcao_suporte(funcao):
    return (funcao or "").strip().lower() in {
        "suporte tecnico",
        "suporte técnico",
        "suporte_tecnico",
    }


@app.route("/suporte")
@login_required
def suporte_dashboard():

    eh_suporte = _funcao_suporte(current_user.funcao) or check_role("administrador")

    if eh_suporte:
        base_query = ChamadoSuporte.query
    else:
        base_query = ChamadoSuporte.query.filter_by(solicitante_id=current_user.id)

    status_ordem = {
        "Aberto": 0,
        "Em atendimento": 1,
        "Aguardando usuário": 2,
        "Resolvido": 3,
        "Cancelado": 4,
    }

    chamados = base_query.order_by(ChamadoSuporte.criado_em.desc()).all()

    prioridade_ordem = {"Crítica": 0, "Alta": 1, "Normal": 2, "Baixa": 3}

    def chave_ticket(c):
        return (
            prioridade_ordem.get(c.prioridade, 9),
            c.criado_em or datetime.min.replace(tzinfo=timezone.utc),
        )

    filas = {status: [] for status in status_ordem}
    for chamado in chamados:
        filas.setdefault(chamado.status, []).append(chamado)

    for status in filas:
        filas[status].sort(key=chave_ticket)

    estatisticas = {status: len(filas.get(status, [])) for status in status_ordem}

    return render_template(
        "suporte/dashboard_suporte.html",
        chamados=chamados,
        filas=filas,
        estatisticas=estatisticas,
        eh_suporte=eh_suporte,
        status_ordem=list(status_ordem.keys()),
    )


@app.route("/suporte/novo", methods=["GET", "POST"])
@login_required
def suporte_novo():

    categorias = [
        "Sistema",
        "Login / acesso",
        "Computador / estação",
        "Impressora",
        "Rede / internet",
        "Painel / chamada",
        "Erro / bug",
        "Outro",
    ]

    prioridades = ["Baixa", "Normal", "Alta", "Crítica"]

    if request.method == "POST":
        titulo = (request.form.get("titulo") or "").strip()
        categoria = (request.form.get("categoria") or "Sistema").strip()
        descricao = (request.form.get("descricao") or "").strip()
        local = (request.form.get("local") or "Não informado").strip()
        prioridade = (request.form.get("prioridade") or "Normal").strip()

        if not titulo or not descricao:
            flash("Informe o título e descreva o problema.", "danger")
            return render_template(
                "suporte/novo_chamado.html",
                categorias=categorias,
                prioridades=prioridades,
            )

        if categoria not in categorias:
            categoria = "Outro"
        if prioridade not in prioridades:
            prioridade = "Normal"

        chamado = ChamadoSuporte(
            solicitante_id=current_user.id,
            titulo=titulo[:160],
            categoria=categoria,
            descricao=descricao,
            local=local[:120] or "Não informado",
            prioridade=prioridade,
            status="Aberto",
        )

        db1.session.add(chamado)
        db1.session.flush()
        tipo = (
            "danger"
            if prioridade == "Crítica"
            else ("warning" if prioridade == "Alta" else "info")
        )
        notificar_funcao(
            "suporte tecnico",
            f"Novo chamado #{chamado.id}",
            f"{current_user.nome_completo} abriu: {titulo} · {local} · prioridade {prioridade}.",
            tipo,
            url_for("suporte_dashboard"),
        )
        db1.session.commit()

        flash("Chamado enviado ao suporte técnico.", "success")
        return redirect(url_for("suporte_dashboard"))

    return render_template(
        "suporte/novo_chamado.html",
        categorias=categorias,
        prioridades=prioridades,
    )


@app.route("/suporte/chamado/<int:chamado_id>", methods=["POST"])
@login_required
def suporte_atualizar(chamado_id):

    chamado = ChamadoSuporte.query.get_or_404(chamado_id)
    eh_suporte = _funcao_suporte(current_user.funcao)

    if not eh_suporte and not check_role("administrador"):
        abort(403)

    status = (request.form.get("status") or chamado.status).strip()
    resposta = (request.form.get("resposta") or "").strip()

    status_validos = {
        "Aberto",
        "Em atendimento",
        "Aguardando usuário",
        "Resolvido",
        "Cancelado",
    }

    if status not in status_validos:
        flash("Status de chamado inválido.", "danger")
        return redirect(url_for("suporte_dashboard"))

    chamado.status = status
    chamado.resposta = resposta or chamado.resposta
    chamado.atualizado_em = datetime.now(timezone.utc)

    if status in {"Em atendimento", "Resolvido"} and not chamado.responsavel_id:
        chamado.responsavel_id = current_user.id

    if status == "Resolvido":
        chamado.resolvido_em = datetime.now(timezone.utc)
    else:
        chamado.resolvido_em = None

    if status == "Resolvido":
        notificar_usuario(
            chamado.solicitante_id,
            f"Chamado #{chamado.id} resolvido",
            resposta or "O suporte marcou seu chamado como resolvido.",
            "success",
            url_for("meus_chamados_suporte"),
        )
    elif status == "Aguardando usuário":
        notificar_usuario(
            chamado.solicitante_id,
            f"Chamado #{chamado.id} aguarda você",
            resposta or "O suporte precisa de uma informação adicional.",
            "warning",
            url_for("meus_chamados_suporte"),
        )

    db1.session.commit()

    flash(f"Chamado #{chamado.id} atualizado.", "success")
    return redirect(url_for("suporte_dashboard"))


@app.route("/suporte/meus-chamados")
@login_required
def meus_chamados_suporte():

    chamados = (
        ChamadoSuporte.query.filter_by(solicitante_id=current_user.id)
        .order_by(ChamadoSuporte.criado_em.desc())
        .all()
    )

    return render_template(
        "suporte/meus_chamados.html",
        chamados=chamados,
    )


# =========================================================
# SOCKET
# =========================================================


@socketio.on("assinatura_finalizada")
def assinatura_finalizada(data):

    token = data.get("token")

    imagem = data.get("imagem")

    emit("assinatura_recebida", {"token": token, "imagem": imagem}, broadcast=True)


# =========================================================
# GUIA
# =========================================================


@app.route("/documentacao")
@login_required
def documentacao():
    return render_template("utils/documentacao.html")


@app.route("/guia")
@login_required
def guia():
    return redirect(url_for("documentacao"))


# =========================================================
# ERROS
# =========================================================


@app.errorhandler(403)
def forbidden(error):
    return (
        render_template(
            "utils/error.html",
            code=403,
            title="Acesso negado",
            message="Você não tem permissão para acessar esta área.",
        ),
        403,
    )


@app.errorhandler(404)
def not_found(error):
    return (
        render_template(
            "utils/error.html",
            code=404,
            title="Página não encontrada",
            message="O endereço solicitado não existe ou foi removido.",
        ),
        404,
    )


@app.errorhandler(413)
def file_too_large(error):
    flash("A imagem excede o limite de 5 MB.", "danger")
    return redirect(request.referrer or url_for("dashboard_pacientes"))


@app.errorhandler(CSRFError)
def csrf_error(error):
    flash(
        "Sua sessão expirou ou o formulário estava desatualizado. "
        "Por favor, tente novamente.",
        "warning",
    )
    if current_user.is_authenticated:
        return redirect(request.referrer or url_for("login")), 400
    return redirect(url_for("login")), 400


# =========================================================
# RUN
# =========================================================

if __name__ == "__main__":

    socketio.run(
        app,
        host="0.0.0.0",
        port=int(os.getenv("PORT", "5000")),
        debug=os.getenv("FLASK_DEBUG", "0") == "1",
    )
