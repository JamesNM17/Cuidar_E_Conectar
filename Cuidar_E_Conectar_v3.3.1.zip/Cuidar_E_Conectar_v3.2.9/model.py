# =========================================================
# FINALIZADO
# =========================================================

import string
import random
from datetime import datetime, timezone
from flask import redirect, url_for
from flask_login import UserMixin, current_user
from flask_admin.contrib.sqla import ModelView
from werkzeug.security import generate_password_hash, check_password_hash
from dados1 import db1


def _normalizar_funcao(funcao):
    valor = (funcao or "").strip().lower()
    aliases = {
        "médico": "medico",
        "segurança": "seguranca",
        "suporte tecnico": "suporte_ti",
        "suporte técnico": "suporte_ti",
        "suporte_tecnico": "suporte_ti",
    }
    return aliases.get(valor, valor)


# =========================================================
# GERADORES DE ID
# =========================================================


def gerar_id():
    chars = string.ascii_uppercase + string.digits

    while True:

        novo_id = "".join(random.choices(chars, k=5))

        existe = Paciente.query.get(novo_id)

        if not existe:
            return novo_id


def gerar_id_2():
    chars = string.ascii_uppercase + string.digits

    while True:

        novo_id = "".join(random.choices(chars, k=10))

        existe = Funcionarios.query.get(novo_id)

        if not existe:
            return novo_id


# =========================================================
# FUNCIONÁRIOS
# =========================================================


class Funcionarios(UserMixin, db1.Model):

    __tablename__ = "funcionarios"

    id = db1.Column(db1.String(10), primary_key=True, default=gerar_id_2)

    nome_completo = db1.Column(db1.String(100), nullable=False)

    usuario = db1.Column(db1.String(70), nullable=False, unique=True)

    funcao = db1.Column(db1.String(30), nullable=False)

    especialidade = db1.Column(db1.String(50))

    senha = db1.Column(db1.String(200), nullable=False)

    sexo = db1.Column(db1.String(15))

    email = db1.Column(db1.String(100), unique=True)

    telefone = db1.Column(db1.String(20))

    foto = db1.Column(db1.String(200))

    online = db1.Column(db1.Boolean, default=False)

    data_criacao = db1.Column(db1.DateTime, default=lambda: datetime.now(timezone.utc))

    ultimo_login = db1.Column(db1.DateTime)

    ultimo_logout = db1.Column(db1.DateTime)

    # Último local confirmado; a sessão sempre exige nova confirmação no login.
    local_atendimento = db1.Column(db1.String(160))

    assinatura = db1.Column(db1.Text)

    assinatura_token = db1.Column(db1.String(255))

    # =====================================================
    # SENHA
    # =====================================================

    def set_senha(self, senha):
        self.senha = generate_password_hash(senha)

    def check_senha(self, senha):
        return check_password_hash(self.senha, senha)

    def get_id(self):
        return str(self.id)


# =========================================================
# PACIENTES
# =========================================================


class Paciente(db1.Model):

    __tablename__ = "paciente"

    id = db1.Column(db1.String(5), primary_key=True, default=gerar_id)

    nome_completo = db1.Column(db1.String(100), nullable=False)

    data_nascimento = db1.Column(db1.Date)

    sexo = db1.Column(db1.String(15))

    contato = db1.Column(db1.String(100))

    documento = db1.Column(db1.String(30))


    horario_cadastro = db1.Column(
        db1.DateTime, default=lambda: datetime.now(timezone.utc)
    )

    observacoes_cadastro = db1.Column(db1.Text)

    responsavel_cadastro = db1.Column(db1.String(100))

    foto = db1.Column(db1.String(100))

    email = db1.Column(db1.String(100), unique=True)

    usuario = db1.Column(db1.String(100), unique=True)

    senha = db1.Column(db1.String(200))

    responsavel = db1.Column(db1.String(100))

    assinatura = db1.Column(db1.Text)

    assinatura_token = db1.Column(db1.String(255))

    # =====================================================
    # RELACIONAMENTOS
    # =====================================================

    recepcoes = db1.relationship("Recepcao", backref="paciente", lazy=True)


    # =====================================================
    # SENHA
    # =====================================================

    def set_senha(self, senha):
        self.senha = generate_password_hash(senha)

    def check_senha(self, senha):
        return check_password_hash(self.senha, senha)


# =========================================================
# RECEPÇÃO
# =========================================================


class Recepcao(db1.Model):

    __tablename__ = "recepcao"

    id = db1.Column(db1.Integer, primary_key=True)

    paciente_id = db1.Column(
        db1.String(5), db1.ForeignKey("paciente.id"), nullable=False
    )

    urgencia_recepcao = db1.Column(db1.String(50))

    horario_chegada = db1.Column(
        db1.DateTime, default=lambda: datetime.now(timezone.utc)
    )

    chamado = db1.Column(db1.Boolean, default=False)

    destino = db1.Column(db1.String(50))

    observacoes_recepcao = db1.Column(db1.Text)

    responsavel_recepcao = db1.Column(db1.String(100))

    horario_chamada = db1.Column(db1.DateTime)

    fila = db1.Column(db1.String(100))

    status = db1.Column(db1.String(100), default="Aguardando")

    protocolo = db1.Column(db1.String(100))

    motivo = db1.Column(db1.Text)

    finalizado = db1.Column(db1.Boolean, default=False)

    assinatura1 = db1.Column(db1.Text)

    # Controle de reabertura administrativa
    reaberto_em = db1.Column(db1.DateTime)
    reaberto_por = db1.Column(db1.String(100))
    reaberto_motivo = db1.Column(db1.Text)
    reaberto_destino = db1.Column(db1.String(50))

    # Snapshot do local físico no momento da criação do atendimento.
    local_atendimento = db1.Column(db1.String(160))

    # =====================================================
    # RELACIONAMENTOS
    # =====================================================

    triagem = db1.relationship("Triagem", backref="recepcao", uselist=False)

    medico = db1.relationship("Medico", back_populates="recepcao", uselist=False)




# =========================================================
# TRIAGEM
# =========================================================


class Triagem(db1.Model):

    __tablename__ = "triagem"

    id = db1.Column(db1.Integer, primary_key=True)

    recepcao_id = db1.Column(
        db1.Integer, db1.ForeignKey("recepcao.id"), nullable=False, unique=True
    )

    ocupacao = db1.Column(db1.String(100))

    temperatura = db1.Column(db1.String(20))

    freq_cardiaca = db1.Column(db1.Integer)

    freq_respiratoria = db1.Column(db1.Integer)

    peso = db1.Column(db1.String(20))

    altura = db1.Column(db1.String(20))

    queixa_principal = db1.Column(db1.Text)

    doencas_pre_existentes = db1.Column(db1.Text)

    finalizado_triagem = db1.Column(db1.Boolean, default=False)

    responsavel_triagem = db1.Column(db1.String(100))

    observacoes_triagem = db1.Column(db1.Text)

    pressao_arterial = db1.Column(db1.String(20))

    alergia = db1.Column(db1.String(50))

    saturacao = db1.Column(db1.Integer)

    tabagista = db1.Column(db1.Boolean, default=False)

    bebida_alcoolica = db1.Column(db1.Boolean, default=False)

    cirurgia_realizada = db1.Column(db1.Text)

    horario_de_triagem = db1.Column(
        db1.DateTime, default=lambda: datetime.now(timezone.utc)
    )

    escala_de_dor = db1.Column(db1.Integer)

    toma_medicacao = db1.Column(db1.Text)

    imc = db1.Column(db1.String(20))

    gestante = db1.Column(db1.Boolean)

    tipo_sanguineo = db1.Column(db1.String(5))


# =========================================================
# MÉDICO
# =========================================================


class Medico(db1.Model):

    __tablename__ = "medico"

    id = db1.Column(db1.Integer, primary_key=True)

    recepcao_id = db1.Column(
        db1.Integer, db1.ForeignKey("recepcao.id"), nullable=False, unique=True
    )

    diagnostico = db1.Column(db1.Text)

    prescricao = db1.Column(db1.Text)

    feedback = db1.Column(db1.Text)

    observacoes_medico = db1.Column(db1.Text)

    cid = db1.Column(db1.String(20))

    encaminhamento_destino = db1.Column(db1.String(200))
    encaminhamento_motivo = db1.Column(db1.Text)

    finalizado_medico = db1.Column(db1.Boolean, default=False)

    responsavel_medico = db1.Column(db1.String(100))

    horario_de_finalizacao = db1.Column(
        db1.DateTime, default=lambda: datetime.now(timezone.utc)
    )

    # =====================================================
    # RELACIONAMENTOS
    # =====================================================

    recepcao = db1.relationship("Recepcao", back_populates="medico")


# =========================================================
# CHAMADOS DE SEGURANÇA
# =========================================================


class ChamadoSeguranca(db1.Model):

    __tablename__ = "chamados_seguranca"

    id = db1.Column(db1.Integer, primary_key=True)
    solicitante_id = db1.Column(db1.String(10), db1.ForeignKey("funcionarios.id"), nullable=False)
    local = db1.Column(db1.String(160), nullable=False, default="Não informado")
    mensagem = db1.Column(db1.Text)
    status = db1.Column(db1.String(30), nullable=False, default="Pendente")
    criado_em = db1.Column(db1.DateTime, nullable=False, default=lambda: datetime.now(timezone.utc))
    atendido_por = db1.Column(db1.String(100))
    atendido_em = db1.Column(db1.DateTime)

    solicitante = db1.relationship("Funcionarios", foreign_keys=[solicitante_id])


# =========================================================
# NOTIFICAÇÕES
# =========================================================


class Notificacao(db1.Model):

    __tablename__ = "notificacoes"

    id = db1.Column(db1.Integer, primary_key=True)

    destinatario_id = db1.Column(
        db1.String(10), db1.ForeignKey("funcionarios.id"), nullable=True
    )

    funcao_destino = db1.Column(db1.String(40), nullable=True)

    titulo = db1.Column(db1.String(160), nullable=False)

    mensagem = db1.Column(db1.Text, nullable=False)

    tipo = db1.Column(db1.String(20), nullable=False, default="info")

    link = db1.Column(db1.String(255), nullable=True)

    lida = db1.Column(db1.Boolean, nullable=False, default=False)

    voz = db1.Column(db1.Boolean, nullable=False, default=False)

    criada_em = db1.Column(
        db1.DateTime, nullable=False, default=lambda: datetime.now(timezone.utc)
    )

    # =====================================================
    # RELACIONAMENTOS
    # =====================================================

    destinatario = db1.relationship("Funcionarios", foreign_keys=[destinatario_id])


class AcessoLog(db1.Model):

    __tablename__ = "acessos_log"

    id = db1.Column(db1.Integer, primary_key=True)
    funcionario_id = db1.Column(db1.String(10), db1.ForeignKey("funcionarios.id"), nullable=True)
    funcionario_nome = db1.Column(db1.String(100))
    funcao = db1.Column(db1.String(40))
    metodo = db1.Column(db1.String(10), nullable=False)
    caminho = db1.Column(db1.String(255), nullable=False)
    status_code = db1.Column(db1.Integer)
    ip = db1.Column(db1.String(64))
    criado_em = db1.Column(db1.DateTime, nullable=False, default=lambda: datetime.now(timezone.utc))

    funcionario = db1.relationship("Funcionarios", foreign_keys=[funcionario_id])


# =========================================================
# CHAMADOS DE SUPORTE TÉCNICO
# =========================================================


class ChamadoSuporte(db1.Model):

    __tablename__ = "chamados_suporte"

    id = db1.Column(db1.Integer, primary_key=True)

    solicitante_id = db1.Column(
        db1.String(10), db1.ForeignKey("funcionarios.id"), nullable=False
    )

    responsavel_id = db1.Column(
        db1.String(10), db1.ForeignKey("funcionarios.id"), nullable=True
    )

    titulo = db1.Column(db1.String(160), nullable=False)

    categoria = db1.Column(db1.String(50), nullable=False, default="Sistema")

    descricao = db1.Column(db1.Text, nullable=False)

    local = db1.Column(db1.String(120), nullable=False, default="Não informado")

    prioridade = db1.Column(db1.String(20), nullable=False, default="Normal")

    status = db1.Column(db1.String(30), nullable=False, default="Aberto")

    resposta = db1.Column(db1.Text)

    criado_em = db1.Column(
        db1.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False
    )

    atualizado_em = db1.Column(
        db1.DateTime,
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
    )

    resolvido_em = db1.Column(db1.DateTime)

    # =====================================================
    # RELACIONAMENTOS
    # =====================================================

    solicitante = db1.relationship(
        "Funcionarios",
        foreign_keys=[solicitante_id],
        backref=db1.backref("chamados_abertos", lazy=True),
    )

    responsavel = db1.relationship(
        "Funcionarios",
        foreign_keys=[responsavel_id],
        backref=db1.backref("chamados_atendidos", lazy=True),
    )


# =========================================================
# ADMIN BASE
# =========================================================


class BaseAdmin(ModelView):

    def inaccessible_callback(self, name, **kwargs):
        if not current_user.is_authenticated:
            return redirect(url_for("login"))
        # Usuário autenticado, porém sem permissão: não mascarar autorização
        # como uma tela de login.
        from flask import abort
        return abort(403)


# =========================================================
# ADMIN RECEPÇÃO
# =========================================================


class AdminRecepcao(BaseAdmin):

    def is_accessible(self):

        return current_user.is_authenticated and _normalizar_funcao(current_user.funcao) in {"recepcionista", "administrador"}


# =========================================================
# ADMIN TRIAGEM
# =========================================================


class AdminTriagem(BaseAdmin):

    def is_accessible(self):

        return current_user.is_authenticated and _normalizar_funcao(current_user.funcao) in {"enfermeiro", "administrador"}


# =========================================================
# ADMIN MÉDICO
# =========================================================


class AdminMedico(BaseAdmin):

    def is_accessible(self):

        return current_user.is_authenticated and _normalizar_funcao(current_user.funcao) in {"medico", "administrador"}


# =========================================================
# ADMIN FUNCIONÁRIOS
# =========================================================


class AdminFuncionarios(BaseAdmin):

    def is_accessible(self):

        return (
            current_user.is_authenticated
            and _normalizar_funcao(current_user.funcao) == "administrador"
        )
