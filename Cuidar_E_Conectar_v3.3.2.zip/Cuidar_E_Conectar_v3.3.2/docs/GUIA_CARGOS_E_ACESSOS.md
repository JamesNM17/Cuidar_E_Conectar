# Guia de cargos e acessos — Cuidar & Conectar 3.3.2

## Administrador
Visão geral, controle do sistema, central de operações, funcionários, recepção, triagem, pacientes, Conselheiro de Saúde, segurança, suporte e painel de senhas.

## Recepcionista
Recepção e cadastro/atualização de pacientes. Pode consultar o histórico operacional do paciente necessário ao atendimento.

## Enfermeiro
Fila e formulários de triagem. Pode consultar o histórico necessário à assistência.

## Conselheiro de Saúde
Fila/atendimento clínico, histórico assistencial e emissão dos documentos de receita e encaminhamento.

## Segurança
Alertas e chamados de segurança. Não possui acesso a prontuário, funcionários, recepção, triagem ou configuração do painel.

## Suporte de TI
Central de suporte, abertura/acompanhamento/atualização de chamados e reabertura operacional de atendimentos finalizados. Não possui acesso a dados clínicos, funcionários ou configuração administrativa do painel.

## Atalhos comuns
Documentação de estudos, suporte técnico (exceto a área administrativa própria do suporte) e créditos ficam disponíveis aos usuários autenticados.
