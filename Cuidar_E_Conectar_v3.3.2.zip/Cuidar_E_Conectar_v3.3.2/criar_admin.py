import os

from main import app
from dados1 import db1
from model import Funcionarios


def criar_usuario(
    usuario, senha, nome_completo, funcao, sexo="", email=None, telefone=None, especialidade=None
):
    """Cria uma conta administrativa/de trabalho com validação de duplicidade."""
    with app.app_context():
        usuario = (usuario or "").strip().lower()
        email = (email or "").strip().lower() or None
        if not usuario or not senha or not nome_completo or not funcao:
            raise ValueError("Usuário, senha, nome e função são obrigatórios.")
        if Funcionarios.query.filter(db1.func.lower(Funcionarios.usuario) == usuario).first():
            print(f"Usuário '{usuario}' já existe.")
            return False
        if email and Funcionarios.query.filter(db1.func.lower(Funcionarios.email) == email).first():
            print(f"E-mail '{email}' já está em uso.")
            return False

        funcionario = Funcionarios(
            nome_completo=nome_completo.strip()[:100],
            usuario=usuario[:70],
            funcao=funcao.strip().lower()[:30],
            especialidade=especialidade,
            sexo=sexo,
            email=email,
            telefone=(telefone or "").strip() or None,
        )
        funcionario.set_senha(senha)
        db1.session.add(funcionario)
        db1.session.commit()
        print(f"Usuário criado: {funcionario.usuario} ({funcionario.funcao}) — ID {funcionario.id}")
        return True


def criar_usuario_interativo():
    print("=== Cuidar & Conectar — criação de usuário ===")
    nome = input("Nome completo: ").strip()
    usuario = input("Usuário: ").strip()
    senha = input("Senha: ").strip()
    funcao = input("Função (administrador/recepcionista/enfermeiro/medico/suporte_ti/seguranca): ").strip()
    email = input("E-mail (opcional): ").strip() or None
    telefone = input("Telefone (opcional): ").strip() or None
    especialidade = None
    if funcao.lower() in {"medico", "médico"}:
        especialidade = input("Especialidade (opcional): ").strip() or None
    criar_usuario(usuario, senha, nome, funcao, email=email, telefone=telefone, especialidade=especialidade)


def criar_usuarios_demo():
    """Cria contas de demonstração somente com confirmação explícita por variável de ambiente."""
    usuarios = [
        ("admin", "admin123", "Administrador do Sistema", "administrador", "admin@clinica.com", None, None),
        ("recepcao", "recepcao123", "Recepcionista", "recepcionista", "recepcao@clinica.com", None, None),
        ("medico", "medico123", "Médico Responsável", "medico", "medico@clinica.com", None, "clinica_medica"),
        ("enfermeiro", "enfermeiro123", "Enfermeiro Responsável", "enfermeiro", "enfermeiro@clinica.com", None, None),
        ("suporte", "suporte123", "Suporte de TI", "suporte_ti", "suporte@clinica.com", None, None),
    ]
    for usuario, senha, nome, funcao, email, telefone, especialidade in usuarios:
        criar_usuario(usuario, senha, nome, funcao, email=email, telefone=telefone, especialidade=especialidade)


if __name__ == "__main__":
    if os.getenv("CRIAR_USUARIOS_DEMO") == "1":
        print("Modo DEMO ativado. As contas de demonstração serão criadas somente se ainda não existirem.")
        criar_usuarios_demo()
    else:
        criar_usuario_interativo()
