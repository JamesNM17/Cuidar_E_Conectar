# =========================================================
# FINALIZADO
# =========================================================

from flask_wtf import FlaskForm
from flask_wtf.file import FileField
from wtforms import (
    HiddenField,
    StringField,
    IntegerField,
    FloatField,
    SelectField,
    SubmitField,
    TextAreaField,
    DateField,
    BooleanField,
    PasswordField,
)
from decimal import Decimal, InvalidOperation
from wtforms.validators import (
    InputRequired,
    Optional,
    Length,
    NumberRange,
    Email,
    EqualTo,
)


class PrecoBRField(StringField):
    """Campo monetário que aceita 1234,56 e 1234.56."""

    def process_data(self, value):
        if value is None:
            self.data = ""
        else:
            self.data = f"{float(value):.2f}".replace(".", ",")

    def process_formdata(self, valuelist):
        if not valuelist:
            return
        value = (valuelist[0] or "").strip().replace("R$", "").replace(" ", "")
        if "," in value:
            value = value.replace(".", "").replace(",", ".")
        self.data = value

    def to_float(self):
        try:
            value = str(self.data or "").strip().replace("R$", "").replace(" ", "")
            if "," in value:
                value = value.replace(".", "").replace(",", ".")
            return float(value)
        except (ValueError, TypeError):
            raise ValueError("Informe um preço válido, por exemplo 149,90.")


class LocalAtendimentoForm(FlaskForm):
    """Confirma o local físico de trabalho para a sessão atual."""

    local = StringField(
        "Local de atendimento",
        validators=[InputRequired(), Length(min=2, max=160)],
    )
    submit = SubmitField("Continuar")


# =========================================================
# FUNCIONÁRIOS
# =========================================================


class FuncionarioForm(FlaskForm):

    nome_completo = StringField(
        "Nome completo", validators=[InputRequired(), Length(max=100)]
    )

    usuario = StringField("Usuário", validators=[InputRequired(), Length(max=70)])

    funcao = SelectField(
        "Função",
        choices=[
            ("administrador", "Administrador"),
            ("recepcionista", "Recepcionista"),
            ("medico", "Conselheiro de Saúde"),
            ("enfermeiro", "Enfermeiro"),
            ("psicologo", "Psicólogo"),
            ("comercial", "Comercial"),
            ("suporte_ti", "Suporte de TI"),
            ("seguranca", "Segurança"),
        ],
        validators=[InputRequired()],
    )

    especialidade = SelectField(
        "Especialidade",
        choices=[
            ("", "Não se aplica"),
            ("clinica_medica", "Conselheiro de Saúde"),
            ("pediatria", "Pediatria"),
            ("cardiologia", "Cardiologia"),
            ("dermatologia", "Dermatologia"),
            ("ginecologia", "Ginecologia"),
            ("psicologia_clinica", "Psicologia Clínica"),
        ],
        validators=[Optional()],
    )

    senha = PasswordField("Senha", validators=[Optional(), Length(min=6, max=200)])

    confirmar_senha = PasswordField(
        "Confirmar senha",
        validators=[
            Optional(),
            EqualTo("senha", message="As senhas devem ser iguais."),
        ],
    )

    sexo = SelectField(
        "Sexo",
        choices=[
            ("", "Selecione"),
            ("Masculino", "Masculino"),
            ("Feminino", "Feminino"),
            ("Outro", "Outro"),
        ],
        validators=[Optional()],
    )

    email = StringField("Email", validators=[Optional(), Email(), Length(max=100)])

    telefone = StringField("Telefone", validators=[Optional(), Length(max=20)])

    assinatura = TextAreaField("Assinatura", validators=[Optional()])

    submit = SubmitField("Salvar")


# =========================================================
# PACIENTE
# =========================================================


class PacienteForm(FlaskForm):

    nome_completo = StringField(
        "Nome completo", validators=[InputRequired(), Length(max=100)]
    )

    data_nascimento = DateField(
        "Data de nascimento", format="%Y-%m-%d", validators=[Optional()]
    )

    sexo = SelectField(
        "Sexo",
        choices=[
            ("", "Selecione"),
            ("Masculino", "Masculino"),
            ("Feminino", "Feminino"),
            ("Outro", "Outro"),
        ],
        validators=[Optional()],
    )

    contato = StringField("Contato", validators=[Optional(), Length(max=100)])

    documento = StringField("Documento", validators=[Optional(), Length(max=30)])

    plano = SelectField("Plano", choices=[], coerce=str)

    observacoes_cadastro = TextAreaField(
        "Observações", validators=[Optional(), Length(max=5000)]
    )

    responsavel_cadastro = StringField(
        "Responsável pelo cadastro", validators=[Optional(), Length(max=100)]
    )

    foto = FileField("Foto")

    email = StringField("Email", validators=[Optional(), Email(), Length(max=100)])

    usuario = StringField("Usuário", validators=[Optional(), Length(max=100)])

    senha = PasswordField("Senha", validators=[Optional(), Length(min=6, max=200)])

    confirmar_senha = PasswordField(
        "Confirmar senha",
        validators=[
            Optional(),
            EqualTo("senha", message="As senhas devem ser iguais."),
        ],
    )

    responsavel = StringField("Responsável", validators=[Optional(), Length(max=100)])

    assinatura = TextAreaField("Assinatura", validators=[Optional()])

    submit = SubmitField("Salvar")


# =========================================================
# RECEPÇÃO
# =========================================================


class RecepcaoForm(FlaskForm):

    paciente_id = SelectField("Paciente", coerce=str, validators=[InputRequired()])

    urgencia_recepcao = SelectField(
        "Urgência",
        choices=[
            ("", "Selecione"),
            ("Vermelho", "Vermelho"),
            ("Laranja", "Laranja"),
            ("Amarelo", "Amarelo"),
            ("Verde", "Verde"),
            ("Azul", "Azul"),
        ],
        validators=[Optional()],
    )

    chamado = BooleanField("Paciente chamado")

    destino = SelectField(
        "Destino",
        choices=[
            ("", "Selecione"),
            ("Triagem", "Triagem"),
            ("Consultório", "Consultório"),
            ("Vacinação", "Vacinação"),
            ("Emergência", "Emergência"),
            ("Observação", "Observação"),
        ],
        validators=[Optional()],
    )

    observacoes_recepcao = TextAreaField(
        "Observações", validators=[Optional(), Length(max=5000)]
    )

    responsavel_recepcao = StringField(
        "Responsável", validators=[Optional(), Length(max=100)]
    )

    fila = StringField("Fila", validators=[Optional(), Length(max=100)])

    status = SelectField(
        "Status",
        choices=[
            ("Aguardando", "Aguardando"),
            ("Em atendimento", "Em atendimento"),
            ("Finalizado", "Finalizado"),
        ],
        validators=[Optional()],
    )

    protocolo = StringField("Protocolo", validators=[Optional(), Length(max=100)])

    motivo = TextAreaField("Motivo", validators=[Optional(), Length(max=5000)])

    finalizado = BooleanField("Finalizado")

    assinatura1 = TextAreaField("Assinatura", validators=[Optional()])

    submit = SubmitField("Salvar")


# =========================================================
# TRIAGEM
# =========================================================


class TriagemForm(FlaskForm):

    recepcao_id = SelectField("Paciente", coerce=int, validators=[InputRequired()])

    ocupacao = StringField("Ocupação", validators=[Optional(), Length(max=100)])

    temperatura = StringField("Temperatura", validators=[Optional(), Length(max=20)])

    freq_cardiaca = IntegerField("Frequência cardíaca", validators=[Optional()])

    freq_respiratoria = IntegerField("Frequência respiratória", validators=[Optional()])

    peso = StringField("Peso", validators=[Optional(), Length(max=20)])

    altura = StringField("Altura", validators=[Optional(), Length(max=20)])

    pressao_arterial = StringField(
        "Pressão arterial", validators=[Optional(), Length(max=20)]
    )

    saturacao = IntegerField(
        "Saturação", validators=[Optional(), NumberRange(min=0, max=100)]
    )

    alergia = StringField("Alergia", validators=[Optional(), Length(max=50)])

    queixa_principal = TextAreaField(
        "Queixa principal", validators=[Optional(), Length(max=5000)]
    )

    doencas_pre_existentes = TextAreaField(
        "Doenças pré-existentes", validators=[Optional(), Length(max=5000)]
    )

    finalizado_triagem = BooleanField("Triagem finalizada")

    responsavel_triagem = StringField(
        "Responsável", validators=[Optional(), Length(max=100)]
    )

    observacoes_triagem = TextAreaField(
        "Observações", validators=[Optional(), Length(max=5000)]
    )

    tabagista = BooleanField("Tabagista")

    bebida_alcoolica = BooleanField("Bebida alcoólica")

    cirurgia_realizada = TextAreaField(
        "Cirurgias realizadas", validators=[Optional(), Length(max=5000)]
    )

    escala_de_dor = IntegerField(
        "Escala de dor", validators=[Optional(), NumberRange(min=0, max=10)]
    )

    toma_medicacao = TextAreaField(
        "Medicação em uso", validators=[Optional(), Length(max=5000)]
    )

    imc = StringField("IMC", validators=[Optional(), Length(max=20)])

    gestante = BooleanField("Gestante")

    tipo_sanguineo = SelectField(
        "Tipo sanguíneo",
        choices=[
            ("", "Selecione"),
            ("A+", "A+"),
            ("A-", "A-"),
            ("B+", "B+"),
            ("B-", "B-"),
            ("AB+", "AB+"),
            ("AB-", "AB-"),
            ("O+", "O+"),
            ("O-", "O-"),
        ],
        validators=[Optional()],
    )

    submit = SubmitField("Salvar")


# =========================================================
# MÉDICO
# =========================================================


class MedicoForm(FlaskForm):

    recepcao_id = SelectField("Paciente", coerce=int, validators=[InputRequired()])

    diagnostico = TextAreaField(
        "Diagnóstico", validators=[Optional(), Length(max=5000)]
    )

    prescricao = TextAreaField("Prescrição", validators=[Optional(), Length(max=5000)])

    feedback = TextAreaField("Feedback", validators=[Optional(), Length(max=5000)])

    observacoes_medico = TextAreaField(
        "Observações", validators=[Optional(), Length(max=5000)]
    )

    cid = StringField("CID", validators=[Optional(), Length(max=20)])

    finalizado_medico = BooleanField("Atendimento finalizado")

    destino_final = SelectField(
        "Após o atendimento",
        choices=[
            ("ENCERRAR", "Finalizar atendimento"),
            ("ENCAMINHAMENTO", "Emitir encaminhamento"),
            ("VACINACAO", "Encaminhar para vacinação"),
            ("PSICOLOGIA", "Encaminhar para psicologia"),
        ],
        default="ENCERRAR",
        validators=[InputRequired()],
    )

    encaminhamento_psicologia = TextAreaField(
        "Motivo do encaminhamento para psicologia",
        validators=[Optional(), Length(max=2000)],
    )

    encaminhamento_destino = StringField(
        "Encaminhar para", validators=[Optional(), Length(max=200)]
    )

    encaminhamento_motivo = TextAreaField(
        "Motivo do encaminhamento", validators=[Optional(), Length(max=3000)]
    )

    responsavel_medico = StringField(
        "Responsável", validators=[Optional(), Length(max=100)]
    )

    submit = SubmitField("Salvar")

    def preencher_form(self, recepcao):

        self.recepcao_id.choices = [
            (
                recepcao.id,
                (f"{recepcao.id}" f" - " f"{recepcao.paciente.nome_completo}"),
            )
        ]

        self.recepcao_id.data = recepcao.id

        if recepcao.medico:

            self.diagnostico.data = recepcao.medico.diagnostico

            self.prescricao.data = recepcao.medico.prescricao

            self.feedback.data = recepcao.medico.feedback

            self.observacoes_medico.data = recepcao.medico.observacoes_medico

            self.cid.data = recepcao.medico.cid

            self.finalizado_medico.data = recepcao.medico.finalizado_medico

            self.responsavel_medico.data = recepcao.medico.responsavel_medico
            self.encaminhamento_destino.data = recepcao.medico.encaminhamento_destino
            self.encaminhamento_motivo.data = recepcao.medico.encaminhamento_motivo


# =========================================================
# PLANOS
# =========================================================


class PlanoForm(FlaskForm):

    nome_plano = StringField(
        "Nome do plano", validators=[InputRequired(), Length(max=100)]
    )

    preco = PrecoBRField("Preço", validators=[InputRequired()])

    descricao = TextAreaField("Descrição", validators=[Optional(), Length(max=5000)])

    ativo = BooleanField("Plano ativo")

    submit = SubmitField("Salvar")


# =========================================================
# PACIENTE PLANO
# =========================================================


class PacientePlanoForm(FlaskForm):

    paciente_id = SelectField("Paciente", coerce=str, validators=[InputRequired()])

    plano_id = SelectField("Plano", coerce=int, validators=[InputRequired()])

    data_inicio = DateField(
        "Data de início", format="%Y-%m-%d", validators=[InputRequired()]
    )

    data_vencimento = DateField(
        "Data de vencimento", format="%Y-%m-%d", validators=[Optional()]
    )

    pagamento_em_dia = BooleanField("Pagamento em dia")

    ativo = BooleanField("Plano ativo")

    submit = SubmitField("Salvar")


# =========================================================
# VACINAÇÃO
# =========================================================


class VacinacaoForm(FlaskForm):

    recepcao_id = SelectField("Paciente", coerce=int, validators=[InputRequired()])

    vacina = StringField("Vacina", validators=[InputRequired(), Length(max=100)])

    dose = StringField("Dose", validators=[Optional(), Length(max=30)])

    lote = StringField("Lote", validators=[Optional(), Length(max=50)])

    fabricante = StringField("Fabricante", validators=[Optional(), Length(max=100)])

    observacoes = TextAreaField(
        "Observações", validators=[Optional(), Length(max=5000)]
    )

    responsavel_vacinacao = StringField(
        "Responsável", validators=[Optional(), Length(max=100)]
    )

    assinatura = TextAreaField("Assinatura", validators=[Optional()])

    submit = SubmitField("Salvar")


# =========================================================
# LOGIN
# =========================================================


class LoginForm(FlaskForm):

    usuario = StringField("Usuário", validators=[InputRequired()])

    senha = PasswordField("Senha", validators=[InputRequired()])

    submit = SubmitField("Entrar")


# =========================================================
# PSICOLOGIA
# =========================================================


class PsicologiaForm(FlaskForm):
    recepcao_id = HiddenField()
    avaliacao = TextAreaField(
        "Avaliação psicológica", validators=[Optional(), Length(max=10000)]
    )
    observacoes = TextAreaField(
        "Anotações do atendimento", validators=[Optional(), Length(max=10000)]
    )
    diagnostico = TextAreaField(
        "Impressão diagnóstica", validators=[Optional(), Length(max=5000)]
    )
    conduta = TextAreaField(
        "Conduta e orientações", validators=[Optional(), Length(max=5000)]
    )
    finalizado_psicologia = BooleanField("Atendimento finalizado")
    submit = SubmitField("Finalizar atendimento")